	HelpWindow = new Object();

		//		**********************	HELP WINDOW	**********************
	function CloseWindow()
	{
	  try
	  {
		if( typeof( HelpWindow ) == "object" && !HelpWindow.closed )
		{
			HelpWindow.close();
			throw "e";
		}
	  }
	  catch(e){ return(e);}
	}
	
	function OpenWindow( form, par, Obj )
	{
		with( form )
		{
			var FinEnd	= parseInt( StYr.value ) + 1;
			HelpWindow = open( '/Client/FA_FOCAPS/HelpSearch/MultiClientsHelp.cfm?cocd='+ cocd.value +'&coname='+ coname.value +'&StYr='+ StYr.value +'&EndYr='+ EndYr.value +'&Object='+ Obj +'&helpfor='+par ,'HelpWindow', 'width= 700 , height= 525 , scrollbar = no, top=0, left=0 menubar=no, titlebar=no, toolbar=no, status=no, resizeable=no' );
		}
	}
	
	function OpenWindowWithParam( form, par, Obj, Param, Param1 )
	{
		with( form )
		{
			var FinEnd	= parseInt( StYr.value ) + 1;
			HelpWindow = open( '/Client/FA_FOCAPS/HelpSearch/MultiClientsHelp.cfm?cocd='+ cocd.value +'&coname='+ coname.value +'&StYr='+ StYr.value +'&EndYr='+ EndYr.value +'&Object='+ Obj +'&helpfor='+ par +'&Param='+ Param  +'&Param1='+ Param1,'HelpWindow', 'width= 700 , height= 525 , scrollbar = no, top=0, left=0 menubar=no, titlebar=no, toolbar=no, status=no, resizeable=no' );
		}
	}
	
	function OpenWindowForPosting( form, par, Obj )
	{
		with( form )
		{
			var FinEnd	= parseInt( StYr.value ) + 1;
			HelpWindow = open( '/Client/FA_FOCAPS/HelpSearch/BalanceSheetHelp.cfm?cocd='+ cocd.value +'&coname='+ coname.value +'&StYr='+ StYr.value +'&EndYr='+ EndYr.value +'&Object='+ Obj +'&helpfor='+par ,'HelpWindow', 'width= 700 , height= 525 , scrollbar = no, top=0, left=0 menubar=no, titlebar=no, toolbar=no, status=no, resizeable=no' );
		}
	}
	function BankDetail(form,TxtPartyCode,Tr_Type)
	{
		with(form)
		{
			HelpWindow = open('/Client/FA_FOCAPS/Forms/BankListforRecipt.cfm?TxtPartyCode='+TxtPartyCode.value+'&Tr_Type='+Tr_Type.value,'HelpWindow','width= 800 , height= 225 , scrollbar = Yes, top=200, left=0 menubar=no, titlebar=no, toolbar=no, status=no, resizeable=yes');
		}
	}
	function OpenClientTransaction(form,TxtPartyCode,TxtPartyName,ToDate)
	{
		with(form)
		{
			HelpWindow = open('/Client/FA_FOCAPS/FORMS/REPORTAccountDetail.cfm?cocd='+ cocd.value +'&coname='+ coname.value +'&StYr='+ StYr.value +'&EndYr='+ EndYr.value +'&ClientCode='+ TxtPartyCode.value+'&FromDt=01/04/'+StYr.value+'&ToDt='+ToDate,'HelpWindow','width= 800 , height= 550 ,hscroll = yes, scrollbar = Yes,top = 0,left=0 menubar=no, titlebar=no, toolbar=no, status=no, resizeable=no' );
		}
	}

		//		**********************************************************
