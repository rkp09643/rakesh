//	FUNCTION FOR VALIDATING SELECTION / DESELECTION OF ALL ITEMS FROM THE LIST.
function selectDeselectAll( form, chk, recCnt, idName )
{
	with( form )
	{
		for( i = 1; i <= recCnt; i++ )
		{
			if( chk == "Y" || ALL.checked )
			{
				eval( idName +i ).checked	=	true;
			}
			else
			{
				eval( idName +i ).checked	=	false;
			}
		}
	}
}


//	FUNCTION FOR VALIDATING THE FORM BEFORE SUBMITTING IT.
function chkForSelection( form, recCnt, idName )
{
	var checkedItemsCnt	=	0;
	
	with( form )
	{
		for( i = 1; i <= recCnt; i++ )
		{
			if( eval( idName +i ).checked )
			{
				checkedItemsCnt	=	( checkedItemsCnt + 1 );
			}
		}
		
		if( checkedItemsCnt == 0 )
		{
			alert( "You should select atleast one Client-ID to proceed." );
			return false;
		}
	}
}