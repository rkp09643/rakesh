/* #####################################################################################
					JAVASCRIPT FILE FOR VALIDATING THE NUMERIC FORM FIELDS.
##################################################################################### */


/* *********************************************************
		FUNCTION FOR VALIDATING EMPTY FORM FIELDS.
********************************************************* */
function selectDeSelectAll( formObj )
{
	with( formObj )
	{
		if( chkAll.checked )
		{/*
			for( i = 1; i <= TotalClients.value; i++ )
			{
				eval( "Clients" +i ).checked	=	true;
			}*/
		}
		else
		{/*
			for( i = 1; i <= TotalClients.value; i++ )
			{
				eval( "Clients" +i ).checked	=	false;
			}*/
		}
	}
}


/* *********************************************************
		FUNCTION FOR VALIDATING EMPTY FORM FIELDS.
********************************************************* */
function validateFormFields( formObj, fieldObj, fieldName, fieldType, allowNegative, markType )
{
	with( eval( formObj ) )
	{
		fieldObj		=	eval( fieldObj );
		fieldValue		=	fieldObj.value;
		
		if( ( fieldValue == "" ) || ( fieldValue.charAt(0) == " " ) )
		{
			alert( "Please enter a value for '" +fieldName +"'." );
			fieldObj.focus();
			
			return false;
		}
	}
}