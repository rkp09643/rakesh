//	FOR SELECTING/DESELECTING ALL CLIENTS TO MARK THE AUTO OUTWARD PROCESS.
function selectDeSelectAll( form )
{
	with( form )
	{
		if( typeof( TotalClients ) != "undefined" )
		{
			for( clientSlNo = 1; clientSlNo <= TotalClients.value; clientSlNo++ )
			{
				if( chkAll.checked )
				{
					eval( "Clients" +clientSlNo ).checked	=	true;
				}
				else
				{
					eval( "Clients" +clientSlNo ).checked	=	false;
				}
				
				for ( scripSlNo = 1; scripSlNo <= eval( "TotalScrips" +clientSlNo ).value; scripSlNo++ )
				{
					if( eval( "Clients" +clientSlNo ).checked )
					{
						eval( "ClientScrips" +clientSlNo +scripSlNo ).checked = true;
					}
					else
					{
						eval( "ClientScrips" +clientSlNo +scripSlNo ).checked = false;
					}
				}
			}
		}
	}
}


//	FOR SELECTING/DESELECTING PARTICULAR CLIENT'S ALL SCRIPS TO MARK THE AUTO OUTWARD PROCESS.
function selectDeSelectClients( form, clientSlNo )
{
	with( form )
	{
		for ( scripSlNo = 1; scripSlNo <= eval( "TotalScrips" +clientSlNo ).value; scripSlNo++ )
		{
			if( eval( "Clients" +clientSlNo ).checked )
			{
				eval( "ClientScrips" +clientSlNo +scripSlNo ).checked = true;
			}
			else
			{
				eval( "ClientScrips" +clientSlNo +scripSlNo ).checked = false;
			}
		}
	}
}


//	FOR VALIDATING THE FORM FIELDS BEFORE SUBMITTING TO MARK THE AUTO OUTWARD PROCESS.
function validateFormFields( form, hasClientDPDetail, hasReason )
{
	var checkedCount	=	0;
	var recNo			=	0;
	
	with( form )
	{
		if( typeof( TotalClients ) != "undefined" )
		{
			for ( clientSlNo = 1; clientSlNo <= TotalClients.value; clientSlNo++ )
			{
				for ( scripSlNo = 1; scripSlNo <= eval( "TotalScrips" +clientSlNo ).value; scripSlNo++ )
				{
					recNo				=	recNo + 1;
					
					ISINObj				=	eval( "ISIN" +recNo );
					
					if( hasClientDPDetail == "Y" )
					{
						ClientDPDetailObj	=	eval( "ClientDPDetail" +recNo );
					}
					
					QtyToMarkObj		=	eval( "QtyToMark" +recNo );
					
					//	FOR RESETING THE "ISIN" FIELD UI SETTINGS.
					ISINObj.readOnly			=	true;
					ISINObj.style.border		=	"None";
					ISINObj.style.color			=	"Navy";
					
					//	FOR RESETING THE "QtyToMark" FIELD UI SETTINGS.
					QtyToMarkObj.style.border	=	"1pt Solid Black";
					QtyToMarkObj.style.color	=	"Black";
					
					if( eval( "ClientScrips" +clientSlNo +scripSlNo ).checked )
					{
						checkedCount	=	checkedCount + 1;
						
						//	FOR VALIDATING THE FIELD "ISIN". IT SHOULD NOT BE EMPTY.
						if( ( ISINObj.value == "" ) || ( ISINObj.value.charAt(0) == " " ) )
						{
							alert( "Please enter a value for 'ISIN'." );
							ISINObj.value			=	"";
							//ISINObj.readOnly		=	false;
							ISINObj.style.border	=	"1pt Solid Red";
							ISINObj.style.color		=	"Black";
							ISINObj.focus();
							return false;
						}
						
						//	FOR VALIDATING THE FIELD "ClientDPDetail". IT SHOULD NOT BE EMPTY.
						if( hasClientDPDetail == "Y" )
						{
							if( ( ClientDPDetailObj.value == "" ) || ( ClientDPDetailObj.value.charAt(0) == " " ) )
							{
								alert( "Please enter a value for 'ClientDPDetail'." );
								ClientDPDetailObj.focus();
								return false;
							}
						}
						
						//	FOR VALIDATING THE FIELD "QtyToMark". IT SHOULD NOT BE EMPTY OR ZERO.
						if( ( QtyToMarkObj.value == "" ) || ( QtyToMarkObj.value.charAt(0) == " " ) )
						{
							alert( "Please enter a value for 'Quantity To Mark'." );
							QtyToMarkObj.focus();
							QtyToMarkObj.style.border	=	"1pt Solid Red";
							QtyToMarkObj.style.color	=	"Black";
							return false;
						}
						else if( ( parseInt( QtyToMarkObj.value ) == 0 ) )
						{
							alert( "'Quantity To Mark' should be greater than zero." );
							QtyToMarkObj.value			=	"";
							QtyToMarkObj.style.border	=	"1pt Solid Red";
							QtyToMarkObj.style.color	=	"Black";
							QtyToMarkObj.focus();
							return false;
						}
						else
						{
							//	FOR VALIDATING THE NUMERIC FIELD "Quantity To Mark".
							//chkForValidNumber( form, QtyToMarkObj, 'Quantity To Mark', QtyToMarkObj.value, 'Integer', 'No', 'No', 'No', 'No' );
							
							DeliverableQty		=	parseInt( eval( "DeliverableQty" +recNo ).value );
							DeliveredQty		=	parseInt( eval( "DeliveredQty" +recNo ).value );
							BalDeliverableQty	=	DeliverableQty - DeliveredQty;
							
							if( parseInt( QtyToMarkObj.value ) > BalDeliverableQty )
							{
								alert( "'Quantity To Mark' should be less than\nBalance Deliverable Quantity,\ni.e.'" +DeliverableQty +" - " +DeliveredQty +" = " +BalDeliverableQty +"' and NOT '" +QtyToMarkObj.value +"'." );
								QtyToMarkObj.value			=	BalDeliverableQty;
								QtyToMarkObj.style.border	=	"1pt Solid Red";
								QtyToMarkObj.style.color	=	"Black";
								QtyToMarkObj.focus();
								return false;
							}
						}
						
						if( hasReason == "Y" )
						{
							eval( "Narration" +recNo ).value	=	eval( "Reason" +clientSlNo ).value;
						}
					}
				}
			}
			
			if( checkedCount == 0 )
			{
				alert( "Please select atleast one Record to proceed further." );
				return false;
			}
		}

		ProcessData.value	=	"Yes";
		Process.disabled	=	true;
	}
}