function	Initialize( form )
{
	with ( form )
	{
		Save.style.display="none";
		Delete.style.display="none";
		showHide( form );
	}	
}

function showHide( form )
{
	with ( form )
	{
		if ( name == "REPORT_ENTRY" )
		{
			REPORT_ID.focus();
			Save.style.display="";
			Save.value = "Save";
			Cancel.value = "Clear";
			REPORT_DETAIL_FRAME.style.display='none';
		}
		else if ( name == "REPORT_DETAIL_ENTRY" )
		{
			DetailView.style.height = "100%";
			DetailEntry.style.display = "none";
		}
	}
}

function 	setMasterValues(form, report_value)
{
	with ( form )
	{
		if ( report_value.length > 0 )
		{
			fieldString = new String( report_value ).split(",");
			PREVREPORT_ID.value			=	fieldString[0];
			REPORT_ID.value				=	fieldString[0];
			REPORT_NAME.value			=	fieldString[1];
			REPORT_VERSION.value		=	fieldString[2];
			REPORT_LOCATION.value		=	fieldString[3];
			REPORT_SEGMENT.value		=	fieldString[4];
			REPORT_DESCRIPTION.value	=	fieldString[5];
			REPORT_TYPE_LOCATION.value	=	fieldString[6];
			if (fieldString[7] == "CRYSTAL")				
			{
				REPORT_TYPE[0].checked = true;
			}
			else
			{
				REPORT_TYPE[1].checked = true;
			}
			Save.style.display = "";
			Delete.style.display = "";
			Save.value = "Update";
			Cancel.value = "Cancel";
			REPORT_DETAIL_FRAME.style.display='';
			REPORT_DETAIL.location.href	=	"REPORT_DETAIL_ENTRY.cfm?REPORT_ID=" + REPORT_ID.value;
		}	
	}	
}

function 	clear_Fields( form )
{
	with ( form )
	{
		REPORT_ID.value = "";
		REPORT_NAME.value = "";
		REPORT_LOCATION.value = "";
		REPORT_DESCRIPTION.value = "";
		REPORT_ID.focus();
	}	
}

function 	Reset_Form( form )
{
	with ( form )
	{
		clear_Fields( form );
		Save.style.display="none";
		Delete.style.display = "none";
	}
}
///////////DETAIL
function	New_Records( form )
{
	with ( form )
	{
		DetailView.style.display = "none"; 
		DetailEntry.style.display = "";
		PARAMETER_DESCRIPTIONS.focus();
		Save.style.display = "";
		Delete.style.display = "none";
		DetailSave.value="Save";
		defaultStyle( form );
	}
}

function 	setDetailValues( SEQ_ID, PARAM_NAME, PARAM_HEADING, INPUTTYPE, INPUT_TYPE_VAL, INPUT_TYPE_TXT, DT_TYPE, REQ, DISP, DEF_VAL, OPERATOR, CMB_QURY, HELP_QURY, HELP_RET_INPUT_TYPE, PARAM_DESC )
{
	with ( REPORT_DETAIL_ENTRY )
	{
		PREVSEQUENCE_ID.value			= SEQ_ID;
		SEQUENCE_ID.value				= SEQ_ID; 
		PREVPARAMETER_NAME.value		= PARAM_NAME; 
		PARAMETER_NAME.value			= PARAM_NAME; 
		PARAMETER_HEADING.value			= PARAM_HEADING;	 
		INPUT_TYPE.value				= INPUTTYPE; 
		INPUT_TYPE_VALUE.value			= INPUT_TYPE_VAL; 
		INPUT_TYPE_TEXT.value			= INPUT_TYPE_TXT; 
		DATA_TYPE.value					= DT_TYPE; 
		if ( REQ == "YES" )
		{
			REQUIRED(0).checked			= true; 
		}
		else
		{
			REQUIRED(1).checked			= true; 
		}

		if ( DISP == "NONE" )
		{
			DISPLAY(1).checked			= true; 
		}
		else
		{
			DISPLAY(0).checked			= true; 
		}
		
		if ( HELP_RET_INPUT_TYPE == "RADIO" )
		{
			HELP_RETURN_INPUT_TYPE(0).checked = true; 
		}
		else
		{
			HELP_RETURN_INPUT_TYPE(1).checked = true; 
		}
		
		DEFAULT_VALUE.value				= DEF_VAL; 
		DB_LIST_QUERIES.value			= CMB_QURY; 
		HELP_QUERIES.value				= HELP_QURY; 
		CONCATE_OPERATOR.value			= OPERATOR; 
		PARAMETER_DESCRIPTIONS.value	= PARAM_DESC;	

		//New.style.display = "none";
		Save.style.display = "";
		Delete.style.display = "";
		Save.value = "Update";
		DetailView.style.display = "none";
		DetailEntry.style.display = "";
		display_Input( REPORT_DETAIL_ENTRY , INPUTTYPE);
	}	
}

function	display_Input( form, input_Type)
{
	with ( form )
	{
		if ( input_Type == "HIDDEN" )
		{
			changeDisplay ( form, "Display" );
			changeDisplay ( form, "Help");
			TDDisplay.style.color="Gainsboro";
			DISPLAY[1].checked = true;
			DISPLAY[0].disabled = true;
			DISPLAY[1].disabled = true;
		}
		else if ( input_Type == "TEXT" || input_Type == "TEXTAREA" )
		{
			changeDisplay ( form, "Display" );
		}
		else if ( input_Type == "SELECT" )
		{
			changeDisplay ( form, "SystemValue");
			changeDisplay ( form, "Help");
		}
		else if ( input_Type == "RADIO" || input_Type == "CHECKBOX" )
		{
			changeDisplay ( form, "SystemValue");
			changeDisplay ( form, "Help");
			Fill_Cmb.style.color="Gainsboro";
			TDDbQuery.style.color="Gainsboro";
			DB_LIST_QUERIES.style.background = "Gainsboro";
			DB_LIST_QUERIES.disabled = true;
		}
	}
}

function	changeDisplay ( form, ObjType )
{
	with ( form )
	{
		if ( ObjType == "Display" )
		{
			DisplayType.style.color="Gainsboro";
			INPUT_TYPE_VALUE.disabled = true;
			INPUT_TYPE_TEXT.disabled = true;
			INPUT_TYPE_VALUE.style.background = "Gainsboro";
			INPUT_TYPE_TEXT.style.background = "Gainsboro";
		}
		if ( ObjType == "Help" )
		{
			HELP_SEL_QRY.style.color="Gainsboro";
			HELP_RETURN_INPUT_TYPE[0].disabled = true;
			HELP_RETURN_INPUT_TYPE[1].disabled = true;
			HELP_QUERIES.disabled = true;
			HELP_QUERIES.style.background = "Gainsboro";
		}
		if ( ObjType == "SystemValue" )
		{
			TDSysVal.style.color="Gainsboro";
			DEFAULT_VALUE.disabled = true;
			DEFAULT_VALUE.style.background = "Gainsboro";
		}	
	}	
}

function 	clear_Fields( form )
{
	with ( form )
	{
		reset();
		//SEQUENCE_ID.focus();
	}	
}

function	defaultStyle ( form )
{
	with ( form )
	{
		for ( i=0; i < elements.length; i++ )
		{
			elements[i].disabled = false;
			if ( elements[i].type == "text" )
			{
				elements[i].style.background = "White";
			}
		}
		HELP_QUERIES.style.background = "White";
		DB_LIST_QUERIES.style.background = "White";
		DisplayType.style.color="Navy";
		TDDisplay.style.color="Navy";
		HELP_SEL_QRY.style.color="Navy";
		TDSysVal.style.color="Navy";
		TDDbQuery.style.color="Navy";
		Fill_Cmb.style.color="Navy";
	}	
}

function 	reset_Form( form )
{
	with ( form )
	{
		//clear_Fields( form );
		defaultStyle( form );
		DetailView.style.display = "";
		DetailEntry.style.display = "none";
		//document.all("tblExample").rows(2).deleteCell(1)
	}
		//document.all.tags('TR').style.color="Red";
	
}
