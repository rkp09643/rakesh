		// CHECK THE FIELD IS NUMERIC OR NOT.
		function chkForNumeric(form, obj)
		{
			var objValue = obj.value;
			var objType = "";
			
			with(form)
			{
				// CHECK FIELD VALUE IS NUMERIC OR NOT, IF VALUE IS NOT EMPTY.
				if (objValue != "")
				{
					if (obj.name == "AdjustTo")
					{
						objValue = parseInt(objValue);
						objType = "IntegerField";
					}
					
					else
					{
						objValue = parseFloat(objValue);
						objType = "DoubleField";
					}
					
					// IF FIELD VALUE IS NOT NUMERIC, THEN ALERT THE USER.
					if ((isNaN(objValue) && objType == "IntegerField") || (isNaN(objValue) && objType == "DoubleField"))
					{
						if (obj.name == "SC")
							alert("'SC' should be float value.");
						
						else if (obj.name == "TOC1")
							alert("'TOC' should be float value.");
						
						else if (obj.name == "TOC2")
							alert("'TOC' should be float value.");
						
						else if (obj.name == "AdjustTo")
						{
							alert("'Adjust To' should be integer.");
							obj.value = 1;
						}
						
						// SET THE VALUE AND FOCUS OF THE FIELD.
						if (obj.name == "SC" || obj.name == "TOC1" || obj.name == "TOC2")
						{
							obj.value = 0;
							obj.focus();
						}
						
						else
						{
							obj.focus();
						}
					}
					
					// IF FIELD VALUE IS NUMERIC, THEN CHECK FOR THE FIELD VALIDITY.
					else
					{
						obj.value = objValue;
					}
				}
			}
		}
		
