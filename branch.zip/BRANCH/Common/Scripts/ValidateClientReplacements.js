function getClientName( form, clIDobj, objValue, clNameObj )
{
	with( form )
	{
		if( objValue != "" && objValue.charAt(0) != " " )
		{
			top.fraPaneBar.location.href	=	"/BRANCH/DynamicFrame/Fra_Hide.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&ValidateFor=ClientTradeReplacement&DocFormObject=top.Display.Reports.Details.document." +name +"&ClientID=" +objValue +"&CurrClientID=" +CurrClient.value +"&ClientIDObject=" +clIDobj.name  +"&ClientNameObject=" +clNameObj.name;
		}
	}
}