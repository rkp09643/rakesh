/* *************************************************************************
	FUNCTION FOR VALIDATING PASSWORD FIELD BEFORE SUBMITING THE FORM.
************************************************************************* */
function chkPassword( form )
{
	with( form )
	{
		obj = PwdForCompanyDeletion;
		pwd = PwdForCompanyDeletion.value;
		
		// CHECK FOR EMPTY PASSWORD FIELD.
		if( ( pwd == "" ) || ( pwd.charAt ( 0 ) == " " ) )
		{
			obj.focus();
			alert( "Please enter Password to proceed further." );
			return false;
		}
		// CHECK FOR CORRECT PASSWORD ( "Delete" ) VALUE.
		else
		{
			// IF IT'S INCORRECT PASSWORD, THEN ALERT THE USER WITH ERROR MESSAGE.
			if( pwd != "Delete" )
			{
				obj.value = "";
				obj.focus();
				alert( "You have entered Incorrect Password." );
				return false;
			}
			// IF IT'S CORRECT ONE, ALERT THE USER AND THEN ALLOW THEM TO DELETE THE COMPANY.
			else
			{
				if( ! confirm( "Do you really want to Delete this Company." ) )
				{
					return false;
				}
			}
		}
	}
}