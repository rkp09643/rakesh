/* ####################################################################################
					JAVASCRIPT FILE FOR OPENING/MAILING DERIVATIVES REPORTS.
#################################################################################### */


function setOnLoad( form, rptID )
{
	with( form )
	{
		msg.value	=	"";
		PrintDate.focus();
		
		if( rptID == 1 )// || ( rptID == 6 ) )
		{
			MailReport.style.display	=	"";
			SMSReport.style.display		=	"None";
		}
		else if( rptID == 2 )
		{
			MailReport.style.display	=	"";
			
			if( D.checked || S.checked )
			{
				SMSReport.style.display	=	"None";
			}
			else if( A.checked )
			{
				SMSReport.style.display	=	"";
			}
		}
		else
		{
			MailReport.style.display	=	"None";
			SMSReport.style.display		=	"None";
		}
	}
}


function openReports( form )
{
	with( form )
	{
		msg.value		=	"Please wait ....";
		commonParams	=	"?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value;
		
		//************************ REPORT 1: CONTRACT **********************
		if( ReportNo.value == 1 )
		{
			if( Selection[0].checked )
			{
				type				=	"Detail";
				
				if( parseInt( PaperSize.value ) == 0 )
				{
					title			=	"Contract Detail";
					templateName	=	"PrePrintedContract.cfm";
				}
				else
				{
					title			=	"Trade Done Detail";
					templateName	=	"ContractDetails.cfm";
				}
			}
			else if( Selection[1].checked )
			{
				title				=	"Trade Done Summary";
				type				=	"Summ";
				templateName		=	"ContractSummary.cfm";
			}

			if ( flgReportTextGenerate.value == "True" )
			{
				parent.Display.location.href	=	"/BRANCH/text_Reports/FO/PrePrintedContractText.cfm" +commonParams +"&Trade_Date=" +FromDate.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&ContractNo=" +ContractNo.value +"&BranchID=" +BranchID.value +"&Type=" +type +"&ReportType=" +PaperSize.value +"&Title=" +title +"&PrintDate=" +PrintDate.value +"&RepID="+ ReportNo.value;
			}
			else
			{
				parent.Display.location.href	=	"/BRANCH/Reports/FO/" +templateName +commonParams +"&Trade_Date=" +FromDate.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&ContractNo=" +ContractNo.value +"&BranchID=" +BranchID.value +"&Type=" +type +"&ReportType=" +PaperSize.value +"&Title=" +title +"&PrintDate=" +PrintDate.value +"&RepID="+ ReportNo.value;
			}	
		}


		//************************** REPORT 2: BILL ************************
		if( ReportNo.value == 2 )
		{			
			if( Selection[0].checked )
			{
				dateParam			=	"&Trade_Date=";
				type				=	"Detail";
				
				if( parseInt( PaperSize.value ) == 0 )
				{
					title			=	"Bill Detail";
					templateName	=	"PrePrintedBill.cfm";
				}
				else
				{
					title			=	"Bill Detail";
					templateName	=	"BillDetails.cfm";
				}
			}
			else if( Selection[1].checked )
			{
				dateParam			=	"&Trade_Date=";
				title				=	"Bill Summary";
				type				=	"Summ";
				templateName		=	"BillSummary.cfm";
			}
			else if( Selection[2].checked )
			{
				dateParam			=	"&FromDate=";
				title				=	"Bill Absolute Summary";
				type				=	"AbsSumm";
				templateName		=	"BillAbsSummary.cfm";
			}
			if( flgReportTextGenerate.value == "True" )
			{			
				parent.Display.location.href	=	"/BRANCH/Text_Reports/FO/PrePrintedBillText.cfm" +commonParams +dateParam +FromDate.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=" +BillNo.value +"&BranchID=" +BranchID.value +"&Type=" +type +"&ReportType=" +PaperSize.value +"&Title=" +title +"&PrintDate=" +PrintDate.value +"&RepID=" +ReportNo.value;
			}
			else
			{
				parent.Display.location.href	=	"/BRANCH/Reports/FO/" +templateName +commonParams +dateParam +FromDate.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=" +BillNo.value +"&BranchID=" +BranchID.value +"&Type=" +type +"&ReportType=" +PaperSize.value +"&Title=" +title +"&PrintDate=" +PrintDate.value +"&RepID=" +ReportNo.value;	
			}	
		}


		//*********************** REPORT 3: BROKERAGE **********************
		if( ReportNo.value == 3 )
		{
			if( ToDate.value == "" || ToDate.value.charAt(0) == " " )
			{
				toDate = ToDate.value;
			}
			else
			{
				toDate = ToDate.value;
			}
			
			if( Selection[0].checked )
			{
				parent.Display.location.href = "/BRANCH/Reports/FO/BrokerageDetails.cfm" +commonParams +"&FromDate="+ FromDate.value +"&ToDate=" +toDate + "&FamilyGroup=" + FamilyGroup.value + "&FromClient=" + escape( FromClient.value ) +"&ToClient=&BranchID=" + BranchID.value +"&type=Detail&PrintDate="+ PrintDate.value +"&RepID="+ ReportNo.value;
			}
			
			if( Selection[1].checked )
			{
				parent.Display.location.href = "/BRANCH/Reports/FO/BrokerageSummary.cfm" +commonParams +"&FromDate="+ FromDate.value +"&ToDate=" +toDate + "&FamilyGroup=" + FamilyGroup.value + "&FromClient=" + escape( FromClient.value ) +"&ToClient=&BranchID=" + BranchID.value +"&type=Summary&PrintDate="+ PrintDate.value +"&RepID="+ ReportNo.value;
			}
		}


		//************************ REPORT 4: EXPENSE ***********************
		if( ReportNo.value == 4 )
		{
			if( ToDate.value == "" || ToDate.value.charAt(0) == " " )
			{
				toDate = FromDate.value;
			}
			else
			{
				toDate = ToDate.value;
			}
			
			if( Selection[0].checked )
			{
				parent.Display.location.href	=	"/BRANCH/Reports/FO/ExpenseDetails.cfm" +commonParams +"&FromDate=" +FromDate.value +"&ToDate=" +toDate +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BranchID=" +BranchID.value +"&type=Detail&PrintDate=" +PrintDate.value +"&RepID=" +ReportNo.value;
			}
			
			if( Selection[1].checked )
			{
				parent.Display.location.href	=	"/BRANCH/Reports/FO/ExpenseSummary.cfm" +commonParams +"&FromDate=" +FromDate.value +"&ToDate=" +toDate +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BranchID=" +BranchID.value +"&type=Summary&PrintDate=" +PrintDate.value +"&RepID=" +ReportNo.value;
			}
		}


		//******************* REPORT 5: STAMP-DUTY PAYABLE *****************
		if( ReportNo.value == 5 )
		{
			if( ToDate.value == "" || ToDate.value.charAt(0) == " " )
			{
				toDate	=	FromDate.value;
			}
			else
			{
				toDate	=	ToDate.value;
			}
			
			if( Selection[0].checked )
			{
				v = "";
			}
			else if( Selection[1].checked )
			{
				v = "Y";
			}
			else if( Selection[2].checked )
			{
				v = "N";
			}
			
			parent.Display.location.href	=	"/BRANCH/Reports/FO/StampDutyPayable.cfm" +commonParams +"&FromDate=" +FromDate.value +"&ToDate=" +toDate +"&FromClient=" +v +"&PrintDate="+ PrintDate.value +"&RepID=" +ReportNo.value;
		}


		//********************* REPORT 6: O/S POSITION *********************
		if( ReportNo.value == 6 )
		{
			if( NonZero[0].checked )
			{
				nonZero		=	"Y";
			}
			else if( NonZero[1].checked )
			{
				nonZero		=	"N";
			}
			
			if( PrintType[0].checked )
			{
				printType	=	"P";
			}
			else if( PrintType[1].checked )
			{
				printType	=	"C";
			}
			
			if( Selection[0].checked )
			{
				title		=	"CLP O/S Position";
				osType		=	2;
			}
			else if( Selection[1].checked )
			{
				title		=	"O/S Position";
				osType		=	1;
			}

			parent.Display.location.href	=	"/BRANCH/Reports/FO/OSPosition.cfm" +commonParams +"&Branch_Code=" + Branch.value + "&Trade_Date=" +FromDate.value +"&FromClient=" +escape( FromClient.value ) +"&BranchID=" +BranchID.value +"&FromSymbol=" +escape( FromSymbol.value ) +"&ToSymbol=&Expiry=" +Expiry.value +"&LastTranDate=" +LastTranDate.value +"&NonZero=" +nonZero +"&Type=1&PrintDate=" +PrintDate.value +"&ReportType=75&OSType=" +osType +"&Title=" +title +"&PrintType=" +printType +"&RepID=" +ReportNo.value;
		}		
		//********************* REPORT 6: MULTI-DATE O/S POSITION *********************
		if( ReportNo.value == 24 )
		{
			if( PrintType[0].checked )
			{
				printType	=	"P";
			}
			else if( PrintType[1].checked )
			{
				printType	=	"C";
			}
			
			if ( flgReportTextGenerate.value == 'True' )
			{
				parent.Display.location.href	=	"/BRANCH/Text_Reports/FO/MultiDateOSPosition.cfm" +commonParams +"&FromDate=" +FromDate.value +"&ToDate=" +ToDate.value +"&FromClient=" +escape( FromClient.value ) +"&BranchID=" +BranchID.value +"&FromSymbol=" +escape( FromSymbol.value ) +"&ToSymbol=&Type=1&PrintDate=" +PrintDate.value +"&ReportType=75&OSType=1" +"&Title=Multi-Date O/S Position&PrintType=" +printType +"&RepID=" +ReportNo.value;
			}
			else
			{
				parent.Display.location.href	=	"/BRANCH/Reports/FO/MultiDateOSPosition.cfm" +commonParams +"&FromDate=" +FromDate.value +"&ToDate=" +ToDate.value +"&FromClient=" +escape( FromClient.value ) +"&BranchID=" +BranchID.value +"&FromSymbol=" +escape( FromSymbol.value ) +"&ToSymbol=&Type=1&PrintDate=" +PrintDate.value +"&ReportType=75&OSType=1" +"&Title=Multi-Date O/S Position&PrintType=" +printType +"&RepID=" +ReportNo.value;
			}
		}


		//******************** REPORT 7: SPREAD POSITION *******************
		if( ReportNo.value == 7 )
		{
			if( escape( FromClient.value ).length == 0 && escape( FromSymbol.value ).length == 0 )
			{
				if( Selection[0].checked )
				{
					title1 = "Client Spread Pos";
					title2 = "";
					
					parent.Display.location.href = "/BRANCH/Reports/FO/SpreadPosition.cfm?COCD="+ COCD.value + "&coname=" + CoName.value + "&market=" + Market.value + "&exchange=" + Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value + "&Trade_Date=" + FromDate.value + "&BranchID=" + BranchID.value + "&PrintDate="+ PrintDate.value +"&ReportType=25&OStype=2" +"&Title="+ title1+title2 +"&RepID="+ ReportNo.value;
				}
				if( Selection[1].checked )
				{
					title1 = "Scrip Spread Pos";
					title2 = "";
					
					parent.Display.location.href = "/BRANCH/Reports/FO/SpreadPosition.cfm?COCD="+ COCD.value + "&coname=" + CoName.value + "&market=" + Market.value + "&exchange=" + Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value + "&Trade_Date=" + FromDate.value + "&BranchID=" + BranchID.value + "&PrintDate="+ PrintDate.value +"&ReportType=75&OStype=1" +"&Title="+ title1+title2 +"&RepID="+ ReportNo.value;
				}
			}
			else
			{
				if( Selection[0].checked )
				{
					title1 = "Client Spread Pos";
					title2 = "";
					symbol = "";
					
					parent.Display.location.href = "/BRANCH/Reports/FO/SpreadPositionDetails2.cfm?COCD="+ COCD.value + "&coname=" + CoName.value + "&market=" + Market.value + "&exchange=" + Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value + "&FromClient=" + escape( FromClient.value ) + "&Scrip=&Trade_Date=" + FromDate.value + "&BranchID=" + BranchID.value + "&PrintDate="+ PrintDate.value +"&ReportType=25&OStype=2" +"&Title="+ title1+title2 +"&RepID="+ ReportNo.value;
				}
				if( Selection[1].checked )
				{
					title1 = "Scrip Spread Pos";
					title2 = "";
					symbol = new String( escape( FromSymbol.value ) );
					symbol = symbol.replace("&","*");
					
					parent.Display.location.href = "/BRANCH/Reports/FO/SpreadPositionDetails1.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&FromClient=&Scrip=" +symbol +"&Trade_Date=" +FromDate.value +"&BranchID=" +BranchID.value +"&PrintDate=" +PrintDate.value +"&ReportType=75&OStype=1" +"&Title=" +title1 +title2 +"&RepID=" +ReportNo.value;
				}
			}
		}


		//********************* REPORT 8: CHECK POSITION *******************
		if( ReportNo.value == 8 )
		{
			if( Selection[0].checked )
			{
				addParam = "&RptType=Client&";
			}
			else
			{
				addParam = "&RptType=Scrip&";
			}

			addParam = addParam + "&DispType=";
							
			if (DispType[0].checked)
			{
				addParam = addParam + "";
			}	
			else if (DispType[1].checked)
			{
				addParam = addParam + "Match";
			}
			else if (DispType[2].checked)
			{
				addParam = addParam + "MisMatch";
			}
			
			addParam = addParam + "&RptFlag=";
			
			if (ChkTrTypes[0].checked)
			{
				addParam = addParam + "&";
			}
			
			if (!ChkTrTypes[0].checked)
			{
				if (ChkTrTypes[1].checked)
				{
					addParam = addParam + "BF,";
				}
				if (ChkTrTypes[2].checked)
				{
					addParam = addParam + "SQRD,";
				}
				if (ChkTrTypes[3].checked)
				{
					addParam = addParam + "FUTTRD,";
				}	
				if (ChkTrTypes[4].checked)
				{
					addParam = addParam + "OPTTRD,";
				}
				if (ChkTrTypes[5].checked)
				{
					addParam = addParam + "PREEXASG,";
				}
				if (ChkTrTypes[6].checked)
				{
					addParam = addParam + "EXASG";
				}
			}

			if( Process.value == "Yes" )
			{
				parent.Display.location.href	=	"/BRANCH/Reports/FO/CheckPosition.cfm?Process=Yes&COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&Trade_Date=" +FromDate.value + addParam +"&PrintDate=" +PrintDate.value +"&RepID=" +ReportNo.value;
			}	
			else
			{
				parent.Display.location.href	=	"/BRANCH/Reports/FO/CheckPosition.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&Trade_Date=" +FromDate.value + addParam +"&PrintDate=" +PrintDate.value +"&RepID=" +ReportNo.value;
			}
			//parent.Display.location.href = "/BRANCH/Reports/FO/CheckPosition.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&FromDate=" +FromDate.value +"&ReportType=S&PrintDate=" +PrintDate.value +"&RepID=" +ReportNo.value;
		}


		//********************* REPORT 9: CLIENT MARGIN *******************
		if(ReportNo.value == 9)
		{
			parent.Display.location.href = "/BRANCH/Reports/FO/ClientMargin.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&FromDate=" +FromDate.value +"&PrintDate=" +PrintDate.value +"&RepID=" +ReportNo.value;
		}

		//****************** REPORT 10: REMESHIRE BROKERAGE ****************
		if(ReportNo.value == 10)
		{
			if( ToDate.value == "" || ToDate.value.charAt(0) == " " )
			{
				toDate = FromDate.value;
			}
			else
			{
				toDate = ToDate.value;
			}
			
			parent.Display.location.href = "/BRANCH/Reports/FO/RemeshireReport.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&FromDate=" +FromDate.value +"&ToDate=" +toDate +"&RemGroup=" +RemGroup.value +"&PrintDate=" +PrintDate.value +"&RepID=" +ReportNo.value;
		}


		//*********************** REPORT 11: SAUDA BOOK ********************
		if(ReportNo.value == 11)
		{
			if( ToDate.value == "" || ToDate.value.charAt(0) == " " )
			{
				toDate = FromDate.value;
			}
			else
			{
				toDate = ToDate.value;
			}
			
			parent.Display.location.href = "/BRANCH/Reports/FO/TransRegParam.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&FromDate=" +FromDate.value +"&ToDate=" +toDate +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BranchID=" +BranchID.value +"&FromSymbol=" +escape( FromSymbol.value ) +"&ToSymbol=&ExpiryDate=" +Expiry.value +"&Terminal=" +"&PrintDate=" +PrintDate.value +"&RepID=" +ReportNo.value;
		}


		//*********************** REPORT 12: ANNUAL PROFIT OR LOSS ********************
		if(ReportNo.value == 12)
		{
			if( escape( FromClient.value ) == "" || escape( FromClient.value ).charAt(0) == " " )
			{
				alert( "Please enter 'Client ID'." );
			}
			else
			{
				if( FromDate.value == "" || FromDate.value.charAt(0) == " " )
				{
					alert( "Please enter 'Date'." );
				}
				else
				{
				if( Selection[0].checked )	v = "1";
				if( Selection[1].checked )	v = "2";

				parent.Display.location.href = "/BRANCH/REPORTS/MIS/AnnualProfitLoss.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&FromDate=" +FromDate.value +"&FromClient=" +escape( FromClient.value ) +"&type=" +v +"&PrintDate=" +PrintDate.value +"&RepID=" +ReportNo.value;
				}
			}
		}


		//*********************** REPORT 13: MULTI-REPORT ********************
		if(ReportNo.value == 13)
		{
			if( ToDate.value == "" || ToDate.value.charAt(0) == " " )
			{
				toDate = FromDate.value;
			}
			else
			{
				toDate = ToDate.value;
			}
			
			parent.Display.location.href = "/BRANCH/Reports/FO/MultiReportParams.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&FromDate=" +FromDate.value +"&ToDate=" +toDate +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BranchID=" +BranchID.value +"&PrintDate=" +PrintDate.value +"&RepID=" +ReportNo.value;
		}

		//********************* REPORT 14: CLIENT SHORT MARGIN *******************
		if(ReportNo.value == 14)
		{
			parent.Display.location.href = "/BRANCH/Reports/FO/ClientShortMargin.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&FromDate=" +FromDate.value +"&PrintDate=" +PrintDate.value +"&RepID=" +ReportNo.value;
		}
		
		//*********************** REPORT 15: CONTRACT-REGISTER ********************
		if( ReportNo.value == 15 )
		{
			if( ToDate.value == "" || ToDate.value.charAt(0) == " " )
			{
				toDate = FromDate.value;
			}
			else
			{
				toDate = ToDate.value;
			}
			
			parent.Display.location.href = "/BRANCH/REPORTS/FO/ContractRegister.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&FromDate=" +FromDate.value +"&ToDate=" +toDate +"&FromClient=" +escape( FromClient.value ) +"&BranchID=&PrintDate=" +PrintDate.value +"&RepID=" +ReportNo.value;
		}


		//*********************** REPORT 16: BILL-JV DATA ********************
		if( ReportNo.value == 16 )
		{
			dispType	=	"Net";
			if( optDisplay[0].checked )	dispType = "Net";
			if( optDisplay[1].checked )	dispType = "Margin";
			parent.Display.location.href = "/BRANCH/REPORTS/FO/ViewBillForm.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value + "&FROM_DATE=" + FromDate.value +"&BranchID=&Display=" + dispType +"&PrintDate=" +PrintDate.value +"&RepID=" +ReportNo.value;
		}


		//*********************** REPORT 20: MIS CLIENT-BALANCE ********************
		if( ReportNo.value == 20 )
		{
			parent.Display.location.href = "/BRANCH/REPORTS/MIS/ClientBalance.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value + "&FROM_CLIENT=" + escape( FromClient.value ) + "&BILL_DATE=" + FromDate.value +"&BranchID=&PrintDate=" +PrintDate.value +"&RepID=" +ReportNo.value;
		}


		//*********************** REPORT 21: MIS NET BROKERAGE ********************
		if( ReportNo.value == 21 )
		{
			parent.Display.location.href = "/BRANCH/REPORTS/MIS/NetBrokerage.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value + "&FROM_CLIENT=" + escape( FromClient.value ) + "&FROM_DATE=" + FromDate.value + "&TO_DATE=" + ToDate.value +"&BranchID=&PrintDate=" +PrintDate.value +"&RepID=" +ReportNo.value;
		}


		//*********************** REPORT 22: MIS BROKERAGE STATUS ********************
		if( ReportNo.value == 22 )
		{
			if( Selection[0].checked )	v = "D";
			if( Selection[1].checked )	v = "M";
			if( Selection[2].checked )	v = "Q";
			if( Selection[3].checked )	v = "Y";

			parent.Display.location.href = "/BRANCH/REPORTS/MIS/BrokerageStatus.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value + "&FROM_CLIENT=" + escape( FromClient.value ) + "&FROM_DATE=" + FromDate.value + "&TO_DATE=" + ToDate.value + "&TYPE=" + v +"&BranchID=&PrintDate=" +PrintDate.value +"&RepID=" +ReportNo.value;
		}


		//****************** REPORT 23: COLLATERAL ****************
		if( ReportNo.value == 23 )
		{
			if( ShowMargin.checked )
			{
				showMargin = "Y";
			}
			else
			{
				showMargin = "N";
			}
			
			if( FromDate.value == "" || FromDate.value.charAt(0) == " " )
			{
				alert( "Please enter 'Date'." );
				FromDate.focus()
			}
			else
			{
				parent.Display.location.href = "/BRANCH/Reports/FO/CollateralReport.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&Date=" +FromDate.value +"&CLIENT=" +escape( FromClient.value ) +"&showMargin=" + showMargin +"&PrintDate=" +PrintDate.value +"&RepID=" +ReportNo.value;
			}	
		}


		//******************* REPORT 25: SERVICE-TAX PAYABLE *****************
		if( ReportNo.value == 25 )
		{
			if( PeriodSelection[0].checked )
			{
				periodSelection	=	PeriodSelection[0].value;
				monthDate		=	CmbPeriod.value;
				
				frDate			=	"";
				toDate			=	"";
			}
			else if( PeriodSelection[1].checked )
			{
				periodSelection	=	PeriodSelection[1].value;
				monthDate		=	"";
				
				if( ToDate.value == "" || ToDate.value.charAt(0) == " " )
				{
					frDate		=	FromDate.value;
					toDate		=	FromDate.value;
				}
				else
				{
					frDate		=	FromDate.value;
					toDate		=	ToDate.value;
				}
			}
			
			if( ShowOptionalCols.checked )
			{
				showOptionalCols	=	"Y";
			}
			else
			{
				showOptionalCols	=	"N";
			}
			
			parent.Display.location.href	=	"/BRANCH/Reports/ServiceTaxPayable.cfm" +commonParams +"&PeriodSelection=" +periodSelection +"&MonthDate=" +monthDate +"&FromDate=" +frDate +"&ToDate=" +toDate +"&ClientSelection=" +ClientSelection.value +"&ShowOptionalCols=" +showOptionalCols +"&PrintDate=" +PrintDate.value +"&RepID=" +ReportNo.value;
		}
		
		if(ReportNo.value == 32)
		{
			parent.Display.location.href = "/BRANCH/Reports/FO/ClientWiseMargin4.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&PrintDate=" +PrintDate.value +"&RepID=" +ReportNo.value +"&ToDate="+ToDate.value +"&FromClient="+FromClient.value;
		}

		//*************************** REPORT ***********************
	}
}


function emailReports( form )
{
	if( confirm( "Do you want to add any additional information to the E-Mail Message?." ) )
	{
		mailMsg = prompt( "Enter your Message.", "" );
		
		if( ( mailMsg != null ) && ( mailMsg != "" ) && ( mailMsg.charAt(0) != " " ) )
		{
			mailMsg = mailMsg;
		}
		else
		{
			mailMsg = "";
		}
	}
	else
	{
		mailMsg = "";
	}
	
	with( form )
	{
		msg.value = "Mailing Report ......";

		//************************ REPORT 1: CONTRACT **********************
		if( ReportNo.value == 1 )
		{
			title1 = "Trade Done ";
			
			if( Selection[0].checked )
			{
				title2 = "Detail";
				
				parent.Display.location.href = "/BRANCH/Reports/ContractMail.cfm?COCD=" +COCD.value +"&coname=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&Trade_Date=" +FromDate.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&ContractNo=" +ContractNo.value +"&BranchID=" +BranchID.value +"&BranchID=" +BranchID.value +"&Type=Detail&PrintDate=" +PrintDate.value +"&ReportType=" +PaperSize.value +"&Title=" +title1 +title2 +"&RepID=" +ReportNo.value +"&EMail=Yes&MessageType=EMail&MailMessage=" +mailMsg;
			}
			if( Selection[1].checked )
			{
				title2 = "Summary";
				
				parent.Display.location.href = "/BRANCH/Reports/ContractMail.cfm?COCD=" +COCD.value +"&coname=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&Trade_Date=" +FromDate.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&ContractNo=" +ContractNo.value +"&BranchID=" +BranchID.value +"&BranchID=" +BranchID.value +"&Type=Summ&PrintDate=" +PrintDate.value +"&ReportType=" +PaperSize.value +"&Title=" +title1 +title2 +"&RepID=" +ReportNo.value +"&EMail=Yes&MessageType=EMail&MailMessage=" +mailMsg;
			}
		}


		//************************** REPORT 2: BILL ************************
		if( ReportNo.value == 2 )
		{			
			title1 = "Bill ";
			
			if( Selection[0].checked )
			{
				title2 = "Detail";
				
				parent.Display.location.href = "/BRANCH/Reports/BillMail.cfm?COCD=" +COCD.value +"&coname=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&Trade_Date=" +FromDate.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=" +BillNo.value +"&BranchID=" +BranchID.value +"&Type=Detail&PrintDate=" +PrintDate.value +"&ReportType=" +PaperSize.value +"&Title=" +title1 +title2 +"&RepID=" +ReportNo.value +"&EMail=Yes&MessageType=EMail&MailMessage=" +mailMsg;
			}
			if( Selection[1].checked )
			{
				title2 = "Summary";
				
				parent.Display.location.href = "/BRANCH/Reports/BillMail.cfm?COCD=" +COCD.value +"&coname=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&Trade_Date=" +FromDate.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=" +BillNo.value +"&BranchID=" +BranchID.value +"&Type=Summ&PrintDate=" +PrintDate.value +"&ReportType=" +PaperSize.value +"&Title=" +title1 +title2 +"&RepID=" +ReportNo.value +"&EMail=Yes&MessageType=EMail&MailMessage=" +mailMsg;
			}
			if( Selection[2].checked )
			{
				title2 = "Absolute Summary";
				
				parent.Display.location.href = "/BRANCH/Reports/BillMail.cfm?COCD=" +COCD.value +"&coname=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&FromDate=" +FromDate.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=" +BillNo.value +"&BranchID=" +BranchID.value +"&Type=AbsSumm&PrintDate=" +PrintDate.value +"&ReportType=" +PaperSize.value +"&Title=" +title1 +title2 +"&RepID=" +ReportNo.value +"&EMail=Yes&MessageType=EMail&MailMessage=" +mailMsg;
			}
		}


		//********************* REPORT 6: O/S POSITION *********************
		if( ReportNo.value == 6 )
		{
			if( NonZero[0].checked ) nonZero = "Y";
			if( NonZero[1].checked ) nonZero = "N";
			
			if( Selection[0].checked )
			{
				title1 = "CLP O/S Position";
				title2 = "";
				
				parent.Display.location.href = "/BRANCH/Reports/OSPositionMail.cfm?COCD=" +COCD.value +"&coname=" +CoName.value +"&market=" +Market.value +"&exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&Trade_Date=" +FromDate.value +"&FromClient=" +escape( FromClient.value ) +"&BranchID=" +BranchID.value +"&FromSymbol="+escape( FromSymbol.value ) +"&ToSymbol=&Expiry=" +Expiry.value +"&LastTranDate=" +LastTranDate.value +"&NonZero=" +nonZero +"&Type=1&PrintDate=" +PrintDate.value +"&ReportType=75&OSType=2" +"&Title=" +title1 +title2 +"&RepID="+ReportNo.value +"&EMail=Yes&MessageType=EMail&MailMessage=" +mailMsg;
			}
			if( Selection[1].checked )
			{
				title1 = "O/S Position";
				title2 = "";
				
				parent.Display.location.href = "/BRANCH/Reports/OSPositionMail.cfm?COCD=" +COCD.value +"&coname=" +CoName.value +"&market=" +Market.value +"&exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&Trade_Date=" +FromDate.value +"&FromClient=" +escape( FromClient.value ) +"&BranchID=" +BranchID.value +"&FromSymbol="+escape( FromSymbol.value ) +"&ToSymbol=&Expiry=" +Expiry.value +"&LastTranDate=" +LastTranDate.value +"&NonZero=" +nonZero +"&Type=1&PrintDate=" +PrintDate.value +"&ReportType=75&OSType=1" +"&Title=" +title1 +title2 +"&RepID="+ReportNo.value +"&EMail=Yes&MessageType=EMail&MailMessage=" +mailMsg;
			}
		}
	}
}


function smsReports( form )
{
	with( form )
	{
		//************************** REPORT 2: BILL ************************
		if( ReportNo.value == 2 )
		{
			title	=	"Bill Absolute Summary";
			
			if( Selection[2].checked )
			{
				parent.Display.location.href = "/BRANCH/Reports/FO/BillAbsSMS.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&FromDate=" +FromDate.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=" +BillNo.value +"&BranchID=" +BranchID.value +"&Type=AbsSumm&PrintDate=" +PrintDate.value +"&ReportType=" +PaperSize.value +"&Title=" +title +"&RepID=" +ReportNo.value +"&EMail=Yes&MessageType=SMS";
			}
		}
	}
}