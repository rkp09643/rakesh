/*###############################################################################################
					JAVASCRIPT FILE FOR VALIDATING THE NUMERIC FORM FIELDS.
###############################################################################################*/


// *********************************
	// FUNCTION FOR SETTING VALUE.
// *********************************
function setValue ( fieldName, fieldValue )
{
	if ( ( fieldName == "ModuleNo" ) || ( fieldName == "SettlementPeriod" ) || ( fieldName == "AdjustTo" ) )
	{
		return parseInt ( fieldValue );
	}
	
	else
	{
		return parseFloat ( fieldValue );
	}
}

// ********************************************************
	// MAIN FUNCTION FOR VALIDATING NUMERIC FORM FIELDS.
// ********************************************************
function chkForNumeric( form, obj )
{
	var objValue = obj.value;
	
	with( form )
	{
		// ******************************************************************
			// CHECK FIELD VALUE IS NUMERIC OR NOT, IF VALUE IS NOT EMPTY.
		// ******************************************************************
		if( objValue != "" )
		{
			// ***************************************************
				// CALL THE FUNCTION "setValue()" TO SET VALUE.
			// ***************************************************
			objValue = setValue ( obj.name, objValue );
			
			// *********************************************************
				// IF FIELD VALUE IS NOT NUMERIC, THEN ALERT THE USER.
			// *********************************************************
			if( isNaN( objValue ) )
			{
				// **********************************************************
					// THE FOLLOWING ARE FIELDS OF "NewClientDetailsForm".
				// **********************************************************
				if ( obj.name == "AnnualIncome" )
				{
					alert ( "'Annual Income' should be a float value." );
				}
				
				// *************************************************************
					// THE FOLLOWING ARE FIELDS OF "BrokerageApplicationForm".
				// *************************************************************
				else if ( obj.name == "JobberPer" )
				{
					alert ( "'Jobber %' should be a float value." );
				}
				
				// ********************************************************************************
					// THE FOLLOWING ARE FIELDS OF "BrokerageMasterForm" and "ExpenseMasterForm".
				// ********************************************************************************
				else if ( obj.name == "ModuleNo" )
				{
					alert ( "'Module No' should be an integer value." );
					obj.value = "";
				}
				
				// **********************************************************
					// THE FOLLOWING ARE FIELDS OF "BrokerageDetailsForm".
				// **********************************************************
				else if ( obj.name == "FromTurnOver" )
				{
					alert ( "'From Turn-Over' should be a float value between 0 and 999999999." );
				}
				
				else if ( obj.name == "ToTurnOver" )
				{
					alert ( "'To Turn-Over' should be a float value between 0 and 999999999." );
					obj.value = 999999999;
				}
				
				else if ( obj.name == "FromPrice" )
				{
					alert ( "'From Price' should be a float value between 0 and 999999." );
				}
				
				else if ( obj.name == "ToPrice" )
				{
					alert ( "'To Price' should be a float value between 0 and 999999." );
					obj.value = 999999;
				}
				
				else if ( obj.name == "OneSidePer" )
				{
					alert ( "'One-Side Per(%)' should be a float value." );
				}
				
				else if ( obj.name == "OneSideMin" )
				{
					alert ( "'One-Side Minimum' should be a float value." );
				}
				
				else if ( obj.name == "OtherSidePer" )
				{
					alert ( "'Other-Side Per(%)' should be a float value." );
				}
				
				else if ( obj.name == "OtherSideMin" )
				{
					alert ( "'Other-Side Minimum' should be a float value." );
				}
				
				else if ( obj.name == "DeliveryPer" )
				{
					alert ( "'Delivery Per(%)' should be a float value." );
				}
				
				else if ( obj.name == "DeliveryMin" )
				{
					alert ( "'Delivery Minimum' should be a float value." );
				}
				
				else if ( obj.name == "SettlementPer" )
				{
					alert ( "'Settlement Per(%)' should be a float value." );
				}
				
				else if ( obj.name == "SettlementMin" )
				{
					alert ( "'Settlement Minimum' should be a float value." );
				}
				
				else if ( obj.name == "SettlementPeriod" )
				{
					alert ( "'Settlement Period' should be an integer value." );
				}
				
				// *******************************************************
					// THE FOLLOWING ARE FIELDS OF "ServiceChargeForm".
				// *******************************************************
				else if ( obj.name == "SC" )
				{
					alert ( "'SC' should be a float value." );
				}
				
				// *******************************************************
					// THE FOLLOWING ARE FIELDS OF "TurnOverChargeForm".
				// *******************************************************
				else if ( obj.name == "TOC1" )
				{
					alert ( "'TOC' should be a float value." );
				}
				
				else if ( obj.name == "TOC2")
				{
					alert ( "'TOC' should be a float value." );
				}
				
				// *******************************************************
					// THE FOLLOWING ARE FIELDS OF "ExpenseDetailsForm".
				// *******************************************************
				else if ( obj.name == "CAPSExp" )
				{
					alert ( "'Expense Per(%)' should be a float value." );
				}
				
				else if ( obj.name == "FuturesExp" )
				{
					alert ( "'Futures Exp Per(%)' should be a float value." );
				}
				
				else if ( obj.name == "OptionsExpForTN" )
				{
					alert ( "'Options Exp For TN Per(%)' should be a float value." );
				}
				
				else if ( obj.name == "OptionsExpForTAE" )
				{
					alert ( "'Options Exp For TAE Per(%)' should be a float value." );
				}
				
				// *****************************************************************************
					// THE FOLLOWING ARE FIELDS OF "ServiceChargeForm", "TurnOverChargeForm" 
					// and "ExpenseDetailsForm".
				// *****************************************************************************
				else if ( obj.name == "AdjustTo" )
				{
					alert ( "'Adjust To' should be an integer value." );
					obj.value = 1;
				}
				
				// ********************************************
					// SET THE VALUE AND FOCUS OF THE FIELD.
				// ********************************************
				if (
						( obj.name == "AnnualIncome" ) || ( obj.name == "JobberPer" ) || 
						( obj.name == "FromTurnOver" ) || ( obj.name == "FromPrice" ) || 
						( obj.name == "OneSidePer" ) || ( obj.name == "OneSideMin" ) || 
						( obj.name == "OtherSidePer" ) || ( obj.name == "OtherSideMin" ) || 
						( obj.name == "DeliveryPer" ) || ( obj.name == "DeliveryMin" ) || 
						( obj.name == "SettlementPer" ) || ( obj.name == "SettlementMin" ) || 
						( obj.name == "SettlementPeriod" ) || 
						( obj.name == "SC" ) || ( obj.name == "TOC1" ) || ( obj.name == "TOC2" ) || 
						( obj.name == "CAPSExp" ) || ( obj.name == "FuturesExp" ) || 
						( obj.name == "OptionsExpForTN" ) || ( obj.name == "OptionsExpForTAE" )
					)
				{
					obj.value = 0;
					obj.focus ();
				}
				
				else
				{
					obj.focus ();
				}
			}
			
			// *******************************************************************
				// IF FIELD VALUE IS NUMERIC, THEN CHECK FOR THE FIELD VALIDITY.
			// *******************************************************************
			else
			{
				obj.value = objValue;
				
				// ***************************************************************
					// CHECK FOR FIELD "JobberPer", IT SHOULD BE MORE THAN "Zero".
				// ***************************************************************
				if  (
						( obj.name == "JobberPer" ) || 
						( obj.name == "OneSidePer" ) || ( obj.name == "OtherSidePer" ) || 
						( obj.name == "DeliveryPer" ) || ( obj.name == "SettlementPer" )
					)
				{
					if ( objValue > 100 )
					{
						alert ( "% Value should be less than 100." );
						obj.value = 0;
						obj.focus ();
					}
				}
				
				// ***************************************************************
					// CHECK FOR FIELD "ModuleNo", IT SHOULD BE MORE THAN "Zero".
				// ***************************************************************
				else if ( ( obj.name == "ModuleNo" ) && ( objValue == 0 ) )
				{
					alert ( "'Module No' should be more than Zero." );
					obj.value = "";
					obj.focus ();
				}
				
				// *****************************************************************************
					// CHECK FOR FIELD "ToTurnOver", IT SHOULD BE GREATER THAN "FromTurnOver".
				// *****************************************************************************
				else if ( obj.name == "ToTurnOver" )
				{
					if ( objValue < ( parseFloat ( FromTurnOver.value ) ) )
					{
						alert ( "'To Turn-Over' should be more than 'From Turn-Over'" );
						
						obj.value = 999999999;
						obj.focus ();
					}
				}
				
				// ************************************************************************
					// CHECK FOR FIELD "ToPrice", IT SHOULD BE GREATER THAN "FromPrice".
				// ************************************************************************
				else if ( obj.name == "ToPrice" )
				{
					if ( objValue < ( parseFloat ( FromPrice.value ) ) )
					{
						alert ( "'To Price' should be more than 'From Price" );
						
						obj.value = 999999;
						obj.focus ();
					}
				}
			}
		}
	}
}