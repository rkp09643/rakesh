// JavaScript Document
function PopulateForm(FromDate, Client_ID, CName, Margin, ReportedMargin, Narr, DrMargin, CrMargin, NetMargin, LedBal, LedBalType, DrTransaction, CrTransaction, PriorLedBal, PriorLedBalType, AssociateMarginCode, AssLedBal, AssLedBalType, FUT, BOPT, SOPT, OPT, EXP, BalAmt, BalAmtType, Billable, BNO, CollateralAmt)
{
	MarginStatusData.style.height = "37%";
	priorBill = parseFloat(new Number(PriorLedBal));
	billType = "";
	NetBillAmt = parseFloat(new Number(BalAmt + NetMargin));
	if(Billable == 'N')
	{
		DrMargin = 0;
		CrMargin = 0;
		NetMargin = 0;
	}
							 
	with(MarginForm)
	{
		ChkLedBal.checked = false;
		ChkAssociateBal.checked = false;
		ChkColl.checked = false;
		ChkMarginDrAmt.checked = false;
		ChkBillAmount.checked = false;
		ChkDrTrans.checked = false;
		ChkOpLedBal.checked = true;
		ChkMarginCrAmt.checked = true;
		ChkCrTrans.checked = true;
		
		Mrg.value = Billable;
		
		//FILL CLIENT ID, Name And Title
		FROMDATE.value				= FromDate;
		client.value				= Client_ID;
		Client.innerText			= Client_ID;
		ClientName.innerText		= " " + CName;
		AssociateTitle.innerText	= "Associated Ledger Balance "
		AssociateTitle.innerText	= AssociateTitle.innerText + AssociateMarginCode + " : ";
		LedgerClosingBalance.innerText	= "LedgerBalance as on " + FROMDATE.value + " : " + LedBal + "  " + LedBalType;		
		//FILL BILL NO
		
		if ( BNO > 0 )
		{
			BillNo.innerText		=  BNO;
		}
		else
		{
			BillNo.innerText		= "Not Billed";
		}	

		//ClientMarginQuery.location.href = "ClientMarginQueryForOutput.cfm?Cocd=ManaliFo&ClientID="+ Client_Id + "&FromDate=" + FromDate;
		//FILL FUTURE MTM, EXP. AND MARGIN
		FutMtm.innerText 		= Math.abs(FUT);
		if ( FUT < 0 )
		{
			FutMtm.innerText	= FutMtm.innerText + " DR"
		}
		else
		{
			FutMtm.innerText	= FutMtm.innerText + " CR"
		}
		
		NetPre.innerText		= Math.abs(OPT);
		if ( OPT < 0 )
		{
			NetPre.innerText	= NetPre.innerText + " DR"
		}
		else
		{
			NetPre.innerText	= NetPre.innerText + " CR"
		}
		
		NetMarg.innerText		= Math.abs(NetMargin);
		if ( NetMargin < 0 )
		{
			NetMarg.innerText	= NetMarg.innerText + " DR"
		}
		else
		{
			NetMarg.innerText	= NetMarg.innerText + " CR"
		}

		BuyPre.innerText		= BOPT + " DR";
		SalePre.innerText		= SOPT + " CR";
		Exp.innerText			= EXP + " DR";
		DrMarg.innerText		= DrMargin + " DR";
		CrMarg.innerText		= CrMargin + " CR";
		margin.value			= parseFloat(Margin);
		Reported_Margin.value	= parseFloat(ReportedMargin);
		Narration.value			= Narr;
		Bal.innerText 			= parseFloat(BalAmt) + " "  + BalAmtType;
		Net.innerText			= Math.abs(NetBillAmt);

		if ( NetBillAmt < 0 )
		{
			Net.innerText	= Net.innerText + " DR"
		}
		else
		{
			Net.innerText	= Net.innerText + " CR"
		}

		LedgerOpeningBalance.innerText = priorBill + " " + PriorLedBalType;
		ChkOpLedBal.value = priorBill;
		ChkOpLedBalType.value = PriorLedBalType;
		
		MarginDrAmt.innerText = parseFloat(DrMargin) + " DR";
		ChkMarginDrAmt.value = parseFloat(DrMargin);
		
		MarginCrAmt.innerText = parseFloat(CrMargin) + " CR";
		ChkMarginCrAmt.value = parseFloat(CrMargin);
		
		BillAmount.innerText =  parseFloat(BalAmt) + " "  + BalAmtType;
		ChkBillAmount.value = parseFloat(BalAmt)
		
		DrTrans.innerText = parseFloat(DrTransaction) + " DR";
		ChkDrTrans.value = parseFloat(DrTransaction);
		
		CrTrans.innerText = parseFloat(CrTransaction) + " CR";
		ChkCrTrans.value = parseFloat(CrTransaction);
		
		if ( PriorLedBalType == "DR")
		{	
			priorBill = CrMargin + parseFloat(CrTransaction) - priorBill;
		}
		if ( PriorLedBalType == "CR")
		{
			priorBill = CrMargin + parseFloat(CrTransaction) + priorBill;
		}
		
		if ( priorBill >= 0 )
		{
			billType = "CR";
		}
		else
		{
			billType = "DR";
		}

		LedgerBalance.innerText = Math.abs(priorBill) + " " + billType;
		selTotalBalance.innerText = parseFloat(LedgerBalance.innerText);
		
		HidLedgerBal.value = Math.abs(priorBill);
		HidLedgerBalType.value = billType;
		ChkLedBal.value = Math.abs(priorBill);
		ChkAssociateBal.value  = AssLedBal;
		AssociatedLedgerBalance.innerText = AssLedBal + " " + AssLedBalType;
		CollAmt.innerText = CollateralAmt + " " + "CR";
		ChkColl.value = CollateralAmt;

		if (billType == "DR")
		{
			ChkLedBal.disabled = true;
		}
		else
		{
			ChkLedBal.disabled = false;
		}
		
		if (AssLedBalType == "DR")
		{
			ChkAssociateBal.disabled = true;
		}
		else
		{
			ChkAssociateBal.disabled = false;
		}
		
		TotalAmount.innerText = "";
		TotalAmt.value = 0
		NetAmt.innerText = "";
		InitMar.innerText = parseFloat(Margin) + " DR";
		InitialMargin.value = parseFloat(Margin);
		Reported_Margin.focus();
	}
}

function validReportedMargin( form )
{
	with ( form )
	{
		ReportedMargin = parseFloat(new Number(Reported_Margin.value));
		Margin = parseFloat(new Number(margin.value));
		
		if ( ReportedMargin > Margin )
		{
			alert("'Reported Margin' should not exceed 'Initial Margin'.\n Please change value.")
			Reported_Margin.value = margin.value
			Reported_Margin.focus()
		}
	}	
}

function	setBalance( Form )
{
	with ( Form )
	{	
		//initMrg = parseFloat(new Number(InitialMargin.value));
		seltotAmt = 0;
		seltotAmtType = ChkOpLedBalType.value;
		TotalAmt.value = 0;
		
		if ( seltotAmtType == "" )
		{
			seltotAmtType = "DR";
		}
		
		if (ChkOpLedBal.checked)
		{
			seltotAmt = parseFloat(ChkOpLedBal.value);
		}
		
		if (ChkMarginDrAmt.checked)
		{
			if ( seltotAmtType == "DR" )
			{
				seltotAmt = seltotAmt + parseFloat(ChkMarginDrAmt.value);
			}
			else
			{
				seltotAmt = seltotAmt - parseFloat(ChkMarginDrAmt.value);
			}
		}
		
		if (ChkMarginCrAmt.checked)
		{
			if ( seltotAmtType == "DR" )
			{
				seltotAmt = seltotAmt - parseFloat(ChkMarginCrAmt.value);
			}
			else
			{
				seltotAmt = seltotAmt + parseFloat(ChkMarginCrAmt.value);
			}
		}
		
		if ( ChkBillAmount.checked )
		{
			if ( ChkBillAmountType.value == "DR" )
			{
				if ( seltotAmtType == "DR" )
				{
					seltotAmt = seltotAmt + parseFloat(ChkBillAmount.value);
				}
				else
				{
					seltotAmt = seltotAmt - parseFloat(ChkBillAmount.value);
				}
			}
			else
			{
				if ( seltotAmtType == "DR" )
				{
					seltotAmt = seltotAmt - parseFloat(ChkBillAmount.value);
				}
				else
				{
					seltotAmt = seltotAmt + parseFloat(ChkBillAmount.value);
				}
			}
		}
		
		if (ChkDrTrans.checked)
		{
			if ( seltotAmtType == "DR" )
			{
				seltotAmt = seltotAmt + parseFloat(ChkDrTrans.value);
			}
			else
			{
				seltotAmt = seltotAmt - parseFloat(ChkDrTrans.value);
			}
		}
		
		if (ChkCrTrans.checked)
		{
			if ( seltotAmtType == "DR" )
			{
				seltotAmt = seltotAmt - parseFloat(ChkCrTrans.value);
			}
			else
			{
				seltotAmt = seltotAmt + parseFloat(ChkCrTrans.value);
			}
		}
		
		seltotAmt = parseInt(seltotAmt);
		ChkLedBal.value = 0;
		ChkLedBal.disabled = false;
	 
		if ( seltotAmt < 0 )
		{
			if (seltotAmtType == "DR") 
			{
				LedgerBalance.innerText = Math.abs(seltotAmt) + " CR";
				ChkLedBal.value = parseFloat(Math.abs(seltotAmt));
			}
			else
			{
				LedgerBalance.innerText = Math.abs(seltotAmt) + " DR";
				ChkLedBal.value = parseFloat(seltotAmt);
				ChkLedBal.disabled = true;
			}	
		}				
		else
		{
			LedgerBalance.innerText = Math.abs(seltotAmt) + " " + seltotAmtType; 
			ChkLedBal.value = parseFloat(seltotAmt);
			if (seltotAmtType == "DR")
			{
				ChkLedBal.disabled = true;
			}
		}
		selTotalBalance.innerText = LedgerBalance.innerText;
		ChkLedBal.checked = true;
		/*if (ChkLedBal.value < 0)
		{
			ChkLedBal.disabled = true;
			ChkLedBal.checked = false;
		}*/

	}
}

function	setTotalAmount( Form )
{
	with ( Form )
	{	
		//TotalAmt.value = 0
		TotalMargin  = parseFloat(new Number(ChkLedBal.value));
		Associate  = parseFloat(new Number(ChkAssociateBal.value));
		Collateral = parseFloat(new Number(ChkColl.value));
		initMrg = parseFloat(new Number(InitialMargin.value));
		
		InitMar.style.color = "Red";

		TotalAmt.value = 0;
		
		if ( ChkLedBal.checked == true )
		{
			if ( TotalMargin <= 0 )
			{
				TotalAmt.value = parseFloat(TotalAmt.value) - TotalMargin
			}
			else
			{
				TotalAmt.value = parseFloat(TotalAmt.value) + TotalMargin
			}
		}
		
		if ( ChkAssociateBal.disabled == false )
		{	
			if ( ChkAssociateBal.checked == true )
			{
				TotalAmt.value = parseFloat(TotalAmt.value) + Associate;
			}
		}
		
		if ( ChkColl.checked == true )
		{
			TotalAmt.value = parseFloat(TotalAmt.value) + Collateral;
		}
		
		totAmt = parseFloat(new Number(TotalAmt.value));
		
		TotalAmount.innerText = Math.abs(TotalAmt.value);

		if ( totAmt < 0 )
		{
			TotalAmount.style.color = "Red";
			TotalAmount.innerText = TotalAmount.innerText + " DR" 
		}
		else
		{
			TotalAmount.style.color = "Blue";
			TotalAmount.innerText = TotalAmount.innerText + " CR" 
		}
		
		NetAmt.innerText =  totAmt - initMrg;
		
		if ( totAmt == 0)
		{
			NetAmt.innerText = 0;
		}

		if (NetAmt.innerText <= 0)
		{
			NetAmt.innerText = Math.abs(NetAmt.innerText) + " DR"
			NetAmt.style.color = "Red";
		}
		else
		{
			NetAmt.innerText = Math.abs(NetAmt.innerText) + " CR"
			NetAmt.style.color = "Blue";
		}
	}
}

function setNarration( form )
{		 
	with ( form )
	{
		Narration.value = "";
		/*if ( ChkLedBal.checked )
		{
			if (ChkOpLedBal.checked)
			{
				Narration.value = "Op. Bal : " + LedgerOpeningBalance.innerText +"\n +";
			}
		
			if (ChkMarginDrAmt.checked)
			{
				Narration.value = Narration.value + " Dr. Margin : " + MarginDrAmt.innerText +"\n +";
			}
		
			if (ChkMarginCrAmt.checked)
			{
				Narration.value = Narration.value + " Cr. Margin : " + MarginCrAmt.innerText +"\n";
			}
		
			if ( ChkBillAmount.checked )
			{
				Narration.value = Narration.value + " Bill Amount : " + BillAmount.innerText +"\n +";
			}
		
			if (ChkDrTrans.checked)
			{
				Narration.value = Narration.value + " Dr. Trans : " + DrTrans.innerText +"\n +";
			}
		
			if (ChkCrTrans.checked)
			{
				Narration.value = Narration.value + " Cr. Trans : " + CrTrans.innerText +"\n";
			}

			Narration.value = Narration.value + "			Total Amount : " + LedgerBalance.innerText;
		}*/
				if ( ChkLedBal.checked )
		{
			if (ChkOpLedBal.checked)
			{
				Narration.value = "Op. Bal";
			}
		
			if (ChkMarginDrAmt.checked)
			{
				Narration.value = Narration.value + " + Dr. Margin";
			}
		
			if (ChkMarginCrAmt.checked)
			{
				Narration.value = Narration.value + " + Cr. Margin";
			}
		
			if ( ChkBillAmount.checked )
			{
				Narration.value = Narration.value + " + Bill Amount";
			}
		
			if (ChkDrTrans.checked)
			{
				Narration.value = Narration.value + " + Dr. Trans";
			}
		
			if (ChkCrTrans.checked)
			{
				Narration.value = Narration.value + " + Cr. Trans";
			}

			Narration.value = Narration.value + " " + LedgerBalance.innerText;
		}
		if ( ChkAssociateBal.checked )
		{
			Narration.value = Narration.value + "\n" + AssociateTitle.innerText + AssociatedLedgerBalance.innerText
		}
		if ( ChkColl.checked )
		{
			Narration.value = Narration.value + "\nCollateral Amount : " + ChkColl.value
		}
			Narration.value = Narration.value ;+ "\n\n";
			totAmt = parseFloat(new Number(TotalAmt.value));
			initMarg = parseFloat(new Number(InitialMargin.value));
		
			if ( totAmt <= initMarg )
			{
				Narration.value = Narration.value + "\nReported Margin :" + TotalAmt.value + " DR";
				Reported_Margin.value = TotalAmt.value;
			}
			else
			{
				Narration.value = Narration.value + "\nReported Margin :" + InitialMargin.value + " DR";
				Reported_Margin.value = InitialMargin.value;
			}
	}	
}
