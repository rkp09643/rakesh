/* ****************************************************************
	FUNCTION FOR HIDING AND SHOWING THE STOCK POOL ACC DETAILS.
**************************************************************** */
function setOnLoad( form )
{
	with( form )
	{
		CoGrpCode.focus();
		Creation.style.display = "";
		Modification.style.display = "None";
		AddCompanyGroup.style.display = "";
		ModifyCompanyGroup.style.display = "None";
	}
}


/* *************************************************************************
	FUNCTION FOR VALIDATING EMPTY FORM FIELDS BEFORE SUBMITING THE FORM.
************************************************************************* */
function chkForEmptyFields( form )
{
	var field, fieldName, fieldValue, fieldsCount = form.elements.length;
	
	with( form )
	{
		for( i = 0; i < fieldsCount; i++ )
		{
			field = elements[ i ];
			fieldName = field.name;
			fieldValue = field.value;
			
			if( ( i != 0 ) )
			{
				// GENERALIZED VALIDATION FOR ALL THE FORM FIELDS.
				if( ( fieldValue == "" ) || ( fieldValue.charAt ( 0 ) == " " ) )
				{
					alert( "Please enter a value for the field '" +fieldName +"'." );
					field.value = "";
					field.focus( );
					return false;
				}
			}
		}
	}
}


function modifyCompanyGroups( form, compGrpCode, compGrpName )
{
	Creation.style.display = "None";
	Modification.style.display = "";
	AddCompanyGroup.style.display = "None";
	ModifyCompanyGroup.style.display = "";
	
	with( form )
	{
		CoGrpCode.value = compGrpCode;
		CoGrpCode.readOnly = true;
		CoGrpName.value = compGrpName;
		Update.focus();
	}
}


/* *************************************************
	FOR HIDING/SHOWING USER HELPS WHEN REQUIRED.
************************************************* */
function showHideHelps( obj )
{
	if( obj == "Body" )
	{
		MainHelp.style.display = "";
		CoGrpCodeHelp.style.display ="None";	CoGrpNameHelp.style.display ="None";
	}
	else if( obj.name == "CoGrpCode" )
	{
		MainHelp.style.display = "";
		CoGrpCodeHelp.style.display ="";		CoGrpNameHelp.style.display ="None";
	}
	else if( obj.name == "CoGrpName" )
	{
		MainHelp.style.display = "";
		CoGrpCodeHelp.style.display ="None";	CoGrpNameHelp.style.display ="";
	}
}