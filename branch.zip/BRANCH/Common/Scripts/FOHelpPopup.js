/* ####################################################################################
					JAVASCRIPT FILE FOR HELP POPUP WINDOW.
#################################################################################### */


HelpWindow = new Object();

/* ********************************************
	FUNCTION FOR CLOSING HELP POPUP WINDOW.
******************************************** */
function CloseWindow( )
{
	document.ReportForm.msg.value	=	"";
	
	try
	{
		if( ( typeof( HelpWindow ) == "object" ) && ( !HelpWindow.closed ) )
		{
			HelpWindow.close();
			throw "e";
		}
	}
	catch( e )
	{
		return ( e );
	}
}


/* ********************************************
	FUNCTION FOR OPENING HELP POPUP WINDOW.
******************************************** */
function OpenWindow( form, par )
{
	with( ReportForm )
	{
		if( par == "Settlement" )
		{
			HelpWindow	=	open( "/BRANCH/HelpSearch/TradingClients.cfm?COCD=" +COCD.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&mkt_type=" +Mkt_type.value +"&helpfor=" +par +"&title=Report - " +ReportName.value ,"HelpWindow", "width=700, height=525, scrollbar=no, top=0, left=0, menubar=no, titlebar=no, toolbar=no, status=no, resizeable=no" );
		}
		
		if( par == "Client" )
		{
			try
			{
				if( FromDate && ToDate)
				{
					HelpWindow	=	open( "/BRANCH/HelpSearch/TradingClients.cfm?COCD="+ COCD.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&FromDate=" +FromDate.value +"&ToDate=" +ToDate.value +"&helpfor=" +par +"&title=Report - " +ReportName.value, "HelpWindow", "width=700, height=525, scrollbar=no, top=0, left=0, menubar=no, titlebar=no, toolbar=no, status=no, resizeable=no" );
				}
			}
			catch( e )
			{ 
					HelpWindow	=	open( "/BRANCH/HelpSearch/TradingClients.cfm?COCD="+ COCD.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&FromDate=" +FromDate.value +"&helpfor=" +par +"&title=Report - " +ReportName.value, "HelpWindow", "width=700, height=525, scrollbar=no, top=0, left=0, menubar=no, titlebar=no, toolbar=no, status=no, resizeable=no" );
			}
			
			try
			{
				if( Mkt_type )
				{
					HelpWindow	=	open( "/BRANCH/HelpSearch/TradingClients.cfm?COCD="+ COCD.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&mkt_type=" +Mkt_type.value +"&settlement_no=" +Settlement_no.value +"&helpfor=" +par +"&title=Report - " +ReportName.value, "HelpWindow", "width=700, height=525, scrollbar=no, top=0, left=0, menubar=no, titlebar=no, toolbar=no, status=no, resizeable=no" );
				}
			}
			catch( e ){ }
		}
	}
}


/* ********************************************
	FUNCTION FOR OPENING HELP POPUP WINDOW.
******************************************** */
function OpenWindowForScrip( form, par, Type, InputType )
{
	with( ReportForm )
	{
		HelpWindow = open( "/BRANCH/HelpSearch/TradingClients.cfm?COCD=" +COCD.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&ClientList=" +FromClient.value +"&Type=" +Type +"&InputType=" + InputType +"&helpfor=" +par +"&title=Report - " +ReportName.value, "HelpWindow", "width=700, height=525, scrollbar=no, top=0, left=0, menubar=no, titlebar=no, toolbar=no, status=no, resizeable=no" );
	}
}

function OpenWindowForScrip_FO( form, par, Type, InputType )
{
	with( ReportForm )
	{
		HelpWindow = open( "/BRANCH/HelpSearch/SearchScrip.cfm?COCD=" +COCD.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&ClientList=" +FromClient.value +"&Type=" +Type +"&InputType=" + InputType +"&helpfor=" +par +"&title=Report - " +ReportName.value, "HelpWindow", "width=700, height=525, scrollbar=no, top=0, left=0, menubar=no, titlebar=no, toolbar=no, status=no, resizeable=no" );
		//HelpWindow = open( "/BRANCH/HelpSearch/TradingClients.cfm?COCD=" +COCD.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&ClientList=" +FromClient.value +"&Type=" +Type +"&InputType=" + InputType +"&helpfor=" +par +"&title=Report - " +ReportName.value, "HelpWindow", "width=700, height=525, scrollbar=no, top=0, left=0, menubar=no, titlebar=no, toolbar=no, status=no, resizeable=no" );
	}
}
function OpenWindowForScrip_OfflineOrderEntry( form, par, Type, InputType, FromSymbol )
{
	with( form )
	{		
		HelpWindow = open( "/BRANCH/HelpSearch/TradingClients.cfm?COCD=" +COCD.value + "&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Type=" +Type +"&InputType=" + InputType +"&title=Report" + "&helpfor=Scrip" + "&ScrObj=" + FromSymbol, "HelpWindow", "width=700, height=525, scrollbar=no, top=0, left=0, menubar=no, titlebar=no, toolbar=no, status=no, resizeable=no" );
	}
}
/* ********************************************
	FUNCTION FOR OPENING HELP POPUP WINDOW.
******************************************** */
function OpenSingleWindow( form, par )
{
	with( ReportForm )
	{
		if( par == "Client" )
		{
			try
			{
				HelpWindow	=	open( "/BRANCH/HelpSearch/SingleChoice.cfm?COCD="+ COCD.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&helpfor=" +par +"&title=Report - " +ReportName.value, "HelpWindow", "width=700, height=525, scrollbar=no, top=0, left=0, menubar=no, titlebar=no, toolbar=no, status=no, resizeable=no" );
			}
			catch( e )
			{ 
				HelpWindow	=	open( "/BRANCH/HelpSearch/SingleChoice.cfm?COCD="+ COCD.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&helpfor=" +par +"&title=Report - " +ReportName.value, "HelpWindow", "width=700, height=525, scrollbar=no, top=0, left=0, menubar=no, titlebar=no, toolbar=no, status=no, resizeable=no" );
			}
		}
	}
}


/* ********************************************
	FUNCTION FOR OPENING HELP POPUP WINDOW.
******************************************** */
function OpenDateWindow( form, par )
{
	with( ReportForm )
	{
		try
		{
			HelpWindow	=	open( "/BRANCH/HelpSearch/TradedDates.cfm?COCD=" +COCD.value +"&COName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&FromDate=" +FromDate.value +"&HelpFor=" +par +"&Title=Report - " +ReportName.value, "DateHelpWindow", "Top=50, Left=100, Width=600, Height=400, AlwaysRaised=Yes" );
		}
		catch( e )
		{ 
			HelpWindow	=	open( "/BRANCH/HelpSearch/TradedDates.cfm?COCD=" +COCD.value +"&COName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&FromDate=" +FromDate.value +"&HelpFor=" +par +"&Title=Report - " +ReportName.value, "DateHelpWindow", "Top=50, Left=100, Width=600, Height=400, AlwaysRaised=Yes" );
		}
	}
}