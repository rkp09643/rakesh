import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import org.apache.pdfbox.util.PDFMergerUtility;
 
public class a3 {
 
  public static void main(String[] args) throws Exception {
    /* Assumes the directory contains only PDF files */
	  //String a1="D://pdf_old";
	  String link=args[0];
		String[] splits = link.split("\\|");
		String a1=splits[0];
		String filename=splits[1];
    File dir = new File(a1);
    File [] listOfFiles = dir.listFiles();
    PDFMergerUtility mergerUtility = new PDFMergerUtility();
    List<InputStream> orderedPDFsToMerge
      = new ArrayList<InputStream>();
    for(int i = 0; i < listOfFiles.length; i++) 
    {
    	 if (listOfFiles[i].isFile()) 
    	   {
    	 String files = listOfFiles[i].getName();
    	 if (files.endsWith(".pdf") || files.endsWith(".PDF"))
    		 {
      orderedPDFsToMerge.add(new FileInputStream(listOfFiles[i]));
      System.out.println(listOfFiles[i]);
    		 }
      
    	   }
    }
   
    mergerUtility.addSources(orderedPDFsToMerge);
    String mergefile="D://a1.pdf";
	mergerUtility.setDestinationFileName(filename);
 
    
    mergerUtility.mergeDocuments();
    System.out.print("PDF Merged Successfully");
  }
}
