Please Copy MultiClientsHelp.cfm into

C:\Inetpub\wwwroot\BRANCH\FA_FOCAPS\HelpSearch Folder



Bhavesh