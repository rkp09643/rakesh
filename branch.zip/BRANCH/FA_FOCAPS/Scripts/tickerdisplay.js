// width of the ticker
var tickerwidth=200

// height of the ticker
var tickerheight=150

// distance from the messagetext to the tickermarrgin (pixels)
var tickerpadding=5

// borderwidth of the ticker (pixels)
var borderwidth=1

// font-family
var fnt="Tahoma"

// font-size of the text
var fntsize=9

// font-size of the last letter of the ticker
var fntsizelastletter=9//12

// font-color of the text
var fntcolor="Navy"

// font-color of the last letter of the ticker
var fntcolorlastletter="Navy"

// font-weight. Set a value between 1 to 9 to adjust the boldness
var fntweight=1

// backgroundcolor
var backgroundcolor="AliceBlue"
// standstill between the messages (microseconds)
var standstill=2000

// speed (a higher value will slow down the ticker)
var speed=0.001

// horizontal distance from the textlink to the popupbox (pixels)
var xdistance=5

// vertical distance from the textlink to the popupbox (pixels)
var ydistance=5

// Do not edit the variables below
var timer
var topposition=0
var leftposition=0
var x,y
var i_substring=0
var i_presubstring=0
var i_message=0
var message
var messagecontent=""
var messagebackground=""
var messagepresubstring=""
var messageaftersubstring=""
fntweight=fntweight*100

function getmessagebackground() {
                messagebackground="<table border="+borderwidth+" width="+tickerwidth+" height="+tickerheight+" cellspacing=0 cellpadding=0><tr><td valign=top bgcolor='"+backgroundcolor+"'>"
                messagebackground+="&nbsp;</td></tr></table>"
}

function getmessagecontent() {  
                messagecontent="<table border=0 cellspacing=0 cellpadding="+tickerpadding+" width="+tickerwidth+" height="+tickerheight+"><tr><td valign=top>"
                messagecontent+="<span style='position:relative; font-family:"+fnt+";color:"+fntcolor+";font-size:"+fntsize+"pt;font-weight:"+fntweight+"'>"    
                messagecontent+="<font color='"+fntcolor+"'>"
                messagecontent+=messagepresubstring
                messagecontent+="</font>"
                messagecontent+="</span>"
                messagecontent+="<span style='position:relative; font-family:"+fnt+";color:"+fntcolor+";font-size:"+fntsizelastletter+"pt;font-weight:900'>"    
                messagecontent+="<font color='"+fntcolorlastletter+"'>"
                messagecontent+=messageaftersubstring
                messagecontent+="</font>"
                messagecontent+="</span>"
                messagecontent+="</td></tr></table>"
}

function showticker() {
        if (i_substring<=message.length-1) {
                        i_substring++
                        i_presubstring=i_substring-1
                        if (i_presubstring<0) {i_presubstring=0}
            messagepresubstring=message.substring(0,i_presubstring)
                messageaftersubstring=message.substring(i_presubstring,i_substring)
                        getmessagecontent()
                if (document.all) {
                        ticker.innerHTML=messagecontent
                        timer=setTimeout("showticker()", speed)
						//showticker();
                }
                if (document.layers) {
                        document.ticker.document.write(messagecontent)
                        document.ticker.document.close()
                        timer=setTimeout("showticker()", speed)
						//showticker();
                }
        }
        else {
                clearTimeout(timer)
        }
}

function hideticker() {
    clearTimeout(timer)
    i_substring=0
        i_presubstring=0
    if (document.all) {
            document.all.ticker.style.visibility="hidden"
       document.all.tickerbg.style.visibility="hidden"
        }
        if (document.layers) {
                document.ticker.visibility="hidden"
        document.tickerbg.visibility="hidden"
        }
}

function showmessage(linkmessage) {
    getmessagebackground()
    message=linkmessage
   
        i_substring=0
        i_presubstring=0
    leftposition=x+xdistance
    topposition=y+ydistance

        if (document.all) {     
                document.all.ticker.style.posLeft=leftposition
                document.all.ticker.style.posTop=topposition
                document.all.tickerbg.style.posLeft=leftposition
                document.all.tickerbg.style.posTop=topposition
                tickerbg.innerHTML=messagebackground
        document.all.ticker.style.visibility="visible"
        document.all.tickerbg.style.visibility="visible"
                showticker()
        }
        if (document.layers) {
        document.ticker.left=leftposition
                document.ticker.top=topposition
                document.tickerbg.left=leftposition
                document.tickerbg.top=topposition
                document.tickerbg.document.write(messagebackground)
                document.tickerbg.document.close()
        document.ticker.visibility="visible"
        document.tickerbg.visibility="visible"
                showticker()
        }
}

function handlerMM(e){
        x = (document.layers) ? e.pageX : document.body.scrollLeft+event.clientX
        y = (document.layers) ? e.pageY : document.body.scrollTop+event.clientY
}

if (document.layers){
        document.captureEvents(Event.MOUSEMOVE);
}
document.onmousemove = handlerMM;
