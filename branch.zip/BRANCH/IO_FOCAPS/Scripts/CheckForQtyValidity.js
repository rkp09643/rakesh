/* #####################################################################################
					JAVASCRIPT FILE FOR VALIDATING THE NUMERIC FORM FIELDS.
##################################################################################### */


/* *********************************************************
		FUNCTION FOR VALIDATING EMPTY FORM FIELDS.
********************************************************* */
function chkForFieldValidity( formObj, fieldName, fieldType, allowNegative, markType )
{
	with( eval( formObj ) )
	{
		if( markType == "Auctioned" )
		{
			fieldObj		=	QtyToAuction;
			fieldValue		=	QtyToAuction.value;
			auctdClsdOutQty	=	AuctionedQty.value;
		}
		else if( markType == "Closed-Out" )
		{
			fieldObj		=	QtyToCloseOut;
			fieldValue		=	QtyToCloseOut.value;
			auctdClsdOutQty	=	ClosedOutQty.value;
		}
		else if( markType == "Direct Pay-Out" )
		{
			fieldObj		=	QtyToMark;
			fieldValue		=	QtyToMark.value;
			auctdClsdOutQty	=	DirectPayOutQty.value;
		}
		else if( markType == "Exchange Inward Short" )
		{
			fieldObj		=	ClientInwardShortQty;
			fieldValue		=	ClientInwardShortQty.value;
			auctdClsdOutQty	=	AuctionedQty.value;
		}
		
		if( ( fieldValue == "" ) || ( fieldValue.charAt(0) == " " ) )
		{
			alert( "Please enter a value for '" +fieldName +"'." );
			fieldObj.focus();
			
			return false;
		}
		else
		{
			if( ( auctdClsdOutQty > 0 ) && ( fieldValue == 0 ) )
			{
				if( confirm( "You have entered 'Zero' for '" +fieldName +"'.\nThis will Revert '" +markType +"' Transaction. Do you want to continue?" ) )
				{
					
				}
				else
				{
					return false;
				}
			}
/*
			else if( ( auctdClsdOutQty == 0 ) && ( fieldValue == 0 ) )
			{
				return false;
			}
*/
		}
	}
}


/* *********************************************************
		FUNCTION FOR VALIDATING EMPTY FORM FIELDS.
********************************************************* */
function chkForQtyValidity( formObj, fieldObj, fieldName, fieldValue, auctionCloseOutQty, markType )
{
	if( markType == "Auctioned" )
	{
		msg	=	"Exchange Auctioned-Quantity Plus Short-Quantity.";
	}
	else if( markType == "Closed-Out" )
	{
		msg	=	"Counter-Client ClosedOut-Quantity Plus Short-Quantity.";
	}
	else if( markType == "Direct Pay-Out" )
	{
		msg	=	"Exchange PayOut-Quantity Plus Short-Quantity.";
	}
	else if( markType == "Inter-Settled" )
	{
		msg	=	"Counter-Client ClosedOut-Quantity Plus Short-Quantity.";
	}
	
	fieldValue			=	parseInt( new Number( fieldValue ) );
	auctionCloseOutQty	=	parseInt( new Number( auctionCloseOutQty ) );
	
	with( formObj )
	{
		if( fieldValue > auctionCloseOutQty )
		{
			alert( "'" +fieldName +"' cannot be more than " +msg  );
			fieldObj.value	=	"";
			fieldObj.focus();
			
			return false;
		}
	}
}


/* *********************************************************
		FUNCTION FOR VALIDATING EMPTY FORM FIELDS.
********************************************************* */
function chkForInterSetlFieldValidity( formObj, fieldName, fieldType, allowNegative )
{
	with( eval( formObj ) )
	{
		fieldObj		=	QtyToCloseOut;
		fieldValue		=	QtyToCloseOut.value;
		interSetlQty	=	ClosedOutQty.value;
		
		if( ( fieldValue == "" ) || ( fieldValue.charAt(0) == " " ) )
		{
			alert( "Please enter a value for '" +fieldName +"'." );
			fieldObj.focus();
			
			return false;
		}
		else
		{
			if( ( interSetlQty > 0 ) && ( fieldValue == 0 ) )
			{
				if( confirm( "You have entered 'Zero' for '" +fieldName +"'.\nThis will Revert '" +markType +"' Transaction. Do you want to continue?" ) )
				{
					return true;
				}
				else
				{
					return false;
				}
			}
		}
	}
}