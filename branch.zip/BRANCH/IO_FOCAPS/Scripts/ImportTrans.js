function optDataSelection( form )
{
	with( form )
	{
		if( All.checked )
		{
			FromDateRow.style.display	=	"None";
			ToDateRow.style.display		=	"None";
			SettlementRow.style.display	=	"None";
			EmptyRow3.style.display		=	"None";
			EmptyRow1.style.display		=	"";
			EmptyRow2.style.display		=	"";
		}	
		else if( DateWise.checked )
		{
			FromDateRow.style.display	=	"";
			ToDateRow.style.display		=	"";
			SettlementRow.style.display	=	"None";
			EmptyRow3.style.display		=	"None";
			EmptyRow1.style.display		=	"None";
			EmptyRow2.style.display		=	"None";
			FromDate.focus();
		}
		else if( SetlWise.checked )
		{
			FromDateRow.style.display	=	"None";
			ToDateRow.style.display		=	"None";
			SettlementRow.style.display	=	"";
			EmptyRow3.style.display		=	"";
			EmptyRow1.style.display		=	"None";
			EmptyRow2.style.display		=	"None";
			Settlement.focus();
		}
	}	
}

function optPoolTypeSelection( form )
{
	with( form )
	{
		if( CDSL.checked )
		{
			CDSLFileTypeRow.style.display	=	"";
			NSDLFileTypeRow.style.display	=	"None";
			DP89.checked					=	true;
		}	
		else if( NSDL.checked )
		{
			CDSLFileTypeRow.style.display	=	"None";
			NSDLFileTypeRow.style.display	=	"";
			Speed.checked					=	true;
		}
		
		optUserHelpSelection( form );
	}	
}

function chkForEmptyField( form )
{
	with( form )
	{
		if( form.name == "ImportTransaction" )
		{
			fieldObj	=	form.FileName;
			fieldVal	=	fieldObj.value;
			
			if( ( fieldVal == "" ) || ( fieldVal.charAt(0) == " " ) )
			{
				Msg.style.display	=	"None";
				alert( "Please select a File to Import Transactions." );
				fieldObj.focus();
				return false;
			}
		}
		else if( form.name == "AdditionalParams" )
		{
			if( DateWise.checked )
			{
				if( ( FromDate.value == "" ) || ( FromDate.value.charAt(0) == " " ) )
				{
					Msg.style.display	=	"None";
					alert( "Please enter valid 'From Date'." );
					FromDate.focus();
					return false;
				}
				else if( ( ToDate.value == "" ) || ( ToDate.value.charAt(0) == " " ) )
				{
					Msg.style.display	=	"None";
					alert( "Please enter valid 'To Date'." );
					ToDate.focus();
					return false;
				}
			}
			else if( SetlWise.checked )
			{
				if( ( Settlement.value == "" ) || ( Settlement.value.charAt(0) == " " ) )
				{
					Msg.style.display	=	"None";
					alert( "Please enter valid 'Settlement No'." );
					SetlNo.focus();
					return false;
				}
			}	
		}
		
		Msg.style.display	=	"";
	}
}

function optUserHelpSelection( form )
{
	with( form )
	{
		if( Eiasy.checked )
		{
			UserHelp.innerHTML			=	"CDSL \"Eiasy\" File Import";
			CDSLEiasyRow.style.display	=	"";
			CDSLDP05Row.style.display	=	"None";
			CDSLDP89Row.style.display	=	"None";
			NSDLSpeedRow.style.display	=	"None";
			NSDLSOTRow.style.display	=	"None";
		}	
		else if( DP05.checked )
		{
			UserHelp.innerHTML			=	"CDSL \"DP05\" File Import";
			CDSLEiasyRow.style.display	=	"None";
			CDSLDP05Row.style.display	=	"";
			CDSLDP89Row.style.display	=	"None";
			NSDLSpeedRow.style.display	=	"None";
			NSDLSOTRow.style.display	=	"None";
		}
		else if( DP89.checked )
		{
			UserHelp.innerHTML			=	"CDSL \"DP89\" File Import";
			CDSLEiasyRow.style.display	=	"None";
			CDSLDP05Row.style.display	=	"None";
			CDSLDP89Row.style.display	=	"";
			NSDLSpeedRow.style.display	=	"None";
			NSDLSOTRow.style.display	=	"None";
		}
		else if( Speed.checked )
		{
			UserHelp.innerHTML			=	"NSDL \"Speed\" File Import";
			CDSLEiasyRow.style.display	=	"None";
			CDSLDP05Row.style.display	=	"None";
			CDSLDP89Row.style.display	=	"None";
			NSDLSpeedRow.style.display	=	"";
			NSDLSOTRow.style.display	=	"None";
		}	
		else if( SOT.checked )
		{
			UserHelp.innerHTML			=	"NSDL \"SOT\" File Import";
			CDSLEiasyRow.style.display	=	"None";
			CDSLDP05Row.style.display	=	"None";
			CDSLDP89Row.style.display	=	"None";
			NSDLSpeedRow.style.display	=	"None";
			NSDLSOTRow.style.display	=	"";
		}
	}	
}