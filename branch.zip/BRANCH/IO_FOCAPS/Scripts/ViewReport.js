/* *************************************************************************************
					JAVASCRIPT FILE TO VIEW INWARD / OUTWARD REPORTS.
************************************************************************************* */


function optReportType( form, clr )
{
	with( form )
	{
		if( DateWise.checked )
		{
			DatesRow.style.display = "";
			SetlsRow.style.display = "None";
		}
		else if( ( SetlWise.checked ) || ( clr == "Y" ) )
		{
			DatesRow.style.display = "None";
			SetlsRow.style.display = "";
		}
	}
}


function viewReport( form )
{
	with( form )
	{
		var MainReportPath	=	"/BRANCH/IO_FOCAPS/Reports/";
		
		if ( ReportID.value != 11 & ReportID.value != 12 )
		{
			var CommonParams	=	"COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStYr=" +FinStYr.value +"&FinEndYr=" +FinEndYr.value +"&ReportID=" +ReportID.value +"&ReportName=" +ReportName.value +"&PrintDate=" +PrintDate.value + "&BranchCode=" +cmbBranch.value;
		}
		else
		{
			var CommonParams	=	"COCD=" +COCD.value + "&CoName=" + "&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStYr=" +FinStYr.value +"&FinEndYr=" +FinEndYr.value +"&ReportID=" +ReportID.value +"&ReportName=" +ReportName.value +"&PrintDate=" + "&BranchCode=" +cmbBranch.value;
		}	
		
		if
		(
			( ReportID.value == 1 ) || ( ReportID.value == 2 ) || 
			( ReportID.value == 3 ) || ( ReportID.value == 24 )
		)
		{
			if( ViewType[0].checked )
			{
				rptViewType = ViewType[0].value;
			}
			else
			{
				rptViewType = ViewType[1].value;
			}
		}
		
		if
		(
			( ReportID.value == 2 ) || ( ReportID.value == 3 ) || 
			( ReportID.value == 4 ) || ( ReportID.value == 5 )
		)
		{
			if( FlgInterSettlement.checked )
			{
				FlgIS = "Y";
			}
			else
			{
				FlgIS = "N";
			}
		}
		
		if
		(
			( ReportID.value == 2 ) || ( ReportID.value == 3 ) || 
			( ReportID.value == 4 )
		)
		{
			if( FlgExcessQty.checked )
			{
				FlgXSQty = "Y";
			}
			else
			{
				FlgXSQty = "N";
			}
			
			if( FlgShortQty.checked )
			{
				FlgShQty = "Y";
			}
			else
			{
				FlgShQty = "N";
			}
			
			if( FlgAuctionedQty.checked )
			{
				FlgAuctioned = "Y";
			}
			else
			{
				FlgAuctioned = "N";
			}
			
			if( FlgClosedOutQty.checked )
			{
				FlgClosedOut = "Y";
			}
			else
			{
				FlgClosedOut = "N";
			}
			
			if( FlgDirectPayOutQty.checked )
			{
				FlgDirectPayOut = "Y";
			}
			else
			{
				FlgDirectPayOut = "N";
			}
		}
		
		if
		(
			( ReportID.value == 6 ) || ( ReportID.value == 7 ) || 
			( ReportID.value == 8 )
		)
		{
			if( Depository[0].checked )
			{
				poolAcc	=	Depository[0].value;
			}
			else
			{
				poolAcc	=	Depository[1].value;
			}
		}
		
		if
		(
			( ReportID.value == 4 ) || ( ReportID.value == 5 )
		)
		{					
			if ( ReportID.value != 10 )
			{
				if( TransType[0].checked )
				{
					transType = TransType[0].value;
				}
				else
				{
					transType = TransType[1].value;
				}
			}	
			
			if( ReportType[0].checked )
			{
				rptType = ReportType[0].value;
				
				fromDate = FromDate.value;
				toDate = ToDate.value;
				
				mktType = "";
				setlNo = "";
			}
			else
			{
				rptType = ReportType[1].value;
				
				fromDate = "";
				toDate = "";
				
				mktType = MktType.value;
				setlNo = SetlNo.value;
			}
		}
		
		if( ReportID.value == 5 )
		{
			if( FlgSettledInstn.checked )
			{
				FlgSTrans = FlgSettledInstn.value;
			}
			else
			{
				FlgSTrans = "N";
			}
			
			if( FlgPendingInstn.checked )
			{
				FlgPTrans = FlgPendingInstn.value;
			}
			else
			{
				FlgPTrans = "N";
			}
			
			if( FlgCancelledInstn.checked )
			{
				FlgCTrans = FlgCancelledInstn.value;
			}
			else
			{
				FlgCTrans = "N";
			}
		}
		
		if( typeof( ClientList ) != "undefined" )
		{
			var client	=	escape( ClientList.value );
		}
		
		if( typeof( ScripList ) != "undefined" )
		{
			var scrip	=	escape( ScripList.value );
		}
		
		if( ReportID.value == 1 )
		{
			location.href = MainReportPath +"BillStockSummary.cfm?" +CommonParams +"&MktType=" +MktType.value +"&SetlNo=" +SetlNo.value +"&ClientList=" +client +"&ScripList=" +scrip +"&IOType=" +rptViewType;
		}
		
		else if( ReportID.value == 2 )
		{
			location.href = MainReportPath +"InwardStockSummary.cfm?" +CommonParams +"&MktType=" +MktType.value +"&SetlNo=" +SetlNo.value +"&ClientList=" +client +"&ScripList=" +scrip +"&FlgAuctionedQty=" +FlgAuctioned +"&FlgClosedOutQty=" +FlgClosedOut +"&FlgDirectPayOutQty=" +FlgDirectPayOut +"&FlgInterSettlement=" +FlgIS +"&FlgExcessQty=" +FlgXSQty +"&FlgShortQty=" +FlgShQty +"&InwardType=" +rptViewType;
		}
		
		else if( ReportID.value == 3 )
		{
			location.href = MainReportPath +"OutwardStockSummary.cfm?" +CommonParams +"&MktType=" +MktType.value +"&SetlNo=" +SetlNo.value +"&ClientList=" +client +"&ScripList=" +scrip +"&FlgAuctionedQty=" +FlgAuctioned +"&FlgClosedOutQty=" +FlgClosedOut +"&FlgDirectPayOutQty=" +FlgDirectPayOut +"&FlgInterSettlement=" +FlgIS +"&FlgExcessQty=" +FlgXSQty +"&FlgShortQty=" +FlgShQty +"&OutwardType=" +rptViewType;
		}
		
		else if( ReportID.value == 4 )
		{
			location.href = MainReportPath +"ClientStockSummary.cfm?" +CommonParams +"&FromDate=" +fromDate +"&ToDate=" +toDate +"&MktType=" +mktType +"&SetlNo=" +setlNo +"&ClientList=" +client +"&ScripList=" +scrip +"&FlgAuctionedQty=" +FlgAuctioned +"&FlgClosedOutQty=" +FlgClosedOut +"&FlgDirectPayOutQty=" +FlgDirectPayOut +"&FlgInterSettlement=" +FlgIS +"&FlgExcessQty=" +FlgXSQty +"&FlgShortQty=" +FlgShQty +"&IOType=ClientWise&TransType=" +transType +"&ReportType=" +rptType;
		}
		
		else if( ReportID.value == 5 )
		{
			location.href = MainReportPath +"ClientStockVoucherDetails.cfm?" +CommonParams +"&FromDate=" +fromDate +"&ToDate=" +toDate +"&MktType=" +mktType +"&SetlNo=" +setlNo +"&ClientList=" +client +"&ScripList=" +scrip +"&FlgSettledTrans=" +FlgSTrans +"&FlgPendingTrans=" +FlgPTrans +"&FlgCancelledTrans=" +FlgCTrans +"&FlgInterSettlement=" +FlgIS +"&IOType=ClientWise&TransType=" +transType +"&ReportType=" +rptType;
		}
		
		else if( ReportID.value == 6 )
		{
			if( ClientType[0].checked )
			{
				clType	=	ClientType[0].value;
			}
			else
			{
				clType	=	ClientType[1].value;
			}
			
			location.href	=	MainReportPath +"PayOutToClients.cfm?" +CommonParams +"&MktType=" +MktType.value +"&SetlNo=" +SetlNo.value +"&Depository=" +poolAcc +"&ClientType=" +clType;
		}
		
		else if( ReportID.value == 7 )
		{
			location.href = MainReportPath +"PayOutToExchange.cfm?" +CommonParams +"&MktType=" +MktType.value +"&SetlNo=" +SetlNo.value +"&Depository=" +poolAcc;
		}
		
		else if( ReportID.value == 8 )
		{
			location.href = MainReportPath +"InterSettlementInstructions.cfm?" +CommonParams +"&MktType=" +MktType.value +"&SetlNo=" +SetlNo.value +"&Depository=" +poolAcc;
		}
		
		else if( ReportID.value == 9 )
		{
			location.href = MainReportPath +"StockInHand.cfm?" +CommonParams +"&MktType=" +MktType.value +"&SetlNo=" +SetlNo.value +"&ClientList=&ScripList=" +scrip;
		}
		
		else if( ReportID.value == 10 )
		{
			fromDate = FromDate.value;
			toDate = ToDate.value;
			
			if (chkOnlyShort.checked)
			{
				viewShort = "Y";
			}
			else
			{
				viewShort = "N";
			}
			
			location.href = MainReportPath +"StockSummary.cfm?" +CommonParams +"&FromDate=" +fromDate +"&ToDate=" +toDate +"&ClientList=" +client +"&ScripList=" +scrip + "&IOType=ClientWise" + "&ViewShort=" + viewShort;
		}
		
		else if( ReportID.value == 11 )
		{
			location.href = "/BRANCH/BENEFICIARY/REPORTS/" +"Beneficiary_Summary.cfm?" +CommonParams +"&FromDate=" +"&ToDate=" +"&ClientList=" +client +"&ScripList=" +scrip + "&RptName=Branch";
		}

		else if( ReportID.value == 12 )
		{
			fromDate = FromDate.value;
			toDate = ToDate.value;
			
			location.href = "/BRANCH/BENEFICIARY/Reports/" +"Beneficiary_Detail.cfm?" +CommonParams + "&ClientList=" + ClientList.value + "&frmDt=" + fromDate + "&toDt=" + toDate + "&ScripList=" + ScripList.value;
		}
		
		else if( ReportID.value == 13 )
		{
			if (cmbClntCode.value == "")
			{
				alert("Sorry There is No client Availabel with Statement Of Holding");
			}
			else
			{
				location.href = "/BRANCH/IO_FOCAPS/Reports/" +"SOHReport.cfm?" +CommonParams + "&ClientList=" + cmbClntCode.value + "&frmDt=" + "&toDt=" + "&ScripList=";
			}
		}
	   
	   else if( ReportID.value == 14 )
	   {
		   	if (optAutoPopQty[0].checked)
			{
				AutoPostQty = "Y";
			}
			else
			{
				AutoPostQty = "N";
			}
			//"&Date=" + txtDate.value +
			location.href = "/BRANCH/BENEFICIARY/Reports/" +"Client_Payout_Request.cfm?" +CommonParams + "&ClientList=" + ClientList.value + "&ScripList=" + ScripList.value + "&AutoPostQty=" + AutoPostQty;
	   }
	   
		else if ( ReportID.value == 24 )
		{
			location.href = "/BRANCH/IO_FOCAPS/Reports/SOHReport.cfm?" + CommonParams +"&ViewType=" + rptViewType + "&ClientList=" + ClientList.value + "&ScripList=" + ScripList.value + "&FamGrpCode=" + CmbFamilyCode.value;
		}
	}
}