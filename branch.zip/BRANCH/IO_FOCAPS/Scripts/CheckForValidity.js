/* ####################################################################################
				JAVASCRIPT FILE FOR VALIDATING THE EMPTY FORM FIELDS.
#################################################################################### */


/* *************************************************************************
	FUNCTION FOR VALIDATING EMPTY FORM FIELDS BEFORE SUBMITING THE FORM.
************************************************************************* */
function chkForValidity( form, fieldsCnt, viewType )
{
	var obj, objName, objValue;
	
	with( form )
	{
		for( i = 0; i < fieldsCnt; i++ )
		{
			obj = elements[ i ];
			objName = obj.name;
			objValue = obj.value;
			
			// VALIDATION FOR "ISIN" FIELD.
			if( objName == "ISIN" )
			{
				if( ( objValue == "" ) || ( objValue.charAt ( 0 ) == " " ) )
				{
					alert( "Please enter a value for the field 'ISIN' for the " +viewType +" - '" +elements[ parseInt ( i-1 ) ].value +"'." );
					//obj.value = "";
					obj.focus ( );
					return false;
				}
			}
			
			// VALIDATION FOR "DPID" FIELD.
			if ( objName == "ClientDPCode" )
			{
				if ( ( objValue == "" ) || ( objValue.charAt ( 0 ) == " " ) )
				{
					alert ( "Please enter a value for the field 'DPID' for the " +viewType +" - '" +elements[ parseInt ( i-2 ) ].value +"'." );
					//obj.value = "";
					obj.focus ( );
					return false;
				}
			}
		}
	}
}


/* ********************************************************************
	FUNCTION FOR MANIPULATING VALUES FOR SHORT AND EXCESS QUANTITY, 
	WHEN CHANGING PAID QUANTITY IN OUTWARD ALLOCATION.
******************************************************************** */
function setShortExcessQty ( form, obj, objNo, rowsCnt, transType )
{
	var receivableQty, receivedQty, totReceivableQty, totReceivedQty = 0, 
		payableQty, paidQty, totPayableQty, totPaidQty = 0, 
		balanceQty, shortQty, excessQty, totShortQty, totExcessQty;
	var objNo = parseInt ( objNo );
	
	if ( transType == "Inward" )
	{
		receivedQty = parseInt ( obj.value );
		
		if ( isNaN ( receivedQty ) )
		{
			receivedQty = 0;
		}
	}
	else if ( transType == "Outward" )
	{
		paidQty = parseInt ( obj.value );
		
		if ( isNaN ( paidQty ) )
		{
			paidQty = 0;
		}
	}
	
	with ( form )
	{
		if ( transType == "Inward" )
		{
			receivableQty = parseInt ( elements[ objNo - 1 ].value );
			
			if ( isNaN ( receivableQty ) )
			{
				receivableQty = 0;
			}
			
			balanceQty = ( receivableQty - receivedQty );
		}
		else if ( transType == "Outward" )
		{
			payableQty = parseInt ( elements[ objNo - 1 ].value );
			
			if ( isNaN ( payableQty ) )
			{
				payableQty = 0;
			}
			
			balanceQty = ( payableQty - paidQty );
		}
		shortQty = elements[ objNo + 1 ];
		excessQty = elements[ objNo + 2 ];
		
		// SET THE VALUES FOR PAID, SHORT AND EXCESS QUANTITY.
		if ( transType == "Inward" )
		{
			if ( balanceQty > 0 )
			{
				shortQty.value = balanceQty;
				excessQty.value = 0;
				
				shortQty.style.color = "Red";
			}
			else
			{
				shortQty.value = 0;
				excessQty.value = Math.abs ( balanceQty );
				
				shortQty.style.color = "Navy";
			}
		}
		else if ( transType == "Outward" )
		{
			if ( balanceQty >= 0 )
			{
				shortQty.value = balanceQty;
				excessQty.value = 0;
				
				excessQty.style.color = "Navy";
			}
			else
			{
				shortQty.value = 0;
				excessQty.value = Math.abs ( balanceQty );
				
				excessQty.style.color = "Red";
			}
		}
		
		if ( rowsCnt > 1 )
		{
			for ( i = 0; i < rowsCnt; i++ )
			{
				if ( transType == "Inward" )
				{
					totReceivedQty = totReceivedQty + parseInt ( elements.ReceivedQty[ i ].value );
				}
				else if ( transType == "Outward" )
				{
					totPaidQty = totPaidQty + parseInt ( elements.PaidQty[ i ].value );
				}
			}
		}
		else
		{
			if ( transType == "Inward" )
			{
				totReceivedQty = totReceivedQty + parseInt ( elements.ReceivedQty.value );
			}
			else if ( transType == "Outward" )
			{
				totPaidQty = totPaidQty + parseInt ( elements.PaidQty.value );
			}
		}
		
		// SET THE VALUES FOR TOTAL PAID QUANTITY.
		if ( transType == "Inward" )
		{
			TotalReceivedQty.value = totReceivedQty;
			
			totReceivableQty = parseInt ( TotalReceivableQty.value );
			totBalanceQty = ( totReceivableQty - totReceivedQty );
		}
		else if ( transType == "Outward" )
		{
			TotalPaidQty.value = totPaidQty;
			
			totPayableQty = parseInt ( TotalPayableQty.value );
			totBalanceQty = ( totPayableQty - totPaidQty );
		}
		
		// SET THE VALUES FOR TOTAL SHORT AND EXCESS QUANTITY.
		if ( transType == "Inward" )
		{
			if ( totBalanceQty > 0 )
			{
				TotalShortQty.value = totBalanceQty;
				TotalExcessQty.value = 0;
				
				TotalShortQty.style.color = "Red";
			}
			else
			{
				TotalShortQty.value = 0;
				TotalExcessQty.value = Math.abs ( totBalanceQty );
				TotalShortQty.style.color = "Navy";
			}
		}
		else if ( transType == "Outward" )
		{
			if ( totBalanceQty >= 0 )
			{
				TotalShortQty.value = totBalanceQty;
				TotalExcessQty.value = 0;
				
				TotalExcessQty.style.color = "Navy";
			}
			else
			{
				TotalShortQty.value = 0;
				TotalExcessQty.value = Math.abs ( totBalanceQty );
				
				TotalExcessQty.style.color = "Red";
			}
		}
	}
}