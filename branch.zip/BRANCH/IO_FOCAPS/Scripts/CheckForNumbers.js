/* #####################################################################################
					JAVASCRIPT FILE FOR VALIDATING THE NUMERIC FORM FIELDS.
##################################################################################### */


/* *********************************************************
		FUNCTION FOR VALIDATING NUMERIC FORM FIELDS.
********************************************************* */
function chkForValidNumber( formObj, fieldObj, fieldName, fieldValue, fieldType, allowNegative )
{
	with( formObj )
	{
		// CHECK FIELD VALUE IS NUMERIC OR NOT, IF VALUE IS NOT EMPTY.
		if( ( fieldValue == "" ) || ( fieldValue.charAt(0) == " " ) )
		{
			fieldObj.value = 0;
		}
		// CHECK FIELD VALUE IS NUMERIC OR NOT, IF VALUE IS NOT EMPTY.
		else if( fieldValue != "" )
		{
			fieldValue = new Number( fieldValue );
			
			if( fieldType == "Integer" )
			{
				fieldValue = parseInt( fieldValue );
				fieldType = "an Integer value.";
			}
			else if( fieldType == "Float" )
			{
				fieldValue = parseFloat( fieldValue );
				fieldType = "a Float value.";
			}
			
			// IF FIELD VALUE IS NOT NUMERIC, THEN ALERT THE USER.
			if( isNaN( fieldValue ) )
			{
				alert( "'" +fieldName +"' should be " +fieldType );
				fieldObj.value = 0;
				fieldObj.focus ();
				
				return false;
			}
			
			// IF FIELD VALUE IS NUMERIC, THEN CHECK FOR THE FIELD VALIDITY.
			else
			{
				fieldObj.value = fieldValue;
				
				if( allowNegative == "No" )
				{
					// CHECK FOR FIELD "Quantity", IT SHOULD BE POSITIVE VALUE.
					if( fieldValue < 0 )
					{
						alert( "'" +fieldName +"' should be a Positive value." );
						fieldObj.value = Math.abs( fieldValue );
						fieldObj.focus ();
					}
				}
			}
		}
	}
}


/* *********************************************************
		FUNCTION FOR VALIDATING EMPTY FORM FIELDS.
********************************************************* */
function chkForFieldValidity( formObj, fieldName, fieldType, allowNegative )
{
	fieldObj = eval( formObj.QtyToAuction );
	//fieldValue = fieldObj.value;
	alert( formObj.name );
	/*
	with( formObj )
	{
		// ALERT THE USER, IF THE FIELD VALUE IS EMPTY.
		if( ( fieldValue == "" ) || ( fieldValue.charAt(0) == " " ) )
		{
			alert( "Please enter a value for '" +fieldName +"'" );
			fieldObj.focus();
			return false;
		}
	}*/
}