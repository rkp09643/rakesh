/* ####################################################################################
					JAVASCRIPT FILE FOR MODIFYING THE RECORDS.
#################################################################################### */


/* *******************************************************************
	FUNCTION FOR POPULATING SETTLEMENT-NOS, CLIENT-IDs AND SCRIPs.
******************************************************************* */
function populateFieldValues( form, populateFor, transType, vrType, selectSetlNo, selectClientID, selectScrip, toMktType, toSetlNo, populateType )
{
	with( form )
	{
		commonPath = "/BRANCH/DynamicFrame/Fra_Hide.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStYr=" +FinStYr.value +"&FinEndYr=" +FinEndYr.value +"&ValidationFor=" +populateFor;
		FormObject = "parent.Display.document." +form.name;
		
		// VALIDATION FOR I/O VOUCHER PARAMETERS.
		if( vrType == "ClientWise" )
		{
			parent.HideAndShow.location.href = commonPath +"&FormObject=" +FormObject +"&MktType=" +MktType.value +"&SetlNo=" +SetlNo.value +"&ClientID=" +ClientID.value +"&TransType=" +transType +"&VoucherType=" +vrType +"&SelectedSetlNo=" +selectSetlNo +"&SelectedClientID=" +selectClientID +"&SelectedScrip=" +selectScrip;
		}
		else if( ( vrType == "ScripWise" ) )
		{
			parent.HideAndShow.location.href = commonPath +"&FormObject=" +FormObject +"&MktType=" +MktType.value +"&SetlNo=" +SetlNo.value +"&Scrip=" +Scrip.value +"&TransType=" +transType +"&VoucherType=" +vrType +"&SelectedSetlNo=" +selectSetlNo +"&SelectedClientID=" +selectClientID +"&SelectedScrip=" +selectScrip;
		}
		
		/*
		// VALIDATION FOR OUTWARD INTER-SETTLEMENT VOUCHER PARAMETERS.
		else if( vrType == "InterSettlement" )
		{
			FormObject = "parent.Display.AddOutwardEntry.document." +form.name;
			
			if( ( toMktType != "" ) && ( toSetlNo != "" ) )
			{
				var mktTypeTo = toMktType;
				var setlNoTo = toSetlNo;
			}
			else
			{
				var mktTypeTo = ToMktType.value;
				var setlNoTo = ToSetlNo.value;
			}
			
			top.HideAndShow.location.href = commonPath +"&FormObject=" +FormObject +"&ToMktType=" +mktTypeTo +"&ToSetlNo=" +setlNoTo +"&SelectedSetlNo=" +SelectedSetlNo.value +"&SelectedClientDPCode=" +SelectedClientDPCode.value +"&SelectedISIN=" +SelectedISIN.value;
		}
		*/
		
		// VALIDATION FOR REPORT PARAMETERS.
		else
		{
			rptNo = transType;
			
			if( ( rptNo == 4 ) || ( rptNo == 5 ) )
			{
				if( TransType[0].checked )
				{
					voucherType = "R";
				}
				else
				{
					voucherType = "D";
				}
			}
			else
			{
				voucherType = "";
			}
			
			if( populateType != ""  )
			{
				popuType	=	populateType;
			}
			else
			{
				popuType	=	"";
			}
			billDate	=	TxtBillDate.value;
			parent.fraPaneBar.location.href = commonPath +"&FormObject=" +FormObject +"&MktType=" +MktType.value +"&SetlNo=" +SetlNo.value +"&VrType=" +voucherType +"&ReportNo=" +rptNo +"&PopulateType=" +popuType +"&SelectedSetlNo=" +selectSetlNo +"&SelectedClientID=" +selectClientID +"&SelectedScrip=" +selectScrip +"&Bill_Date=" +billDate;
		}
	}
}


/* *******************************************************************
	FUNCTION TO HIDE/SHOW OUTWARD VOUCHER TO-MKT-TYPE AND SETL-NO.
******************************************************************* */
function hideShowToMkTypeSetlNo( form, remove, frameName, toMktType, toSetlNo )
{
	with( form )
	{
		if( remove == "RemoveToMktTypeSetlNo" )
		{
			FlagIS.disabled = false;
			
			eval( frameName +"LabelToMktType.style.display = 'None';" );
			eval( frameName +"ListToMktType.style.display = 'None';" );
			eval( frameName +"LabelToSetlNo.style.display = 'None';" );
			eval( frameName +"ListToSetlNo.style.display = 'None';" );
		}
		else
		{
			if( FlagIS.checked )
			{
				eval( frameName +"LabelToMktType.style.display = '';" );
				eval( frameName +"ListToMktType.style.display = '';" );
				eval( frameName +"LabelToSetlNo.style.display = '';" );
				eval( frameName +"ListToSetlNo.style.display = '';" );
				
				//populateFieldValues( form, "ToSettlementNumber", 'D', "InterSettlement", '', '', '', toMktType, toSetlNo );
			}
			else
			{
				eval( frameName +"LabelToMktType.style.display = 'None';" );
				eval( frameName +"ListToMktType.style.display = 'None';" );
				eval( frameName +"LabelToSetlNo.style.display = 'None';" );
				eval( frameName +"ListToSetlNo.style.display = 'None';" );
			}
		}
	}
}


/* ***************************************************************************
	FUNCTION FOR VALIDATING MKT-TYPE, SETL-NO, CLIENT-CODE AND SCRIP-CODE.
*************************************************************************** */
function chkForValidity( form, objValue, validateFor, transType, displayBAN )
{
	with( form )
	{
		FrameObject	=	"parent.Display.Add" +transType +"Entry";
		FormObject	=	"parent.Display.Add" +transType +"Entry.document." +name;
		
		if( ( objValue != "" ) && ( objValue.charAt(0) != " " ) )
		{
			if
			(
				( ( validateFor == "SetlNo" ) || ( validateFor == "ToSetlNo" ) ) && 
				( MktType.value == "" ) || ( MktType.value.charAt(0) == " " )
			)
			{
				alert( "Please enter a value for 'Market-Type' before entering 'Settlement-No'." );
				SetlNo.value	=	"";
				MktType.focus();
				return false;
			}
			
			if( validateFor == "ToSetlNo" )
			{
				toMktType	=	ToMktType.value;
				toSetlNo	=	ToSetlNo.value
			}
			else
			{
				toMktType	=	"";
				toSetlNo	=	"";
			}
			
			if( typeof( displayBAN != "undefined" ) && displayBAN == "Y" )
			{
				DisplayBAN	=	displayBAN;
				selectedBAN	=	ClientDPCode.value;
			}
			else
			{
				DisplayBAN	=	"";
				selectedBAN	=	"";
			}
			
			top.HideAndShow.location.href	=	"/BRANCH/DynamicFrame/Fra_Hide.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStYr=" +FinStYr.value +"&FinEndYr=" +FinEndYr.value +"&ValidationFor=" +validateFor +"&ValidityCheckFor=" +validateFor +"&FrameObject=" +FrameObject +"&FormObject=" +FormObject +"&MktType=" +MktType.value +"&SetlNo=" +SetlNo.value +"&ClientID=" +ClientID.value +"&Scrip=" +Scrip.value +"&ToMktType=" +toMktType +"&ToSetlNo=" +toSetlNo +"&DisplayBAN=" +DisplayBAN +"&SelectedBAN=" +selectedBAN +"&ObjValue" +objValue;
		}
	}
}