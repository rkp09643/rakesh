function mouseOverStyle( rowObject )
{
	rowObject.bgColor = 'DFF2FD';
	//rowObject.style.color = 'Indigo';
}

function mouseOutStyle( rowObject )
{
	rowObject.bgColor = 'ECECFF';
}

function inValidFieldMsg( formName, fieldName )
{
	with ( formName )
	{
		alert ( fieldName.value + " does not exists !!!\nenter valid " + fieldName.name + ".")
		fieldName.focus();
		fieldName.value = "";
	}	
}

function setInputValue( formName, fieldName, fieldValue )
{
	with ( formName )
	{	
		fieldName.value = fieldValue;
	}	
}

function setInputObject( formName, fieldName )
{
	with ( formName )
	{	
		fieldName.focus();
	}
}