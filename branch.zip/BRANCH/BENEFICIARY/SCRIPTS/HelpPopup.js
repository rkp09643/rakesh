/* ####################################################################################
					JAVASCRIPT FILE FOR HELP POPUP WINDOW.
#################################################################################### */

HelpWindow = new Object();

/* ********************************************
	FUNCTION FOR CLOSING HELP POPUP WINDOW.
******************************************** */
function CloseWindow( )
{
	try
	{
		if( ( typeof( HelpWindow ) == "object" ) && ( !HelpWindow.closed ) )
		{
			HelpWindow.close();
			throw "e";
		}
	}
	catch( e )
	{
		return e;
	}
}


/* ********************************************
	FUNCTION FOR OPENING HELP POPUP WINDOW.
******************************************** */
function OpenWindow( form, Obj, recNo, dpClCode, dpID, isinNo, missingType, ObjName )
{
	if( form.name == "ReportParameters" )
	{
		ObjName = "";
		
		with( ReportParameters )
		{
			// FOLLOWING ARE HELP-POPUP FOR I/O VOUCHERS AND REPORT PARAMETERS.
			if( Obj == "MktType" )
			{
				HelpWindow = open( "/BRANCH/IO_FOCAPS/HelpSearch/MktTypesHelp.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&Object=" +Obj +"&FormName=ReportParameters&HelpFor=Market Type", "MktTypeHelpPopupWindow", "top=50, left=50, width=700, height=450" );
			}
			
			else if( Obj == "SetlNo" )
			{
				if( ( MktType.value == "" ) || ( MktType.value.charAt(0) == " " ) )
				{
					alert( "Please enter a value for the field 'Mkt Type', \nbefore opening the Help Popup for 'Setl No'." );
					MktType.focus ();
				}
				else
				{
					HelpWindow = open( "/BRANCH/IO_FOCAPS/HelpSearch/SettlementsHelp.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&MktType=" +MktType.value +"&Object=" +Obj +"&FormName=ReportParameters&HelpFor=Settlement Number", "SetlNoHelpPopupWindow", "top=50, left=50, width=700, height=450" );
				}
			}
			
			// FOLLOWING ARE HELP-POPUP FOR I/O VOUCHERS.
			else if( Obj == "Client_ID" )
			{
				HelpWindow = open( "/BRANCH/IO_FOCAPS/HelpSearch/ClientsHelp.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&MktType=" +MktType.value +"&SetlNo=" +SetlNo.value +"&Object=" +Obj +"&FormName=ReportParameters&HelpFor=Client ID", "ClientHelpPopupWindow", "top=50, left=50, width=700, height=450" );
			}
			
			else if( Obj == "CLIENT_DP_CODE" )
			{
				if( ( ClientID.value == "" ) || ( ClientID.value.charAt(0) == " " ) )
				{
					alert( "Please enter a value for the field 'Client ID', \nbefore opening the Help Popup for 'Client DP Code'." );
					ClientID.focus ();
				}
				else
				{
					HelpWindow = open( "/BRANCH/IO_FOCAPS/HelpSearch/ClientDPCodesHelp.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&ClientID=" +ClientID.value +"&Object=" +Obj +"&FormName=ReportParameters&HelpFor=Client DP Code", "ClientDPCodeHelpPopupWindow", "top=50, left=50, width=700, height=450" );
				}
			}
			
			// FOLLOWING ARE HELP-POPUP FOR THE REPORT PARAMETERS.
			else if( Obj == "ClientList" )
			{
				HelpWindow = open( "/BRANCH/IO_FOCAPS/HelpSearch/ClientsHelp.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStYr=" +FinStYr.value +"&FinEndYr=" +FinEndYr.value +"&MktType=" +MktType.value +"&SetlNo=" +SetlNo.value +"&Object=" +Obj +"&FormName=ReportParameters&HelpFor=Client ID", "ClientListHelpPopupWindow", "top=50, left=50, width=700, height=450" );
			}
			
			else if( Obj == "ScripCode" )
			{
				HelpWindow = open( "/BRANCH/IO_FOCAPS/HelpSearch/ScripsHelp.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&MktType=" +MktType.value +"&SetlNo=" +SetlNo.value +"&Object=" +Obj +"&FormName=ReportParameters&HelpFor=Scrip", "ScripHelpPopupWindow", "top=50, left=50, width=700, height=450" );
			}
			
			else if( Obj == "ScripList" )
			{
				if( typeof( ClientList ) == "object" )
				{
					clientList = ClientList.value;
				}
				else
				{
					clientList = "";
				}
				
				HelpWindow = open( "/BRANCH/IO_FOCAPS/HelpSearch/ScripsHelp.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStYr=" +FinStYr.value +"&FinEndYr=" +FinEndYr.value +"&MktType=" +MktType.value +"&SetlNo=" +SetlNo.value +"&ClientList=" +clientList +"&Object=" +Obj +"&FormName=ReportParameters&HelpFor=Scrip", "ScripListHelpPopupWindow", "top=50, left=50, width=700, height=450" );
			}
		}
	}

	else if( form.name == "NewOutwardEntry" )
	{
		with( NewOutwardEntry )
		{
			Client_DPCode.value = "";
			if( Obj == "ClientID" )
			{
				HelpWindow = open( "/BRANCH/IO_FOCAPS/HelpSearch/ClientsHelp.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStYr=" +FinStYr.value +"&FinEndYr=" +FinEndYr.value +"&Object=" +Obj +"&ObjectName=" +ObjName +"&RecNo=" +recNo +"&MissingDPClientCode=" +dpClCode +"&MissingDPID=" +dpID +"&MissingType=" +missingType +"&FormName=NewOutwardEntry&VoucherHelp=true&HelpFor=Client ID", "ClientHelpPopupWindow", "top=50, left=50, width=700, height=450" );
			}
			if( Obj == "ClientDPCode" )
			{				
				HelpWindow = open( "/BRANCH/IO_FOCAPS/HelpSearch/ClientDPHelp.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStYr=" +FinStYr.value +"&FinEndYr=" +FinEndYr.value +"&Object=" +Obj +"&ObjectName=" +ObjName +"&RecNo=" +recNo +"&MissingDPClientCode=" +dpClCode +"&MissingDPID=" +dpID +"&Client_ID=" +ClientID.value +"&MissingType=" +missingType +"&FormName=NewOutwardEntry&Mode=External&VoucherHelp=true&HelpFor=DP ID", "ClientHelpPopupWindow", "top=50, left=50, width=700, height=450" );
			}
		}
	}

	else if( form.name == "NewInwardEntry" )
	{
		with( form )
		{
			Client_DPCode.value = "";
			if( Obj == "ClientID" )
			{
				HelpWindow = open( "/BRANCH/IO_FOCAPS/HelpSearch/ClientsHelp.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStYr=" +FinStYr.value +"&FinEndYr=" +FinEndYr.value +"&Object=" +Obj +"&ObjectName=" +ObjName +"&RecNo=" +recNo +"&MissingDPClientCode=" +dpClCode +"&MissingDPID=" +dpID +"&MissingType=" +missingType +"&FormName=NewInwardEntry&VoucherHelp=true&HelpFor=Client ID", "ClientHelpPopupWindow", "top=50, left=50, width=700, height=450" );
			}
			if( Obj == "ClientDPCode" )
			{
				HelpWindow = open( "/BRANCH/IO_FOCAPS/HelpSearch/ClientDPHelp.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStYr=" +FinStYr.value +"&FinEndYr=" +FinEndYr.value +"&Object=" +Obj +"&ObjectName=" +ObjName +"&RecNo=" +recNo +"&MissingDPClientCode=" +dpClCode +"&MissingDPID=" +dpID +"&Client_ID=" +ClientID.value +"&MissingType=" +missingType +"&FormName=NewInwardEntry&Mode=External&VoucherHelp=true&HelpFor=DP ID", "ClientHelpPopupWindow", "top=50, left=50, width=700, height=450" );
			}
		}
	}
		
	// HELP-POPUP FOR MISSING CLIENT-ID's.
	else if( form.name == "MissingClientDPCode" )
	{
		with( MissingClientDPCode )
		{
			if( Obj == "ClientID" )
			{
				HelpWindow = open( "/BRANCH/IO_FOCAPS/HelpSearch/ClientsHelp.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStYr=" +FinStYr.value +"&FinEndYr=" +FinEndYr.value +"&Object=" +Obj +"&ObjectName=" +ObjName +"&RecNo=" +recNo +"&MissingDPClientCode=" +dpClCode +"&MissingDPID=" +dpID +"&MissingType=" +missingType +"&FormName=MissingClientDPCode&HelpFor=Client ID", "ClientHelpPopupWindow", "top=50, left=50, width=700, height=450" );
			}
		}
	}
	
	// HELP-POPUP FOR MISSING SCRIP's.
	else if( form.name == "MissingISIN" )
	{
		with( MissingISIN )
		{
			if( Obj == "Scrip" )
			{
				HelpWindow = open( "/BRANCH/IO_FOCAPS/HelpSearch/ScripsHelp.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStYr=" +FinStYr.value +"&FinEndYr=" +FinEndYr.value +"&Object=" +Obj +"&ObjectName=" +ObjName +"&RecNo=" +recNo +"&MissingISIN=" +isinNo +"&MissingType=" +missingType +"&FormName=MissingISIN&HelpFor=Scrip", "ScripHelpPopupWindow", "top=50, left=50, width=700, height=450" );
			}
		}
	}
}