/* ####################################################################################
					JAVASCRIPT FILE FOR VALIDATING THE EMPTY FORM FIELDS.
#################################################################################### */


/* *************************************************************************
	FUNCTION FOR VALIDATING EMPTY FORM FIELDS BEFORE SUBMITING THE FORM.
************************************************************************* */
function chkForEmptyFields( form, validateFor )
{
	var field, fieldName, fieldValue, fieldsCount = form.elements.length;
	
	with ( form )
	{
		for ( i = 0; i < fieldsCount; i++ )
		{
			field = elements[ i ];
			fieldName = field.name;
			fieldValue = field.value;
			
			if( validateFor == "DPClientCatalog" )
			{
				if ( i > 6 && i != 10 && i <= 11 )
				{
					// GENERALIZED VALIDATION FOR ALL THE FORM FIELDS.
					if ( ( fieldValue == "" ) || ( fieldValue.charAt( 0 ) == " " ) )
					{
						alert ( "Please enter a value for the field '" +fieldName +"'." );
						field.value = "";
						field.focus ( );
						return false;
					}
				}
			}
			else if( validateFor == "DPIDCatalog" )
			{
				if ( i <= 7 )
				{
					// GENERALIZED VALIDATION FOR ALL THE FORM FIELDS.
					if ( ( fieldValue == "" ) || ( fieldValue.charAt( 0 ) == " " ) )
					{
						alert ( "Please enter a value for the field '" +fieldName +"'." );
						field.value = "";
						field.focus ( );
						return false;
					}
				}
			}
		}
	}
}


/* ***************************************************************************
	FUNCTION FOR VALIDATING MKT-TYPE, SETL-NO, CLIENT-CODE AND SCRIP-CODE.
*************************************************************************** */
function setDPName( form, objValue, validateFor )
{
	with( form )
	{
		formObject	=	"parent.Display.document." +form.name;
		
		if( ( objValue != "" ) && ( objValue.charAt(0) != " " ) )
		{
			top.HideAndShow.location.href	=	"/BRANCH/DynamicFrame/Fra_Hide.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&ValidityCheckFor=" +validateFor +"&FormObject=" +formObject +"&DPID=" +DPID.value;
		}
	}
}


/* ************************************************************************************
	FUNCTION FOR CHECKING CLIENT-ID BEFORE ENTERING CLIENT-DP-CODE IN OUTWARD ENTRY.
************************************************************************************ */
function chkForClientID( form )
{
	with ( form )
	{
		if ( ( ClientID.value == "" ) || ( ClientID.value.charAt( 0 ) == " " ) )
		{
			alert ( "Please enter a value for the field 'Client ID', \nbefore entering 'Client DP Code'." );
			ClientID.focus ();
		}
	}
}


/* ****************************************************************************
	FUNCTION FOR CHECKING MKT-TYPE BEFORE ENTERING SETL-NO IN OUTWARD ENTRY.
**************************************************************************** */
function chkForMktType( form )
{
	with ( form )
	{
		if ( ( MktType.value == "" ) || ( MktType.value.charAt( 0 ) == " " ) )
		{
			alert ( "Please enter a value for the field 'Mkt Type', \nbefore entering 'Setl No'." );
			MktType.focus ();
		}
	}
}