/* ####################################################################################
					JAVASCRIPT FILE FOR MODIFYING THE RECORDS.
#################################################################################### */


/* ***********************************************
	FUNCTION FOR MODIFYING DP-MASTER RECORDS.
*********************************************** */
function modifyDPMaster( form, recNo, dpID, dpName, depository )
{
	AddDPMasterRow.style.display	=	"None";
	ModifyDPMasterRow.style.display	= 	"";
	
	with( form )
	{
		RecordNo.value			=	recNo;
		
		DPID.value				=	dpID;
		DPID.readOnly			=	true;
		DPID.style.color		=	"Navy";
		DPID.style.background	=	"Transparent";
		DPName.value			=	dpName;
		
		//OldDepository.value		=	depository;
		eval( depository +".checked	=	true;" );
	}
}


/* ***********************************************
	FUNCTION FOR MODIFYING DP-CATALOG RECORDS.
*********************************************** */
function modifyDPCatalog( form, recNo, clID, clDPCode, clDPName, dpID, dpName, depository, defAcc, IsCol )
{
	AddDPCatalogRow.style.display = "None";
	ModifyDPCatalogRow.style.display = "";
	
	with( form )
	{
		RecordNo.value = recNo;
		
		ClientID.value = clID;
		/*ClientID.readOnly = true;
		ClientID.style.color = "Navy";
		ClientID.style.background = "Transparent";*/
		OldClientID.value = clID;
		
		ClientDPCode.value = clDPCode;
		/*ClientDPCode.readOnly = true;
		ClientDPCode.style.color = "Navy";
		ClientDPCode.style.background = "Transparent";*/
		OldClientDPCode.value = clDPCode;
		
		ClientDPName.value = clDPName;
		
		DPID.value = dpID;
		/*DPID.readOnly = true;
		DPID.style.color = "Navy";
		DPID.style.background = "Transparent";*/
		OldDPID.value = dpID;
		
		DPName.value = dpName;
		
		if (IsCol == 'Y')
		{
			IsCollateral[0].checked = true;
		}
		else
		{
			IsCollateral[1].checked = true;
		}		
		
		eval( depository +".checked = true;" );
		OldDepository.value	=	depository;
		
		DefaultAccount.focus();
		
		if( defAcc == "Y" )
		{
			DefaultAccount.checked = true;
		}
		else
		{
			DefaultAccount.checked = false;
		}
	}
}


/* *************************************************
	FUNCTION FOR MODIFYING ISIN-CATALOG RECORDS.
************************************************* */
function modifyISINCatalog( form, recNo, isin, scrip, defNo )
{
	AddISINCatalogRow.style.display = "None";
	ModifyISINCatalogRow.style.display = "";
	
	with( form )
	{
		RecordNo.value = recNo;
		ISIN.value = isin;
		ISIN.readOnly = true;
		ISIN.style.color = "Navy";
		ISIN.style.background = "Transparent";
		
		ScripID.value = scrip;
		ScripID.readOnly = true;
		ScripID.style.color = "Navy";
		ScripID.style.background = "Transparent";
		
		DefaultNo.focus();
		if( defNo == "Y" )
		{
			DefaultNo.checked = true;
		}
		else
		{
			DefaultNo.checked = false;
		}
	}
}


/* ************************************************************
	FUNCTION FOR MAKING INWARD/OUTWARD TRANSACTION RECORDS.
************************************************************ */
function makeVoucher( form, vrType, mktType, setlNo, clID, clDPCode, srCode, balQty )
{
	if( vrType == "Inward" )
	{
		parent.AddInwardEntry.AddInwardEntryRow.style.display		=	"";
		parent.AddInwardEntry.ModifyInwardEntryRow.style.display	=	"None";
	}
	else if( vrType == "Outward" )
	{
		parent.AddOutwardEntry.AddOutwardEntryRow.style.display		=	"";
		parent.AddOutwardEntry.ModifyOutwardEntryRow.style.display	=	"None";
	}
	
	with( form )
	{
		reset();
		
		MktType.value		=	mktType;
		SetlNo.value		=	setlNo;
		
		ClientID.value		=	clID;
		ClientDPCode.value	=	clDPCode;
		Scrip.value			=	srCode;
		
		if( balQty > 0 )
		{
			Quantity.value	=	balQty;
		}
		else if( balQty == 0 )
		{
			alert( "Quantity is already Settled." );
		}
		else if( balQty < 0 )
		{
			alert( "Quantity is in Excess side." );
		}
		Quantity.focus();
		
		ValidationFor		=	"ClientDPCodeAndISIN";
		FrameObject			=	"parent.Display.Add" +vrType +"Entry";
		FormObject			=	"parent.Display.Add" +vrType +"Entry.document." +form.name;
		
		top.HideAndShow.location.href = "/BRANCH/DynamicFrame/Fra_Hide.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStYr=" +FinStYr.value +"&FinEndYr=" +FinEndYr.value +"&ValidationFor=" +ValidationFor +"&FrameObject=" +FrameObject +"&FormObject=" +FormObject +"&MktType=" +mktType +"&SetlNo=" +setlNo +"&ClientID=" +clID +"&Scrip=" +srCode;
	}
}


/* ***************************************************************
	FUNCTION FOR MODIFYING INWARD/OUTWARD TRANSACTION RECORDS.
*************************************************************** */
function modifyVoucher( form, vrType, recNo, mktType, setlNo, clID, vrNo, vrDt, srCode, isin, clDPCode, depoPool, qty, execDt, narr, flgIS, toMktType, toSetlNo, transNo )
{
	if( vrType == "Inward" )
	{
		parent.AddInwardEntry.AddInwardEntryRow.style.display = "None";
		parent.AddInwardEntry.ModifyInwardEntryRow.style.display = "";
	}
	else
	{
		parent.AddOutwardEntry.AddOutwardEntryRow.style.display = "None";
		parent.AddOutwardEntry.ModifyOutwardEntryRow.style.display = "";
	}
	
	with( form )
	{
		reset();
		
		RecordNo.value = recNo;
		MktType.value = mktType;
		SetlNo.value = setlNo;
		
		ClientID.value = clID;
		VoucherNo.value = vrNo;
		VoucherDate.value = vrDt;
		//VoucherDate.readOnly = true;
		Scrip.value = srCode;
		ClientDPCode.value = clDPCode;
		ISIN.value = isin;
		Quantity.value = qty;
		Quantity.focus();
		ExecutionDate.value = execDt;
		//ExecutionDate.readOnly = true;
		
		if( depoPool == "CDSL" )
		{
			CDSL.checked = true;
		}
		else
		{
			NSDL.checked = true;
		}
		Narration.value = narr;
		TransNo.value = transNo;
		
		if( vrType == "Inward" && flgIS == "Y" )
		{
			Update.style.display = "None"; Delete.style.display = "None";
			alert( "This is an Inter-Settlement Instruction, so you can not Manipulate it." );
		}
		else if( vrType == "Outward" && flgIS == "Y" )
		{
			ToMktType.value = toMktType;
			ToSetlNo.value = toSetlNo;
			OldInterSettlement.value = flgIS;
			FlagIS.checked = true;
			//FlagIS.disabled = true;
			
			hideShowToMkTypeSetlNo( form, "", "parent.AddOutwardEntry.", toMktType, toSetlNo );
		}
		else if( vrType == "Outward" && flgIS == "N" )
		{
			hideShowToMkTypeSetlNo( form, "RemoveToMktTypeSetlNo", "parent.AddOutwardEntry.", toMktType, toSetlNo );
		}
		
		ValidationFor	=	"ClientDPCodeAndISIN";
		FrameObject		=	"parent.Display.Add" +vrType +"Entry";
		FormObject		=	"parent.Display.Add" +vrType +"Entry.document." +form.name;
		
		top.HideAndShow.location.href = "/BRANCH/DynamicFrame/Fra_Hide.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStYr=" +FinStYr.value +"&FinEndYr=" +FinEndYr.value +"&ValidationFor=" +ValidationFor +"&FrameObject=" +FrameObject +"&FormObject=" +FormObject +"&MktType=" +mktType +"&SetlNo=" +setlNo +"&ClientID=" +clID +"&Scrip=" +srCode +"&CurrSelectedClientDPCode" +clDPCode;
	}
}