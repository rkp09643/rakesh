function chkForValidRec( formName, prevObjValue, obj, objValue)
{
	with( formName )
	{
		if( ( objValue != "" ) && ( objValue.charAt(0) != " " ) )
		{
			REPORT_QUERY.location.href	=	"/BRANCH/BENEFICIARY/COMMON/PASSDATA.cfm?formName=" + formName  +"&fieldName=" + obj +"&fieldValue=" + objValue + "&prevFieldValue=" + prevObjValue;
			Voucher_Disp.style.display = '';			
			VOUCHER_VIEW.location.href = 'Voucher_Query.cfm?View=Y' + '&Voucher_Date=' + VoucherEntryForm.Voucher_Date.value + '&Client_ID=' + VoucherEntryForm.Client_ID.value + '&Scrip=' + VoucherEntryForm.Scrip.value + '&Voucher_Type=' + VoucherEntryForm.VOUCHER_TYPE.value + '&Counter_Client_ID=' + VoucherEntryForm.BENCODE.value;
		}
	}
}

function ValidateOutward()
{
	VOUCHER_VIEW.location.href = 'Voucher_Query.cfm?Validate=Y' + '&Quantity=' + VoucherEntryForm.Quantity.value + '&Scrip=' + VoucherEntryForm.Scrip.value + '&BCode=' + VoucherEntryForm.BENCODE.value + '&View=Y' + '&Voucher_Date=' + VoucherEntryForm.Voucher_Date.value + '&Client_ID=' + VoucherEntryForm.Client_ID.value + '&Counter_Client_ID=' + VoucherEntryForm.BENCODE.value + '&Voucher_Type=' + VoucherEntryForm.VOUCHER_TYPE.value;
}

HelpWindow = new Object();

/* ********************************************
	FUNCTION FOR CLOSING HELP POPUP WINDOW.
******************************************** */
function CloseWindow( )
{
	try
	{
		if( ( typeof( HelpWindow ) == "object" ) && ( !HelpWindow.closed ) )
		{
			HelpWindow.close();
			throw "e";
		}
	}
	catch( e )
	{
		return e;
	}
}

function OpenWindow( form, Obj, returnObject, inputType, helpFor)
{
	ObjName = "";
		
	with( form )
	{
		commonParam = "COCD=" +COCD.value +"&CoName=" +escape(CoName.value) +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStYr=" +FinStYr.value +"&FinEndYr=" + FinEndYr.value+"&BenCode=" + BENCODE.value + "&BenDpId=" + BENEFICIARY_DP_ID.value + "&BenBanNo=" + BENEFICIARY_BAN_NO.value + "&BenDpName=" + BENEFICIARY_DP_NAME.value + "&BenBanName=" + BENEFICIARY_BAN_NAME.value + "&";
		helpParam="FormName=" + name +"&ObjectName=" +Obj.name +"&ObjectValue=" +Obj.value +"&ReturnObject=" + returnObject + "&InputType=" + inputType +"&HelpHeading=" + helpFor +"&";
		var formParam, field, fieldName, fieldValue, fieldsCount = form.elements.length;
	
		for ( i = 0; i < fieldsCount; i++ )
		{
			field = elements[ i ];
			fieldName = field.name;
			fieldValue = field.value;
			formParam = formParam + "&" + fieldName+"="+fieldValue;
		}			
		HelpWindow = open( "/BRANCH/BENEFICIARY/HelpSearch/ClientsHelp.cfm?" +commonParam + helpParam + formParam, "ClientHelpPopupWindow", "top=50, left=20, width=760, height=450" );
	}
}

function ViewScriptDetail(form)
{
	with(form)
	{
		HelpWindow = open("/BRANCH/Beneficiary/Transactions/ClientScripDetail.cfm?ClientID=" + Client_ID.value, "ScripDetailPopupWindow", "top=50, left=50, width=350, height=300");
	}		
}

function setValues( form, CID, CName, ScrCode, isin, Qty, VNo, TransCode, MktType, SetlNo, Brk_Code, ExecDt, TransNo, BanNo, BanName, DpID, DpName, Depo, Narr, voucherdt, BatchNo, datafrom )
{
	with ( form )
	{
		Client_ID.value =  CID; 
		ClientName.value =  CName; 
		Scrip.value =  ScrCode; 
		Isin.value =  isin;
		Quantity.value =  Qty;
		Voucher_No.value =  VNo;
		CmbReasonCode.value =  TransCode;
		Voucher_Date.value = voucherdt;
		MKT_TYPE.value =  MktType;
		SETTLEMENT_NO.value =  SetlNo;
		BROKER_CODE.value =  Brk_Code;
		Execution_Date.value =  ExecDt;
		TRANSACTION_NO.value =  TransNo;
		CLIENT_DP_CODE.value =  BanNo;
		CLIENT_DP_NAME.value =  BanName;
		DP_ID.value =  DpID;
		DP_NAME.value =  DpName;
		Depository.value =  Depo;
		Narration.value =  Narr;
		Delete.style.display = "";	
		DeleteData.value = "True";
		Batch_No.value	=	BatchNo;
		
		//Batch_No.style.display	=	"none";
		Batch_No.readOnly	=	false;
				
		if ( datafrom == "Screen" )
		{
			parent.REPORT_QUERY.location.href	=	"/BRANCH/BENEFICIARY/COMMON/PASSDATA.cfm?formName=VoucherEntryForm&fieldName=Scrip&fieldValue=" + ScrCode + "&prevFieldValue=";
		}
	}
}

function displayTrans()
{

}