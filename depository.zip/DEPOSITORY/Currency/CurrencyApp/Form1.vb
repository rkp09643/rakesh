﻿Imports System.Data.SqlClient
Imports System.Data.SqlTypes


Public Class Form1

    Public Sub New()

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.

    End Sub


    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim cmd As New SqlCommand
        Dim con As New SqlConnection
        Dim adp As New SqlDataAdapter
        Dim dt As New DataTable


        Dim a As MenuItem
        '"Data Source=techexcel;Initial Catalog=CURRENCY;Persist Security Info=True;User ID=sa;Password=sa"
        '---T Tradig , a- Account
        'M –Master ,T Transactions
        con.ConnectionString = "Data Source=techexcel;Initial Catalog=CURRENCY;Persist Security Info=True;User ID=sa;Password=sa"
        cmd.CommandText = "SELECT * FROM MENU_MASTER" & _
        " WHERE SEGMENT ='a' " & _
        "  AND COMPLETED ='Y'" & _
        " AND ISNULL(MARKET,'') !='CAPS'  " & _
        " AND TYPE = 't'  " & _
        " ORDER BY ORDERNO "

        cmd.Connection = con
        cmd.CommandType = CommandType.Text
        adp.SelectCommand = cmd
        adp.Fill(dt)


        If dt.Rows.Count > 0 Then
            For Each dr As DataRow In dt.Rows

                MenuStrip1.Items.Add(dr("Name"))
            Next
        End If



    End Sub
End Class
