DELETE FROM Nsdl_SlipBk_Issue_Master

UPDATE Nsdl_Bulk_Slip_Book_Master
SET
	flg_issued = 'N'

UPDATE Nsdl_Slip_Detail_Master	
SET
	Issued = 'N',
	Issue_BOID = NULL,
	IssueDate= NULL


INSERT INTO Nsdl_SlipBk_Issue_Master
  ( 
  	COCD,BookNo,From_SlipNo,To_SlipNo,BOID,IssueDate,
	Remark,Chargeable,ChrgAmt,LedgerBalance,LastTransactionDt,
	LastBillAmt,HoldScripCount,HoldScripValue,IssueMode,CourierCode,
	DeliveryPerson,Loose,UserId,IPAddr, SlipNoPreFix,Instruction_Code
  )
SELECT 'NSDL',BOOK_NO,CHM_FROMNO,CHM_TONO,CHM_CMCD,CHM_ISSUEDATE,
	NULL,'N',NULL,0,NULL,0,0,0,'HandDelivery',NULL,NULL,'N','IMPORT','127.0.0.1',
	CASE WHEN CHM_INSTCD = '901' THEN 'DMT'
		WHEN CHM_INSTCD = '904' THEN 'ATB'
		WHEN CHM_INSTCD = '906' THEN 'DLO1'
		WHEN CHM_INSTCD = '907' THEN 'INS'
		ELSE 'IDT' END AS SlipNoPreFix,Instruction_Code
FROM ESTROCLIENTMASTER.DBO.CHEQUEMASTER A , Nsdl_Bulk_Slip_Book_Master B
WHERE
	ISNULL(CHM_CMCD,'') <> '' 
AND CHM_INSTCD IN ('904','906','907','925','901')
AND B.FROMSLIPNO = A.CHM_FROMNO
AND A.CHM_TONO = B.TOSLIPNO
AND B.INSTRUCTION_CODE = A.CHM_INSTCD
AND A.CHM_BOOKSIZE = LOTSIZE


UPDATE Nsdl_Bulk_Slip_Book_Master
SET
	flg_issued = 'Y'
FROM ESTROCLIENTMASTER.DBO.CHEQUEMASTER A , Nsdl_Bulk_Slip_Book_Master B
WHERE
	ISNULL(CHM_CMCD,'') <> '' 
AND CHM_INSTCD IN ('904','906','907','925')
AND B.FROMSLIPNO = A.CHM_FROMNO
AND A.CHM_TONO = B.TOSLIPNO
AND B.INSTRUCTION_CODE = A.CHM_INSTCD
AND A.CHM_BOOKSIZE = LOTSIZE
AND B.COCD = 'NSDL'

