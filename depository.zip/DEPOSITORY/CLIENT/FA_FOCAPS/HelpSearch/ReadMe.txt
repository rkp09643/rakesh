Please Copy MultiClientsHelp.cfm into

C:\Inetpub\wwwroot\Client\FA_FOCAPS\HelpSearch Folder



Bhavesh