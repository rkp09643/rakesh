/* ****************************************************************
	FUNCTION FOR HIDING AND SHOWING THE STOCK POOL ACC DETAILS.
**************************************************************** */
function setOnLoad( )
{
	with( NewClientEntry )
	{
		ClientID.focus();
		CompanyGroupList.style.display = "None";
		CoGrpName.readOnly = true;
		CoGrpName.style.background = "Transparent";
		CoGrpName.style.color = "Purple";
	}
}


/* ******************************************************************************************
	FUNCTION FOR VALIDATING THE COMPANY GROUP ENTERED AND SETTING THE COMPANY GROUP-NAME.
****************************************************************************************** */
function chkCompanyGroup( form )
{
	with( form )
	{
		coGrpCode = CoGrpCode.value;
		if( ( coGrpCode != "" ) && ( coGrpCode.charAt(0) != " " ) )
		{
			parent.fraPaneBar.location.href = "/Client/DynamicFrame/Fra_Hide.cfm?ValidateCompanyGroup=Yes&DocFormObject=parent.Display.document.NewClientEntry&CoGrpCode=" +coGrpCode;
		}
		else
		{
			CoGrpName.value = "";
		}
	}
}


/* *************************************************************************
	FUNCTION FOR VALIDATING EMPTY FORM FIELDS BEFORE SUBMITING THE FORM.
************************************************************************* */
function chkForEmptyFields( form )
{
	var field, fieldName, fieldValue, fieldsCount = form.elements.length;
	
	with( form )
	{
		for( i = 0; i < fieldsCount; i++ )
		{
			field = elements[ i ];
			fieldName = field.name;
			fieldValue = field.value;
			
			if( ( i != 13 ) && ( i > 9 ) )
			{
				// GENERALIZED VALIDATION FOR ALL THE FORM FIELDS.
				if( ( fieldValue == "" ) || ( fieldValue.charAt ( 0 ) == " " ) )
				{
					alert( "Please enter a value for the field '" +fieldName +"'." );
					field.value = "";
					field.focus( );
					return false;
				}
			}
		}
	}
}


/* **********************************************
	CHANGING THE END-YEAR WHEN START CHANGES.
********************************************** */
function chkFinStartYear( form, currYear )
{
	with( form )
	{
		finStart = FinStart.value;
		if( ( finStart != "" ) && ( finStart.charAt(0) != " " ) )
		{
			finStart = parseInt( finStart );
			if( isNaN( finStart ) )
			{
				alert( "Please enter a Numeric Value." );
				FinStart.value = parseInt( currYear );
				FinStart.focus();
			}
			else
			{
				FinStart.value = finStart;
				FinEnd.value = ( finStart + 1 );
				StartDate.focus();
			}
		}
	}
}


/* *************************************************
	FOR HIDING/SHOWING USER HELPS WHEN REQUIRED.
************************************************* */
function showHideHelps( obj )
{
	if( obj == "Body" )
	{
		MainHelp.style.display = "";		
		COCDHelp.style.display ="None";			CoNameHelp.style.display ="None";
	}
	else if( obj.name == "COCD" )
	{
		MainHelp.style.display = "";		
		COCDHelp.style.display ="";				CoNameHelp.style.display ="None";
	}
	else if( obj.name == "CoName" )
	{
		MainHelp.style.display = "";		
		COCDHelp.style.display ="None";			CoNameHelp.style.display ="";
	}
}