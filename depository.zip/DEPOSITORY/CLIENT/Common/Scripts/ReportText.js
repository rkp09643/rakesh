function allhide(form)
{
	with ( form )
	{	
				Trading.style.display = "none";
				Account.style.display = "none";
				Stock.style.display = "none";
				Utility.style.display = "none";
	}
}
function Showhide(form,MName)
{
	with ( form )
	{
		if(MName == 'Trading')
		{
				
				if(Trading.style.display == 'none')
				{
					Trading.style.display = "";
				}
				else
				{
					Trading.style.display = "none";
				}
				Account.style.display = "none";
				Stock.style.display = "none";
				Utility.style.display = "none";
		}
		if(MName == 'Account')
		{
				
				if(Account.style.display == 'none')
				{
					Account.style.display = "";
				}
				else
				{
					Account.style.display = "none";
				}
				Trading.style.display = "none";
				Stock.style.display = "none";
				Utility.style.display = "none";
		}
		if(MName == 'Stock')
		{
				if(Stock.style.display == 'none')
				{
					Stock.style.display = "";
				}
				else
				{
					Stock.style.display = "none";
				}
				Trading.style.display = "none";
				Account.style.display = "none";
				Utility.style.display = "none";
		}
		if(MName == 'Utility')
		{
				if(Utility.style.display == 'none')
				{
					Utility.style.display = "";
				}
				else
				{
					Utility.style.display = "none";
				}
				Trading.style.display = "none";
				Account.style.display = "none";
				Stock.style.display = "none";
		}
	}	
}
function openReport( form, segment, btnName, btnValue, rptType )
{
	with ( form )
	{	
		var commonParam;
		ReportNo.value = rptType;
		ReportButtonName.value = btnName;
		ReportName.value = btnValue;
		ReportSegment.value = segment;

		commonParam = "COCD=" +COCD.value +"&CoName=" +CoName.value +"&CoGroup=" +CoGroup.value +"&StYr=" +FinStart.value +"&EndYr=" +FinEnd.value +"&CDSLPoolAccCode=" +CDSLPoolAccCode.value +"&CDSLDPID=" +CDSLDPID.value +"&CDSLDPName=" +CDSLDPName.value +"&NSDLPoolAccCode=" +NSDLPoolAccCode.value +"&NSDLDPID=" +NSDLDPID.value +"&NSDLDPName=" +NSDLDPName.value;
		if	( btnName == "cmdBenSummary" || btnName == "cmdBenDetail" )
		{
			ShowBeneficiary.value = "True";
		}
		
		if ( btnName == "cmdSTTCerticate" )
		{
			ShowRepGen.value = "True";
		}
		
		if ( Market.value == "CAPS" )
		{
			if ( btnName == "cmdSTTCerticate" || btnName == "cmdBenOffMarket" || btnName == "cmdBenInterDP")
			{
				ShowSetlNo.value = "False";
			}
		}

		if ( btnName == "cmdShortMargin")
		{
			ShowIncludeZero.value	=	"True";
		}
		if ( btnName == "cmdShortMargin1")
		{
			ShowSpanMargin.value	=	"True";
			Market.value = 'FO'; 
		}
		if ( btnName == "cmdBenSummary" )
		{
			//ShowViewType.value 		= "True";
			ShowInOutShort.value 	= "True";
			ShowWBrokBen.value		= "True";
		}
		
		if ( btnName == "cmdBenDetail" )
		{
			ShowFrmToDate.value	=	"True";
			ShowBranch.value	=	"True";
		}
		
		if	( btnName == "cmdmp1" || btnName == "cmdPreCont" || btnName == "cmdSaudaSum" || btnName == "cmdSaudaSumCIDDateWise" || btnName == "cmdSaudaSumCID2DateWise" || btnName == "cmdMulOSP" ||
			  btnName == "cmdMulOSPWoBill" || btnName == "cmdOSP" || btnName == "cmdCFOSP" )
		{
			ShowReportType.value	=	"True";
			ShowFamily.value 	=	"True";
			
		}
		
		if	( btnName == "cmdPreCont" ) //|| btnName == "cmdShortMargin"
		{
			ShowStationaryType.value = "True";
			ShowFileGenType.value = "False";
			if ( Market.value == "CAPS" )
			{
				ShowOrderByInContract.value = "True";
				ShowECNPrintInContract.value = "True";
			}
			ContraOption.value = "True";
			ShowClientNature.value = "True";
			ShowBranchwise.value = "False";
		}
	 
		if	( btnName == "cmdMulOSP" || btnName == "cmdMulOSPWoBill" )
		{
			ShowLastExpiry.value	=	"True";
			ShowFoType.value		=	"True";
			ShowOpenPrice.value		=	"True";
			ShowNetAmount.value		=	"True";
		}
		
		if	( 	   btnName == "cmdSaudaSum" || btnName == "cmdSaudaSumCIDDateWise" || btnName == "cmdSaudaSumCID2DateWise" || btnName == "cmdSaudaDet" || btnName == "cmdMulOSP" ||
				  btnName == "cmdMulOSPWoBill" || btnName == "cmdOSP"  || btnName == "cmdCFOSP"
			)
		{
			ShowPrintType.value	=	"True";
			if ( btnName != "cmdSaudaDet" )
			{
				ShowPaperSize.value	=	"True";
			}
		}
		
		if ( btnName == "cmdCFOSP" )
		{
			ShowLastTrDt.value = "True";
		}
		
		if	( 	( btnName == "cmdSaudaSum" || btnName == "cmdSaudaSumCIDDateWise" || btnName == "cmdSaudaSumCID2DateWise" || btnName == "cmdSaudaDet" || btnName == "cmdMulPreBill" || btnName == "cmdMulOSP" ||
				  btnName == "cmdMulOSPWoBill")
				 && Market.value == "FO"
			)
		{
			MultidateReport.value	=	"True";
		}
		if	( btnName == "cmdBenSummary")
		{
			MultidateReport.value	=	"True";
		}

		if ( btnName == "cmdSaudaSumCIDDateWise" )
		{
		 	if (Market.value == "CAPS")
			{
				MultidateReport.value	=	"True";
				ShowSetlNo.value		=	"False";
				ShowAbsolute.value		=	"True";
				/*if (Exchange.value == "BSE")
				{
				 	ShowVarMargin.value = "True";
				}*/
			}
		}
		
		/*if ( btnName == "cmdSaudaSum" )
		{
			if (Market.value == "CAPS")
			{
			 	ShowClientID2.value = "True";
			}
		}*/

		if  ( btnName == "cmdAcDet" || btnName == "cmdClDet" || btnName == "cmdJVReport" || btnName == "cmdSTTCerticate" || btnName == "cmdCashBankBook" )
		{
				MultidateReport.value	=	"True";
		}
		if  (  btnName == "cmdmp1"  )
		{
			if  ( btnName == "cmdOSP" ||  btnName == "cmdmp1" )
			{
				ShowSpanMargin.value	=	"True";
			}
			
		}
		if  (  btnName == "cmdOSP" || btnName == "cmdCFOSP" )
		{
			if  ( btnName == "cmdOSP" )
			{
				ShowSpanMargin.value	=	"True";
			}
			ShowIncludeZero.value	=	"True";			
		}
		
		if  ( btnName == "cmdmp1" )
		{
			ShowSpanMargin.value	=	"True";
		}

		if	( 	btnName == "cmdSaudaSum" && btnName == "cmdSaudaSumCIDDateWise" && btnName == "cmdSaudaSumCID2DateWise" &&	btnName == "cmdMulOSP"  && btnName == "cmdMulOSPWoBill")
		{
			ShowLedgerBal.value 		=	"True";
		}
		
		if ( btnName == "cmdClientPayOutToExport" )
		{
			ShowBatchNo.value 			=	"True";
			ShowSlipNo.value 			=	"True";
		}
		
		if ( btnName == "cmdCFOSP" )
		{
			ShowBFPercentage.value		=	"True";
		}
		
		if	( btnName == "cmdSaudaSum" || btnName == "cmdSaudaSumCIDDateWise" || btnName == "cmdSaudaSumCID2DateWise")
		{
			ShowBrokerage.value 	=	"True";
			ShowFontType.value		=	"True";
			ShowClPrice.value		=	"True";
			if ( btnName == "cmdSaudaSumCIDDateWise" )
			{
				ShowOpening.value		=	"True";
			}
			
			if ( Market.value == "FO" )
			{
				ShowTransactionType.value	=	"True";
				ShowBillAmount.value 		=	"True";
			}
		}

		if ( btnName == "cmdSaudaDet" )
		{
			ShowScripNet.value			=	"True";
			ShowSortOrder.value			=	"True";
			ShowOrderTradeNo.value		=	"True";
			ShowBrokerage.value			=	"True";
			if ( Market.value == "FO" )
			{
				ShowTransactionType.value	=	"True";
				ShowBillAmount.value 		=	"True";
			}
		}
		
		if ( btnName == "cmdSaudaSumCID2DateWise" )
		{
		 	if (Market.value == "CAPS")
			{
				MultidateReport.value	=	"True";
				ShowBranch.value		=	"False";
				ShowFamily.value		=	"False";
				ShowReportType.value 	= 	"False";
				ShowBrokerage.value		=	"False";
				ShowBranchwise.value	=	"False";
			 	ShowClientID2.value 	= 	"True";
				ShowScripFilter.value	=	"True";
				ShowSetlNo.value		=	"False";
				ShowClients.value		=	"False";				
				ShowAbsolute.value		=	"True";
				ShowOpening.value		=	"True";
			}
		}

		if ( btnName == "cmdSttCertificate" )
			{
				MultidateReport.value	=	"True";
				ShowFamily.value		=	"True";
			}

		if	( btnName == "cmdBillAbs" )
		{
			if ( Market.value == "FO" )
			{
				ShowBrokerage.value 	=	"False";
				ShowFontType.value		=	"False";
			}
			else
			{
				ShowBrokerage.value 	=	"True";
				ShowFontType.value		=	"True";
			}
			ShowBilledOrNot.value		=	"True";		
		}		
		
		if	( btnName == "cmdPlainBill"	)
		{
			ShowStationaryType.value = "True";
			//ShowPaperType.value = "True";
			if ( Market.value == "CAPS" )
			{
				ShowPrePrintedBillFormat.value = "True";
				ShowOrderByInContract.value = "True";
			}
			if ( Market.value == "FO" )
			{
				ShowNetMargin.value		=	"True";
				ShowNetFutMToM.value 	=	"True";
				ShowNetOption.value 	=	"True";
				//ShowFileGenType.value 	= 	"False";
				ShowPostingMarginAc.value = 	"True";
				ShowPrePrintedBillFormat.value = "True";
			}
		}
		if	( btnName == "cmdPreBill"	)
		{
			ShowStationaryType.value = "True";
			//ShowPaperType.value = "True";
			if ( Market.value == "CAPS" )
			{
				ShowPrePrintedBillFormat.value = "True";
				ShowOrderByInContract.value = "True";
			}
			if ( Market.value == "FO" )
			{
				ShowNetMargin.value		=	"True";
				ShowNetFutMToM.value 	=	"True";
				ShowNetOption.value 	=	"True";
				//ShowFileGenType.value 	= 	"True";
				ShowPostingMarginAc.value = 	"True";
				ShowPrePrintedBillFormat.value = "True";
			}
		}
		
		/*if ( btnName == "cmdPreBill" || btnName == "cmdPlainBill" || btnName == "cmdSaudaSum" || btnName == "cmdSaudaSumCIDDateWise")
		{
		 	ShowBranchwise.value	=	"False";
		}*/
		
		/*if ( Market.value == "FO" )
		{
			if ( btnName ==  "cmdSaudaDet" ||  btnName == "cmdmp1" ||btnName == "cmdOSP")
			{
				ShowBranchwise.value	=	"True";
			}
		}*/
		
		if	(  btnName == "cmdTB" || btnName == "cmdClientPayOut" || btnName == "cmdInterSet" || btnName == "cmdClientPayOutToExport"
			|| btnName == "cmdClSum" || btnName == "cmdOpSum" || btnName == "cmdGrpSum" || btnName == "cmdJVReport"
			|| btnName == "cmdBenOnMarket" || btnName == "cmdBenInterDP" || btnName == "cmdBenOffMarket"
			//|| btnName == "cmdPoolOnMarket" || btnName == "cmdPoolInterDP" || btnName == "cmdPoolOffMarket"
			)
			
		{
			ShowClientFilter.value 	=	"True";
			if	( btnName != "cmdClSum" )
			{
				ShowBranch.value 		=	"False";
				ShowClientFilter.value 	=	"False";
			}
			
				ShowClients.value 		=	"False";
							
			if ( btnName != "cmdGrpSum" && btnName != "cmdAcDet" && btnName != "cmdClDet" || btnName != "cmdCashBankBook")
			{
				ShowFamily.value 	=	"True";
			}
			if	( btnName == "cmdTB" || btnName == "cmdClSum" || btnName == "cmdOpSum" || btnName == "cmdGrpSum")
			{ 
				ShowNilBalance.value=	"True";
				ShowDrCrFilter.value=	"True";
			}
			
			if ( btnName == "cmdGrpSum" )
			{
				ShowAbsGrpWiseSum.value = "True";
			}
		}

		if ( btnName == "cmdAcDet" || btnName == "cmdClDet" || btnName == "cmdJVReport" || btnName == "cmdCashBankBook")
		{
			ShowNarration.value			=	"True";
			ShowFaTransType.value		=	"True";
			if ( btnName != "cmdJVReport" )
			{
				ShowFaVoucherOrder.value	=	"True";
				ShowFaPrintType.value		=	"True";
			}	
		}
		
		if ( btnName == "cmdAcDet")
		{
			ShowAccConfirmation.value = "True";
			ShowMarginBalance.value		=	"True";
		}
		
		if ( btnName == "cmdVPrint")
		{
			ShowBranch.value 		=	"False";
			ShowFamily.value		=	"False";
 			ShowClients.value 		=	"False";
			ShowAccountCode.value	=	"True";
			ShowVoucherNo.value		=	"True";
		}
		
		if ( btnName == "cmdCdsltoNsdlIntSetl")
		{
			ShowBranch.value 		=	"False";
			ShowFamily.value		=	"False";
 			ShowClients.value 		=	"False";
			ShowSerialNo.value 		=	"True";
			ShowPrintDate.value 	=	"True";
			ShowToSettlementNo.value=	"True";
			ShowPrintBatchNo.value	=	"True";
		}
		
		if ( btnName == "cmdCdsltoNsdlTrans")
		{
			ShowBranch.value 		=	"False";
			ShowFamily.value		=	"False";
 			ShowClients.value 		=	"False";
			ShowSerialNo.value 		=	"True";
			ShowPrintDate.value 	=	"True";
			ShowPrintBatchNo.value	=	"True";
		}

		if	( 	btnName == "cmdClientPayOut" || btnName == "cmdInterSet" || btnName == "cmdClientPayOutToExport" || 
				btnName == "cmdBenOnMarket" || btnName == "cmdBenOffMarket" || btnName == "cmdBenInterDP" || 
				btnName == "cmdPoolOnMarket" //|| btnName == "cmdPoolOffMarket" || btnName == "cmdPoolInterDP"
			)
		{
			ShowPrintDate.value 		=	"True";
			ShowExecDate.value 			=	"True";
			
			if	( btnName != "cmdClientPayOutToExport" )
			{
				ShowSerialNo.value 		=	"True";
			}
			
			if	( btnName == "cmdClientPayOut" )
			{
				ShowDepository.value	 =	"True";
				ShowClientType.value	 =	"True";
				ShowPrintBatchNo.value	=	"True";
				ShowFileGenOutType.value =  "True";
				ShowExecDate.value 		 =	"False";
				ShowFamily.value		=	"False";
			}
		
			if ( btnName == "cmdBenOffMarket" || btnName == "cmdBenInterDP" )
			{
				ShowFileGenOutType.value =	"True";
			}
			
			if ( btnName == "cmdBenOnMarket")
			{
				ShowDepository.value	=	"True";
				if ( Market.value == "CAPS" )
				{
					ShowExecDate.value 		 =	"False";
					ShowFileGenOutType.value =	"True";
					ShowPrintBatchNo.value	=	"True";
					ShowReversibleType.value =	"False";
					ShowBeneficiary.value = "True";
					ShowFamily.value		=	"False";
				}	
			}
			
			if ( btnName == "cmdPoolOnMarket")
			{
				ShowDepository.value	=	"True";
				if ( Market.value == "CAPS" )
				{
					ShowExecDate.value 		 =	"False";
					ShowFileGenOutType.value =	"True";
					ShowPrintBatchNo.value	=	"True";
					ShowReversibleType.value =	"True";
					ShowBranch.value 		=	"False";
					ShowFamily.value		=	"False";
 					ShowClients.value 		=	"False";
					ShowBeneficiary.value 	= "False";
				}	
			}

			if	( btnName == "cmdBenOffMarket" || btnName == "cmdBenInterDP" )
			{
				ShowPrintBatchNo.value	=	"True";
				ShowBeneficiary.value	=	"True";
			}
			
			if ( btnName == "cmdInterSet" )
			{
			 	ShowExecDate.value 		 =	"False";
				ShowFileGenOutType.value =	"True";
				//ShowIOSlipNo.value		 =	"False";
				ShowPrintBatchNo.value	=	"True";
			}
		}
		
		if	(
				btnName != "cmdFileUpload" || btnName != "cmdClientOverView" || btnName != "cmdRecVoucher"
			)
		{
			submit();
		}
		
		if	( btnName 	== "cmdFileUpload" )
		{
			uploadPath	=	"/Client/TradeUploads/";
			transParam	=	"COCD=" +COCD.value +"&CoName=" +CoName.value +"&CoGroup=" +CoGroup.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Client=&CDSLPoolAccCode=" +CDSLPoolAccCode.value +"&CDSLDPID=" +CDSLDPID.value +"&CDSLDPName=" +CDSLDPName.value +"&NSDLPoolAccCode=" +NSDLPoolAccCode.value +"&NSDLDPID=" +NSDLDPID.value +"&NSDLDPName=" +NSDLDPName.value;
			parent.parent.Display.location.href	=	uploadPath +"Upload.cfm?TemplateName=Trading_UploadsForm&" +transParam;		
		}
		
		if	( btnName 	== "cmdRecVoucher" )
		{
			mainPath	=	"/Client/FA_FOCAPS/Forms/"
			param		=	"COCD=" +COCD.value +"&CoName=" +CoName.value +"&CoGroup=" +CoGroup.value +"&StYr=" +FinStart.value +"&EndYr=" +FinEnd.value +"&CDSLPoolAccCode=" +CDSLPoolAccCode.value +"&CDSLDPID=" +CDSLDPID.value +"&CDSLDPName=" +CDSLDPName.value +"&NSDLPoolAccCode=" +NSDLPoolAccCode.value +"&NSDLDPID=" +NSDLDPID.value +"&NSDLDPName=" +NSDLDPName.value;
			parent.parent.Display.location.href	=	mainPath +"ReceiptPayment.cfm?TemplateName=Accounts_Receipt&Bank=Yes&TransactionType=Receipt&Tr_Type=R&" +param;
		}
		
		if	( btnName 	== "cmdSPrint" )
		{
			mainPath	=	"/Client/Text_Reports/"
			param		=	"COCD=" +COCD.value +"&CoName=" +CoName.value +"&CoGroup=" +CoGroup.value +"&StYr=" +FinStart.value +"&EndYr=" +FinEnd.value +"&CDSLPoolAccCode=" +CDSLPoolAccCode.value +"&CDSLDPID=" +CDSLDPID.value +"&CDSLDPName=" +CDSLDPName.value +"&NSDLPoolAccCode=" +NSDLPoolAccCode.value +"&NSDLDPID=" +NSDLDPID.value +"&NSDLDPName=" +NSDLDPName.value;
			parent.parent.Display.location.href	=	mainPath +"SlipPrinting.cfm?ReportName=Slip Printing&" +param+"&ReportType="+rptType;
		}
	}	
}

/*function setVarStatus( form )
{
	with (form)
	{
	 	if (withVarMrg.disabled)
		{	alert("K");
			withVarMrg.disabled == "False";
		}
	}
} */

function setMktSetlValue( form, mkt_Type, setl_No, trdt, setVal )	
{
	with ( form )
	{		
		if ( mkt_Type	!=	"" )
		{
			Mkt_Type.value		=	mkt_Type;
			Settlement_No.value	=	setl_No;
			From_Date.value		=	trdt;
			btnVal				=	ReportButtonName.value;
		}
		
		if( btnVal == "cmdCdsltoNsdlIntSetl" | btnVal == "cmdCdsltoNsdlTrans")
		{
			parent.parent.fraPaneBar.location.href = "/Client/DynamicFrame/Fra_Hide.cfm?FormObject=parent.Display.SubRPTMenu.document.SubReportParameters&FormName=ReportText&COCD=" + COCD.value + "&Market=" + Market.value +"&Exchange=" + Exchange.value +"&Mkt_Type=" + mkt_Type + "&Settlement_No=" + setl_No + "&Trade_Date=" + trdt + "&ReportName=" + btnVal + "&ReturnValue=SlipNo";
		}
		
		if ( setVal == "True" )
		{
			if ( btnVal == "cmdBenOnMarket" || btnVal == "cmdPoolOnMarket" )
			{
				if ( Depository[0].checked )
				{
					//alert("1");
					depo = "NSDL";					
				}
				else if ( Depository[1].checked )
				{
					///alert("2");
					depo = "CDSL";
				}
				else if ( Depository[2].checked )
				{
					//alert();
					depo = "Direct";
				}				
				
				if ( btnVal == "cmdBenOnMarket" )
				{
					var Ben;
					Ben = CmbBenID.value;
					parent.parent.fraPaneBar.location.href = "/Client/DynamicFrame/Fra_Hide.cfm?FormObject=parent.Display.SubRPTMenu.document.SubReportParameters&FormName=ReportText&COCD=" + COCD.value + "&Market=" + Market.value +"&Exchange=" + Exchange.value +"&Mkt_Type=" + mkt_Type + "&Settlement_No=" + setl_No + "&Depo=" + depo + "&ReportName=" + btnVal +  "&ReturnValue=SlipNo" + "&BenVal=" + Ben;
				}
				else
				{
					if ( RevType[0].checked )
					{
						payInType = 'PAYIN';
					}
					else
					{
						if ( Depository[0].checked )
						{
							payInType = 'NSDLEARLYPAYIN';
						}
						else
						{
							payInType = 'CDSLEARLYPAYIN';
						}
					}
					parent.parent.fraPaneBar.location.href = "/Client/DynamicFrame/Fra_Hide.cfm?FormObject=parent.Display.SubRPTMenu.document.SubReportParameters&FormName=ReportText&COCD=" + COCD.value + "&Market=" + Market.value +"&Exchange=" + Exchange.value +"&Mkt_Type=" + mkt_Type + "&Settlement_No=" + setl_No + "&Depo=" + depo + "&ReportName=" + btnVal + "&PayInType=" + payInType +  "&ReturnValue=SlipNo";
				}
			}		
		
			if ( btnVal == "cmdClientPayOut" )
			{
				if ( ClientType[0].checked )
				{
					ClType = "NSDL";					
				}
				else
				{
					ClType = "CDSL";
				}				
							
				if ( Depository[0].checked )
				{
					payInFrom = "NSDL";					
				}
				else
				{
					payInFrom = "CDSL";
				}
				parent.parent.fraPaneBar.location.href = "/Client/DynamicFrame/Fra_Hide.cfm?FormObject=parent.Display.SubRPTMenu.document.SubReportParameters&FormName=ReportText&COCD=" + COCD.value + "&Market=" + Market.value +"&Exchange=" + Exchange.value +"&Mkt_Type=" + mkt_Type + "&Settlement_No=" + setl_No + "&ClientType=" + ClType + "&ReportName=" + btnVal + "&PayInFrom=" + payInFrom + "&ReturnValue=SlipNo";
			}
		}
	}
}

function ValidateSlipNo(form, slipNo, source)
{
 	with (form)
	{
		parent.parent.fraPaneBar.location.href = "/Client/DynamicFrame/Fra_Hide.cfm?FormObject=parent.Display.SubRPTMenu.document.SubReportParameters&FormName=ReportText&COCD=" + COCD.value + "&Market=" + Market.value +"&Exchange=" + Exchange.value +"&SlipNo=" + slipNo + "&Source=" + source + "&RepBtn=" + ReportButtonName.value;
	}
}

function SetSlipNoVal(form)
{
	with (form)
	{
	 	Batch.style.display='';		
		txtSerialNo.value = CmbBatchNo.options.value;
		txtSerialNo.readOnly = true;
	}
}

function showHideBatch( form, ben_id, trdt )
{
	with (form)
	{
		parent.parent.fraPaneBar.location.href = "/Client/DynamicFrame/Fra_Hide.cfm?FormObject=parent.Display.SubRPTMenu.document.SubReportParameters&FormName=ReportText&COCD=" + COCD.value + "&Market=" + Market.value +"&Exchange=" + Exchange.value +"&Mkt_Type=&Settlement_No=&Trade_Date=" + trdt + "&BeneficiaryID=" + ben_id;//+"depository="+Depository;
	}
}

function setfilename( form, ben_id, trdt ,depository)
{
	with (form)
	{
		if(depository == true)
		{
			parent.parent.fraPaneBar.location.href = "/Client/DynamicFrame/Fra_Hide.cfm?FormObject=parent.Display.SubRPTMenu.document.SubReportParameters&FormName=ReportText&COCD=" + COCD.value + "&Market=" + Market.value +"&Exchange=" + Exchange.value +"&Mkt_Type=&Settlement_No=&Trade_Date=" + trdt + "&BeneficiaryID=" + ben_id+"&depository=Nsdl";
		}
		else
		{
			parent.parent.fraPaneBar.location.href = "/Client/DynamicFrame/Fra_Hide.cfm?FormObject=parent.Display.SubRPTMenu.document.SubReportParameters&FormName=ReportText&COCD=" + COCD.value + "&Market=" + Market.value +"&Exchange=" + Exchange.value +"&Mkt_Type=&Settlement_No=&Trade_Date=" + trdt + "&BeneficiaryID=" + ben_id+"&depository=Cdsl";
		}
	}
}

function showHideSlip( form, mkt_type, setl_No, btnVal )
{
	with (form)
	{
		if ( btnVal == "cmdInterSet" )
		{
			parent.parent.fraPaneBar.location.href = "/Client/DynamicFrame/Fra_Hide.cfm?FormObject=parent.Display.SubRPTMenu.document.SubReportParameters&FormName=ReportText&COCD=" + COCD.value + "&Market=" + Market.value +"&Exchange=" + Exchange.value +"&Mkt_Type=" + mkt_type + "&Settlement_No=" + setl_No + "&ReportName=" + btnVal +"&ReturnValue=SlipNo";
		}	
	}
}

function showHideVoucherNo( form, bankCode )
{
	with (form)
	{
		parent.parent.fraPaneBar.location.href = "/Client/DynamicFrame/Fra_Hide.cfm?FormObject=parent.Display.SubRPTMenu.document.SubReportParameters&FormName=ReportText&COCD=" + COCD.value + "&Market=" + Market.value +"&Exchange=" + Exchange.value +"&StYr=" +FinStart.value +"&EndYr=" +FinEnd.value + "&VDate=" + From_Date.value + "&BankCode=" + bankCode + "&ReturnValue=BankVoucherNo";
	}
}

function getLastExpiryDate( form, trdt )	
{
	with ( form )
	{
		if ( LastExpiry.checked )
		{
			parent.parent.fraPaneBar.location.href = "/Client/DynamicFrame/Fra_Hide.cfm?GetBranch=Yes&FormObject=parent.parent.Display.ReportParam&FormName=ReportText&GetLastExpiry=Yes&COCD=" + COCD.value + "&Market=" + Market.value +"&Exchange=" + Exchange.value +"&Trade_Date=" + trdt;
		}	
	}
}

function generateReport()
{
	with ( SubReportParameters )
	{
		var commonParam, lastExpiry, printType, DispBrk, DispLedBal, TransType, fontCondense, InShort, OutShort, VBen, VBroker, VType, SttRepGen,slipno,contraopt;

		commonParam 	= "COCD=" +COCD.value +"&CoName=" +CoName.value +"&CoGroup=" +CoGroup.value +"&Market=" + Market.value +"&Exchange=" + Exchange.value + "&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&CDSLPoolAccCode=" +CDSLPoolAccCode.value +"&CDSLDPID=" +CDSLDPID.value +"&CDSLDPName=" +CDSLDPName.value +"&NSDLPoolAccCode=" +NSDLPoolAccCode.value +"&NSDLDPID=" +NSDLDPID.value +"&NSDLDPName=" +NSDLDPName.value + "&ReportButtonName=" + ReportButtonName.value +"&PortName=" + PortName.value;
		lastExpiry		=	"No";
		printType		=	"C";
		DispBrk			=	"N";
		DispBill		=	"N";
		DispLedBal		=	"N";
		TransType		=	"";
		fontCondense	=	"N";
		PaperSize		=	"Full";
		NilBal			=	"0";
		Depo			=	"NSDL";
		CType			=	"NSDL";
		netMar			=	"N";
		netFut			=	"N";
		netOpt			=	"N";
		narr			=	"True";
		ord				=	"S";
		vType 			=	"'R','P','J','SJ'";
		faPrintType 	= 	"C";
		DispOrd			=	"Y";
		DispScripNet	=	"Y";
		foType			=	"FO";
		inclZero		=	"N";
		spanMg			=	"N";
		fileType		=	"T";
		branchwiseFile	= 	"N";
		gentype			=	"Mail";
		withBfPrice		=	"False";
		outputType		=	"Print";
		NetAmount 		= 	"True";
		batchNo			=	"";
		InShort			=	'N';
		OutShort		=	'N';
		VBen			=	'N';
		VBroker			=	'N';
		PayInFrm		=	"";
		slipno			=	0;
		contraopt		=	"Detail";
				
		NsdlFileName	=	NsdlDpFileName.value;
		CdslFileName	=	CdslDpFileName.value;
		clientNature	=	"C";
		
		if ( ShowStationaryType.value == "True" )
		{
			stationary = optStationary.value;
			/*if ( optStationary[0].checked )
			{
				stationary = 'L';
			}
			
			if ( optStationary[1].checked )
			{
				stationary = 'S';
			}*/
		}
		
		if ( ShowReversibleType.value == "True" )
		{
			if ( RevType[0].checked )
			{
				RT = '00';
			}
			else if ( RevType[1].checked )
			{
				RT = '01';
			}
		}
		
		if ( ShowAbsolute.value == "True" )
		{
			if ( optAbsolute.checked )
			{
				Absolute = 'Y';
			}
			else
			{
				Absolute = 'N';
			}
		}
		
		if ( ShowOpening.value == "True" )
		{
			if ( optOpening.checked )
			{
				Opening = 'Y';
			}
			else
			{
				Opening = 'N';
			}
		}
					
		if ( ShowFileGenOutType.value == "True" )
		{
			/*if (OutType[0].checked)
			{
				OutputType = 'P';
			}
			else if (OutType[1].checked)
			{
				OutputType = 'F';
			}*/
		}
		
		if ( ShowRepGen.value == "True" )
		{
			SttRepGen = optSttRep.value;
			/*if (optSttRep[0].checked)
			{
				SttRepGen = 'I';
			}
			else
			{
				SttRepGen = 'S';
			}*/
		}

		if ( ShowClPrice.value == "True" )
		{		
			if ( withPur.checked )
			{
				WithPurchase = 'Y';
			}
			else
			{
				WithPurchase = 'N';
			}
		
			if ( withSale.checked )
			{
				WithSale = 'Y';
			}
			else
			{
				WithSale = 'N';
			}
		}
				
		//if (!( withPur.checked ) & !( withSale.checked ))
		//{
		//	WithPurchase = 'Y';
		//	WithSale = 'Y';
		//}
		
		if ( ShowInOutShort.value == "True" | ShowWBrokBen.value == "True" )
		{
			if (chkInShort.checked)
			{
				InShort = 'Y';
			}
			
			if (chkOutShort.checked)
			{
				OutShort = 'Y';
			}
			
			if (chkBroker.checked)
			{
				VBroker = 'Y';
			}
			
			if (chkBen.checked)
			{
				VBen = 'Y';
			}
		}
		
		//cmdGenerate.disabled = true;
		
		if 	( ShowPrintType.value == "True")
		{
			printType = PrintType.value;
			/*if ( PrintType[0].checked )
			{
				printType	=	"P";
			}*/
		}

		if 	( ShowBrokerage.value == "True")
		{
			DispBrk = Brokerage.value;
			/*if ( Brokerage[0].checked )
			{
				DispBrk		=	"Y";
			}*/
		}

		if 	( ShowBillAmount.value == "True")
		{
			DispBill = BillAmount.value;
			/*if ( BillAmount[0].checked )
			{
				DispBill	=	"Y";
			}*/
		}
		
		if 	( ShowLedgerBal.value == "True")
		{
			DispLedBal = LedgerBal.value;
			/*if ( LedgerBal[0].checked )
			{
				DispLedBal	=	"Y";
			}*/
		}

		if 	( ShowTransactionType.value == "True")
		{
			TransType = TransactionType.value;
			/*if ( TransactionType[1].checked )
			{
				TransType	=	"N";
			}
			
			if ( TransactionType[0].checked )
			{
				TransType	=	"Y";
			}*/	
		}
		
		if 	( ShowFoType.value == "True")
		{
			foType = FoType.value;
			/*if ( FoType[0].checked )
			{
				foType	=	"F";
			}
			
			if ( FoType[1].checked )
			{
				foType	=	"O";
			}*/
		}
		
		if 	( ShowNilBalance.value == "True")
		{
			NilBal   =  NilBalance.value;
			/*if ( NilBalance[1].checked )
			{
				NilBal		=	"-1";
			}*/
		}
		
		if 	( ShowFontType.value == "True")
		{
			fontCondense = FontType.value;
			/*if ( FontType[1].checked )
			{
				fontCondense	=	"Y";
			}*/
		}

		if 	( ShowDepository.value == "True")
		{
			if ( Depository[0].checked )
			{
				Depo	=	"NSDL";
			}
			else if ( Depository[1].checked )
			{
				Depo	=	"CDSL";
			}
			else if ( Depository[2].checked )
			{
				Depo	=	"Direct";
			}
		}

		if 	( ShowClientType.value == "True")
		{
			if ( ClientType[0].checked )
			{
				CType	=	"NSDL";
			}
			else if ( ClientType[1].checked )
			{
				CType	=	"CDSL";
			}
		}
		
		if 	( ShowPaperSize.value == "True")
		{
			if ( Papersize[1].checked )
			{
				PaperSize	=	"Half";
			}
		}
		
		if	( ReportButtonName.value == "cmdMulOSP" || ReportButtonName.value == "cmdMulOSPWoBill" )
		{
			if ( LastExpiry.checked )
			{
				lastExpiry	=	"Yes";
			}
		}

		if 	( ShowNetMargin.value == "True")
		{
			netMar = NetMargin.value;
			/*if ( NetMargin[0].checked )
			{
				netMar		=	"Y";
			}*/
		}

		if 	( ShowNetFutMToM.value == "True")
		{
			netFut = FutMTOM.value;
			/*if ( FutMTOM[0].checked )
			{
				netFut		=	"Y";
			}*/
		}

		if 	( ShowNetOption.value == "True")
		{
			netOpt = NetOption.value;
			/*if ( NetOption[0].checked )
			{
				netOpt		=	"Y";
			}*/
		}
		
		if 	( ShowIncludeZero.value == "True")
		{
			inclZero = IncludeZero.value;
			/*if ( IncludeZero[0].checked )
			{
				inclZero	=	"Y";
			}*/
		}
		
		if 	( ShowSpanMargin.value == "True")
		{
			spanMg = ShowSpan.value;
			/*if ( ShowSpan[0].checked )
			{
				spanMg		=	"Y";
			}*/
		}
		
		if ( ShowNarration.value == "True" )
		{	
			narr = Narration.value;
			/*if ( Narration[1].checked )
			{
				narr 		=	"False";
			}*/
		}

		if ( ShowFaVoucherOrder.value == "True" )
		{
			ord = VoucherOrder.value;
			/*if ( VoucherOrder[1].checked )
			{
				ord 		=	"M";
			}*/
		}

		if ( ShowFaTransType.value == "True" )
		{
			vType		=	"";
			if ( VoucherType[0].checked )
			{
				vType 	=	"'R'";	  
			}
			if ( VoucherType[1].checked )
			{
				vType 	=	vType + ",'P'";
			}
			if ( VoucherType[2].checked )
			{
				vType 	=	vType + ",'J'";
			}
			if ( VoucherType[3].checked )
			{
				vType 	=	vType + ",'SJ'";
			}
			
		}
		
		if ( ShowFaPrintType.value == "True" )
		{
			faPrintType = FaPrintType.value;
			/*if ( FaPrintType[0].checked )
			{
				faPrintType = "P";
			}*/
		}
		
		DispOrd		=	"Y";
		if ( ShowOrderTradeNo.value	==	"True" )
		{
			DispOrd = DispOrderNo.value;
			/*if ( DispOrderNo[1].checked )
			{
				DispOrd		=	"N";
			}*/
		}
		
		if ( ShowScripNet.value	==	"True" )
		{
			DispScripNet = ScripwiseNet.value;
			/*if ( ScripwiseNet[1].checked )
			{
				DispScripNet =	"N";
			}*/
		}
		
		if 	( ShowReportType.value == "True")
		{
			/*if ( FileType[1].checked )
			{
				fileType	=	"E";
			}
			if ( FileType[2].checked )
			{
				fileType	=	"EM";
			}*/
			fileType =  FileType.value;
			outputType = OutputType.value;
			/*if ( OutputType[0].checked )
			{
				outputType	=	"Screen";
			}
			else if ( OutputType[1].checked )
			{
				outputType	=	"Print";
			}*/
		}
		
		if ( ShowPayInFrom.value == "True" )
		{
			if ( PayInFrom[0].checked )
			{
				PayInFrm = "Ben";
			}
			else if ( PayInFrom[1].checked )
			{
				PayInFrm = "Pool";
			}
		}	

		if ( ShowBranchwise.value == "True" )
		{
			if ( Branchwise.checked )
			{
				branchwiseFile = "Y";
			}
		}

		if ( ShowOpenPrice.value == "True" )
		{
			if ( BFPrice.checked )
			{
				withBfPrice = "True";
			}
		}

		if ( ShowNetAmount.value == "True" )
		{
			NetAmount =  withNetAmount.value;
			/*if ( withNetAmount[1].checked )
			{
				NetAmount = "False";
			}*/
		}
		
		if ( ShowPrintBatchNo.value == "True" )
		{
			if ( BatchNo[1].checked )
			{
				batchNo	=	CmbBatchNo.value;
			}
		}
		
		if ( ShowFileGenType.value == "True" )
		{
			gentype = GenType.value;
			/*if ( GenType[0].checked)
			{
				gentype = "Mail";
			}
			else
			{
				gentype = "File";
			}*/
		}
		if ( ShowBilledOrNot.value == "True" )
		{
			LedgerOp = BilledOrAll.value;
			/*if ( BilledOrAll[0].checked)
			{
				LedgerOp = "Billed";
			}
			else
			{
				 LedgerOp = "All";
			}*/
		}
		if ( ContraOption.value == "True")	
		{
			contraopt =  OptContra.value;
			/*if ( OptContra[0].checked )
			{
				contraopt = "Detail";
			}
			else if ( OptContra[1].checked )
			{
				contraopt = "Order";
			}
			else if ( OptContra[2].checked )
			{
				contraopt = "Net";
			}
			else if ( OptContra[3].checked )
			{
				contraopt = "SINGLE";
			}*/
		}
		
		if 	( ShowClientNature.value == "True")
		{
			clientNature = OptClient_Nature.value;
			/*if ( OptClient_Nature[1].checked )
			{
				clientNature	=	"I";
			}*/
		}
		
		billFormat = "D";
		if ( ShowPrePrintedBillFormat.value == "True" )
		{
			billFormat = optBillFormat.value;
			/*billFormat = "D";
			if (optBillFormat[1].checked)
			{
				billFormat = 'S';
			}*/
		}

		webXContract = "N";
		if ( ShowECNPrintInContract.value == "True" )
		{
			webXContract = optWebXContract.value;
			/*if (optWebXContract[0].checked)
			{
				webXContract = 'Y';
			}*/
		}

		orderBy = "Family";
		if ( ShowOrderByInContract.value == "True" )
		{
			orderBy = optOrderByInContract.value;
			/*if (optOrderByInContract[1].checked)
			{
				orderBy = 'Client';
			}*/
		}
		
		withMarginAc = "N";
		if ( ShowPostingMarginAc.value == "True" )
		{
			withMarginAc =  optShowMarginAcBalance.value;
			/*if (optShowMarginAcBalance[0].checked)
			{
				withMarginAc = 'Y';
			}*/
		}
		/*Pre-Printed Contract*/
		if ( ReportButtonName.value == "cmdPreCont" )
		{
			contType = "";
			contType1 = "";
			
			if ( ContractType.value	==	"C1" )
			{								 
				contType1 = "Type1";
			}
			else if( ContractType.value	==	"C2" )
			{
				contType1 = "Type2";
			}
			else
			{
				contType1 = ContractType.value;
			}

			if ( ContractType.value	==	"C2" )
			{								
				contType = "A4";
				contType1 = "";
			}
			//alert(webXContract);
			if ( fileType	==	"T" )
			{
				if ( branchwiseFile == "N")
				{
					
					if (COCD.value == "MCX")
					{
						FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/MCXPrePrintedContractTextType1.cfm?" + commonParam +"&Client="+ txtBranch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&ContractNo=&From_Date=" + From_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&Type=Detail&PrintDate=&ReportType &ShowNet=&Title=&Order=&RepID=" +ReportNo.value + "&StationaryType=" + stationary +"&ContraOpt="+ contraopt;
					}	
					else if (COCD.value == "NCDEX")
					{
						FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/NCDXPrePrintedContractTextType1.cfm?" + commonParam +"&Client="+ txtBranch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&ContractNo=&From_Date=" + From_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&Type=Detail&PrintDate=&ReportType &ShowNet=&Title=&Order=&RepID=" +ReportNo.value + "&StationaryType=" + stationary +"&ContraOpt="+ contraopt;
					}
					else
					{
						FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/" + contType + "PrePrintedContractText" + contType1 +".cfm?" + commonParam +"&Client="+ txtBranch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&ContractNo=&From_Date=" + From_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&Type=Detail&PrintDate=&ReportType &ShowNet=&Title=&Order=&RepID=" +ReportNo.value + "&StationaryType=" + stationary +"&Client_Nature=" + clientNature +"&ContraOpt="+ contraopt+"&webXContract=" + webXContract +"&orderBy="+orderBy;
					}
				}
				else
				{
					FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/" + contType + "PrePrintedContractText_MailBranchwise.cfm?" + commonParam +"&Client="+ txtBranch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&ContractNo=&From_Date=" + From_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&Type=Detail&PrintDate=&ReportType &ShowNet=&Title=&Order=&RepID=" +ReportNo.value + "&StationaryType=" + stationary +"&Branchwise=" + branchwiseFile +"&GenrationType="+ gentype +"&ContraOpt="+ contraopt;
				}				
			}
			else
			{
				FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/"+ COCD.value +"ContractHTML.cfm?" + commonParam +"&Client="+ txtBranch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&ContractNo=&From_Date=" + From_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&Type=Detail&PrintDate=&ReportType=&ShowNet=&Title=&Order=&RepID=" +ReportNo.value + "&StationaryType=" + stationary +"&ContraOpt="+ contraopt+"&webXContract=" + webXContract ;			
			}
		}
		
		/*Pre-Printed Bill*/
		if ( ReportButtonName.value == "cmdPreBill" )
		{
			//alert(ReportButtonName.value)
			if ( BillType.value	==	"BILL1" )
			{								 
				billType = "Type1";
			}
			else if( BillType.value	==	"BILL2" )
			{
				billType = "Type2";
			}
			else
			{
				billType = "Type3";			
			}
			/*if (optPaperType[0].checked)
			{
				paperType = 'Printed';
			}
			if (optPaperType[1].checked)
			{
				paperType = 'Plain';
			}*/
			
			//if (paperType == 'Printed')
			//{
				if (COCD.value == "NCDEX")
				{
					FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/NCDXPrePrintedBillText" + billType +".cfm?" + commonParam +"&Client="+ txtBranch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=&From_Date=" + From_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&Type=Detail&PrintDate=&ReportType=&ShowNet=&Title=&Order=&ShowNetMargin="+ netMar +"&ShowNetFuture="+ netFut +"&ShowNetOption="+ netOpt +"&RepID=" +ReportNo.value+"&Branchwise=" + branchwiseFile +"&StationaryType="+ stationary;
				}
				else
				{
						
					if (Market.value == "FO")
					{
						if ( branchwiseFile == "Y")
						{
							if (gentype == "Mail")
							{
								FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/PrePrintedBillText" + billType +"_MailBranchwise.cfm?" + commonParam +"&Client="+ txtBranch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=&From_Date=" + From_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&Type=Detail&PrintDate=&ReportType=&ShowNet=&Title=&Order=&ShowNetMargin="+ netMar +"&ShowNetFuture="+ netFut +"&ShowNetOption="+ netOpt +"&RepID=" +ReportNo.value +"&Branchwise=" + branchwiseFile+"&GenrationType="+ gentype +"&orderBy="+orderBy + "&withMarginAc=" + withMarginAc;
							}
							else
							{
								FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/PrePrintedBillText" + billType +"_MailBranchwise.cfm?" + commonParam +"&Client="+ txtBranch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=&From_Date=" + From_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&Type=Detail&PrintDate=&ReportType=&ShowNet=&Title=&Order=&ShowNetMargin="+ netMar +"&ShowNetFuture="+ netFut +"&ShowNetOption="+ netOpt +"&RepID=" +ReportNo.value +"&Branchwise=" + branchwiseFile+"&GenrationType="+ gentype+"&StationaryType="+ stationary + "&BillFormat=" + billFormat +"&orderBy="+orderBy + "&withMarginAc=" + withMarginAc;
							}						
						}
						else
						{
							FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/PrePrintedBillText" + billType +".cfm?" + commonParam +"&Client="+ txtBranch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=&From_Date=" + From_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&Type=Detail&PrintDate=&ReportType=&ShowNet=&Title=&Order=&ShowNetMargin="+ netMar +"&ShowNetFuture="+ netFut +"&ShowNetOption="+ netOpt +"&RepID=" +ReportNo.value+"&StationaryType="+ stationary +"&BillFormat=" + billFormat +"&orderBy="+orderBy + "&withMarginAc=" + withMarginAc;	
						}					
					}						
					else
					{
						FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/PrePrintedBillText" + billType +".cfm?" + commonParam +"&Client="+ txtBranch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=&From_Date=" + From_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&Type=Detail&PrintDate=&ReportType=&ShowNet=&Title=&Order=&ShowNetMargin="+ netMar +"&ShowNetFuture="+ netFut +"&ShowNetOption="+ netOpt +"&RepID=" +ReportNo.value +"&Branchwise=" + branchwiseFile+"&StationaryType="+ stationary+"&BillFormat=" + billFormat+"&orderBy="+orderBy;
					}
				}
				/*if (COCD.value == "NCDEX")
				{
					FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/NCDXPrePrintedBillText" + billType +".cfm?" + commonParam +"&Client="+ txtBranch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=&From_Date=" + From_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&Type=Detail&PrintDate=&ReportType=&ShowNet=&Title=&Order=&ShowNetMargin="+ netMar +"&ShowNetFuture="+ netFut +"&ShowNetOption="+ netOpt +"&RepID=" +ReportNo.value+"&Branchwise=" + branchwiseFile;
				}
				else
				{
					FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/PrePrintedBillText" + billType +".cfm?" + commonParam +"&Client="+ txtBranch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=&From_Date=" + From_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&Type=Detail&PrintDate=&ReportType=&ShowNet=&Title=&Order=&ShowNetMargin="+ netMar +"&ShowNetFuture="+ netFut +"&ShowNetOption="+ netOpt +"&RepID=" +ReportNo.value +"&Branchwise=";
				}*/
			//}
			/*else
			{
				FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/PlainBillText.cfm?" + commonParam +"&Client="+ txtBranch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=&From_Date=" + From_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&Type=Detail&PrintDate=&ReportType=&ShowNet=&Title=&Order=&ShowNetMargin="+ netMar +"&ShowNetFuture="+ netFut +"&ShowNetOption="+ netOpt +"&RepID=" +ReportNo.value +"&Branchwise=" + branchwiseFile;
			}*/	
		}
		/*For Plain Bill*/
		
		if ( ReportButtonName.value == "cmdPlainBill" )
		{
			billFormat = optBillFormat.value;
/*			if ( BillType.value	==	"BILL1" )
			{								 
				billType = "Type1";
			}
			else if( BillType.value	==	"BILL2" )
			{
				billType = "Type2";
			}
			else
			{
				billType = "Type3";			
			}*/
			if(chkplainsummary.checked)
			{
					Summary = 1;
			}
			else
			{
					Summary = 0;
			}

			billType = "Type1";

				if (COCD.value == "NCDEX")
				{
					FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/NCDXPrePrintedBillText" + billType +".cfm?" + commonParam +"&Client="+ txtBranch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=&From_Date=" + From_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&Type=Detail&PrintDate=&ReportType=&ShowNet=&Title=&Order=&ShowNetMargin="+ netMar +"&ShowNetFuture="+ netFut +"&ShowNetOption="+ netOpt +"&RepID=" +ReportNo.value+"&Branchwise=" + branchwiseFile +"&StationaryType="+ stationary;
				}
				else
				{
					if (Market.value == "FO")
					{
						if ( branchwiseFile == "Y")
						{
							if (gentype == "Mail")
							{
								FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/PrePrintedBillText" + billType +"_MailBranchwise.cfm?" + commonParam +"&Client="+ txtBranch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=&From_Date=" + From_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&Type=Detail&PrintDate=&ReportType=&ShowNet=&Title=&Order=&ShowNetMargin="+ netMar +"&ShowNetFuture="+ netFut +"&ShowNetOption="+ netOpt +"&RepID=" +ReportNo.value +"&Branchwise=" + branchwiseFile+"&GenrationType="+ gentype +"&orderBy="+orderBy + "&withMarginAc=" + withMarginAc;
							}
							else
							{
								FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/PrePrintedBillText" + billType +"_MailBranchwise.cfm?" + commonParam +"&Client="+ txtBranch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=&From_Date=" + From_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&Type=Detail&PrintDate=&ReportType=&ShowNet=&Title=&Order=&ShowNetMargin="+ netMar +"&ShowNetFuture="+ netFut +"&ShowNetOption="+ netOpt +"&RepID=" +ReportNo.value +"&Branchwise=" + branchwiseFile+"&GenrationType="+ gentype+"&StationaryType="+ stationary + "&BillFormat=" + billFormat +"&orderBy="+orderBy + "&withMarginAc=" + withMarginAc;
							}						
						}
						else
						{
							FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/PrePrintedBillText" + billType +".cfm?" + commonParam +"&Client="+ txtBranch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=&From_Date=" + From_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&Type=Detail&PrintDate=&ReportType=&ShowNet=&Title=&Order=&ShowNetMargin="+ netMar +"&ShowNetFuture="+ netFut +"&ShowNetOption="+ netOpt +"&RepID=" +ReportNo.value+"&StationaryType="+ stationary +"&BillFormat=" + billFormat +"&orderBy="+orderBy + "&withMarginAc=" + withMarginAc+"&Summary="+Summary;	
						}					
					}						
					else
					{
						FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/PrePrintedBillText" + billType +".cfm?" + commonParam +"&Client="+ txtBranch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=&From_Date=" + From_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&Type=Detail&PrintDate=&ReportType=&ShowNet=&Title=&Order=&ShowNetMargin="+ netMar +"&ShowNetFuture="+ netFut +"&ShowNetOption="+ netOpt +"&RepID=" +ReportNo.value +"&Branchwise=" + branchwiseFile+"&StationaryType="+ stationary+"&BillFormat=" + billFormat+"&orderBy="+orderBy;
					}
				}
				/*if (COCD.value == "NCDEX")
				{
					FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/NCDXPrePrintedBillText" + billType +".cfm?" + commonParam +"&Client="+ txtBranch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=&From_Date=" + From_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&Type=Detail&PrintDate=&ReportType=&ShowNet=&Title=&Order=&ShowNetMargin="+ netMar +"&ShowNetFuture="+ netFut +"&ShowNetOption="+ netOpt +"&RepID=" +ReportNo.value+"&Branchwise=" + branchwiseFile;
				}
				else
				{
					FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/PrePrintedBillText" + billType +".cfm?" + commonParam +"&Client="+ txtBranch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=&From_Date=" + From_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&Type=Detail&PrintDate=&ReportType=&ShowNet=&Title=&Order=&ShowNetMargin="+ netMar +"&ShowNetFuture="+ netFut +"&ShowNetOption="+ netOpt +"&RepID=" +ReportNo.value +"&Branchwise=";
				}*/
			//}
			/*else
			{
				FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/PlainBillText.cfm?" + commonParam +"&Client="+ txtBranch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=&From_Date=" + From_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&Type=Detail&PrintDate=&ReportType=&ShowNet=&Title=&Order=&ShowNetMargin="+ netMar +"&ShowNetFuture="+ netFut +"&ShowNetOption="+ netOpt +"&RepID=" +ReportNo.value +"&Branchwise=" + branchwiseFile;
			}*/	
		}

		/*Pre-Printed Bill*/
		if ( ReportButtonName.value == "cmdMulPreBill" )
		{
			FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/PrePrintedBillText.cfm?" + commonParam +"&Client="+ txtBranch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=&From_Date=" + From_Date.value +"&To_Date=" + To_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&Type=Detail&PrintDate=&ReportType=&ShowNet=&Title=&Order=&RepID=" +ReportNo.value;
		}
		
		/*Sauda Summary */
		if ( ReportButtonName.value == "cmdSaudaSum" )
		{
			if ( Market.value == "CAPS")
			{
				FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/Transaction_Summary.cfm?" + commonParam +"&fileType="+ fileType +"&Client="+ txtBranch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=&From_Date=" + From_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&PrintType=" + printType +"&DispBrk=" + DispBrk +"&DispLedBal=" + DispLedBal +"&fontCondense=" + fontCondense +"&PaperSize=" + PaperSize +"&RepID=" +ReportNo.value +"&Output=" + outputType +"&Branchwise=" + branchwiseFile + "&WithSale=" + WithSale + "&WithPurchase=" + WithPurchase; // + "&ClientID2=" + txtClientID2.value
			}
			else
			{
				FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/Transaction_Summary.cfm?" + commonParam +"&fileType="+ fileType +"&Client="+ txtBranch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=&From_Date=" + From_Date.value +"&To_Date=" + To_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&PrintType=" + printType +"&DispBrk=" + DispBrk +"&DispLedBal=" + DispLedBal +"&DispBill=" + DispBill + "&TransType=" + TransType +"&fontCondense=" + fontCondense +"&Output=" + outputType +"&PaperSize=" + PaperSize +"&RepID=" +ReportNo.value +"&Branchwise=" + branchwiseFile + "&WithSale=" + WithSale + "&WithPurchase=" + WithPurchase;
			}	
		}
		
		if ( ReportButtonName.value == "cmdSaudaSumCIDDateWise" )
		{
			if ( Market.value == "CAPS")
			{
				FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/Transaction_Summary_CID.cfm?" + commonParam +"&fileType="+ fileType +"&Client="+ txtBranch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=&From_Date=" + From_Date.value + "&To_Date=" + To_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&PrintType=" + printType +"&DispBrk=" + DispBrk +"&DispLedBal=" + DispLedBal +"&fontCondense=" + fontCondense +"&PaperSize=" + PaperSize +"&RepID=" +ReportNo.value +"&Output=" + outputType +"&Branchwise=" + branchwiseFile + "&WithSale=" + WithSale + "&WithPurchase=" + WithPurchase + "&Opening=" + Opening + "&Absolute=" + Absolute; // + "&ClientID2=" + txtClientID2.value
			}
		}
		
		if ( ReportButtonName.value == "cmdSaudaSumCID2DateWise" )
		{
			if ( Market.value == "CAPS")
			{
				FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/Transaction_Summary_CID2.cfm?" + commonParam +"&fileType="+ fileType +"&Client="+ "&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value + "&ToClient=&BillNo=&From_Date=" + From_Date.value + "&To_Date=" + To_Date.value +"&BranchID=" + "&FamilyGroup=" + "&PrintType=" + printType +"&DispBrk=" + DispBrk +"&DispLedBal=" + DispLedBal +"&fontCondense=" + fontCondense +"&PaperSize=" + PaperSize +"&RepID=" +ReportNo.value +"&Output=" + outputType +"&Branchwise=" + branchwiseFile + "&WithSale=" + WithSale + "&WithPurchase=" + WithPurchase + "&ClientID2=" + txtClientID2.value + "&Scrip=" + FromSymbol.value + "&Absolute=" + Absolute + "&Opening=" + Opening; //"&FromClient=" +escape( FromClient.value ) +
			}
		}
		
			/*Sauda Detail */
		if ( ReportButtonName.value == "cmdSaudaDet" )
		{
			if ( Market.value == "CAPS")
			{
				FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/Transaction_Detail.cfm?" + commonParam +"&Client=&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=&From_Date=" + From_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&PrintType=" + printType +"&DispBrk=" + DispBrk +"&DispLedBal=" + DispLedBal +"&fontCondense=" + fontCondense +"&PaperSize=" + PaperSize +"&ShowScripWiseNet=" + DispScripNet +"&ShowOrderNo=" + DispOrd +"&RepID=" +ReportNo.value;
			}
			else
			{
				FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/Transaction_Detail.cfm?" + commonParam +"&Client="+ txtBranch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=&From_Date=" + From_Date.value +"&To_Date=" + To_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&PrintType=" + printType +"&DispBrk=" + DispBrk +"&DispLedBal=" + DispLedBal +"&DispBill=" + DispBill + "&TransType=" + TransType +"&ShowScripWiseNet=" + DispScripNet +"&ShowOrderNo=" + DispOrd +"&RepID=" +ReportNo.value + "&Branchwise=" + branchwiseFile;
			}
		}
		
		/* Bill Absolute Summary */		
		if ( ReportButtonName.value == "cmdBillAbs" )
		{
			if ( Market.value == "CAPS")
			{
				FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/BillAbsSummary.cfm?" + commonParam +"&Client="+ txtBranch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=&From_Date=" + From_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&DispBrk=" + DispBrk +"&DispLedBal=" + DispLedBal +"&PaperSize=" + PaperSize +"&fontCondense=" + fontCondense +"&RepID=" +ReportNo.value+"&LedgerOp="+LedgerOp;
			}	
			else
			{
				FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/BillAbsSummary.cfm?" + commonParam +"&Client="+ txtBranch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=&From_Date=" + From_Date.value +"&To_Date=" + To_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&PrintType=" + printType +"&DispBrk=" + DispBrk +"&DispLedBal=" + DispLedBal +"&DispBill=" + DispBill + "&TransType=" + TransType +"&ShowScripWiseNet=" + DispScripNet +"&ShowOrderNo=" + DispOrd +"&RepID=" +ReportNo.value+"&LedgerOp="+LedgerOp;
			}	

		}
		
		/*Multidate OS-Position Office Copy*/
		if ( ReportButtonName.value == "cmdMulOSP" || ReportButtonName.value == "cmdMulOSPWoBill" ||ReportButtonName.value == "cmdOSP" || ReportButtonName.value == "cmdCFOSP")
		{
			if ( ReportButtonName.value == "cmdCFOSP" )
			{
				cfPerc = txtCFPerc.value;
				lastTrDt = txtLastTrDt.value;
			}					
			else
			{
				cfPerc = 0;
				lastTrDt = "";
			}
			FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/MultiDateOSPosition.cfm?" + commonParam +"&fileType="+ fileType +"&Client="+ txtBranch.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&FROM_LAST_EXPIRY=" + lastExpiry +"&From_Date=" + From_Date.value +"&To_Date=" + To_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&FromSymbol=&ToSymbol=&LastTrDt=" + lastTrDt + "&FoType=" + foType + "&PrintType=" + printType + "&PaperSize=" + PaperSize +"&inclZero=" + inclZero +"&showSpan=" + spanMg + "&CFPerc=" + cfPerc + "&withBfPrice=" + withBfPrice + "&Output=" + outputType +"&ShowNetAmt=" + NetAmount +"&Branchwise=" + branchwiseFile + "&RepID=" +ReportNo.value;
		}

		if ( ReportButtonName.value == "cmdSttCertificate" )
		{
			cfPerc = 0;
			lastTrDt = "";
			FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/STT_Certificate.cfm?" + commonParam +"&fileType="+ fileType +"&Client="+ txtBranch.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&FROM_LAST_EXPIRY=" + lastExpiry +"&From_Date=" + From_Date.value +"&To_Date=" + To_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&FromSymbol=&ToSymbol=&LastTrDt=" + lastTrDt + "&FoType=" + foType + "&PrintType=" + printType + "&PaperSize=" + PaperSize +"&inclZero=" + inclZero +"&showSpan=" + spanMg + "&CFPerc=" + cfPerc + "&withBfPrice=" + withBfPrice + "&Output=" + outputType +"&ShowNetAmt=" + NetAmount +"&Branchwise=" + branchwiseFile + "&RepID=" +ReportNo.value;
		}

	if ( ReportButtonName.value == "cmdmp1" )
		{
			cfPerc = 0;
			lastTrDt = "";
			FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/MarginReport.cfm?" + commonParam +"&fileType="+ fileType +"&Client="+ txtBranch.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&FROM_LAST_EXPIRY=" + lastExpiry +"&From_Date=" + From_Date.value +"&To_Date=" + To_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&FromSymbol=&ToSymbol=&LastTrDt=" + lastTrDt + "&FoType=" + foType + "&PrintType=" + printType + "&PaperSize=" + PaperSize +"&inclZero=" + inclZero +"&showSpan=" + spanMg + "&CFPerc=" + cfPerc + "&withBfPrice=" + withBfPrice + "&Output=" + outputType +"&ShowNetAmt=" + NetAmount +"&Branchwise=" + branchwiseFile + "&RepID=" +ReportNo.value;
		}
		/*Short Margin*/
		if ( ReportButtonName.value == "cmdShortMargin")
		{
			FileGeneration.location.href = "/Client/Text_Reports/Trading/FO/ClientShortMargin.cfm?" + commonParam +"&FromClient=" +escape( FromClient.value ) +"&From_Date=" + From_Date.value +"&To_Date=" + To_Date.value +"&Client=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&Branchwise=" + branchwiseFile + "&RepID=" +ReportNo.value +"&InclZero=" + inclZero;
		}
		if ( ReportButtonName.value == "cmdShortMargin1")
		{
			FileGeneration.location.href = "/Client/Text_Reports/Trading/FO/ClientInitialMargin.cfm?" + commonParam +"&FromClient=" +escape( FromClient.value ) +"&From_Date=" + From_Date.value +"&To_Date=" + To_Date.value +"&Branch=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&Branchwise=" + branchwiseFile + "&RepID=" +ReportNo.value +"&InclZero=" + inclZero+"&Rpttype="+Rpttype.value+"&ShowSpan="+ShowSpan.value;
		}

		/*Trial Balance*/
		if ( ReportButtonName.value == "cmdTB" )
		{
			FileGeneration.location.href = "/Client/Text_Reports/Accounts/AccountSummary.cfm?" + commonParam +"&Client=&From_Date=" + From_Date.value + "&ReportType=TrialBalance&ReportName=Trial Balance&Group=KindOfAccount&DrCrFilter=" + CmbDrCr.value + "&Operator=" + CmbOperator.value + "&DrCrVal=" + txtFilterValue.value + "&NilBalance=" + NilBal;
		}

		/*Client Summary*/
		if ( ReportButtonName.value == "cmdClSum" )
		{
			FileGeneration.location.href = "/Client/Text_Reports/Accounts/AccountSummary.cfm?" + commonParam +"&Client=&From_Date=" + From_Date.value + "&ReportType=ClientSummary&ReportName=Client Report&Group=CompanyCode&DrCrFilter=" + CmbDrCr.value + "&Operator=" + CmbOperator.value + "&DrCrVal=" + txtFilterValue.value + "&NilBalance=" + NilBal +"&FromClient=" + txtFromClient.value +"&ToClient=" + txtToClient.value + "&Branch_Code=" + txtBranch.value;
		}
		
		/*Opening Balance*/
		if ( ReportButtonName.value == "cmdOpSum" )
		{
			FileGeneration.location.href = "/Client/Text_Reports/Accounts/AccountSummary.cfm?" + commonParam +"&Client=&From_Date=" + From_Date.value + "&ReportType=FAOpening&ReportName=Fa Opening&Group=KindOfAccount&DrCrFilter=" + CmbDrCr.value + "&Operator=" + CmbOperator.value + "&DrCrVal=" + txtFilterValue.value + "&NilBalance=" + NilBal;
		}

		/*Opening Balance*/
		if ( ReportButtonName.value == "cmdGrpSum" )
		{
			var AbsSum;
			if ( chkAbs.checked )
			{
				AbsSum = 'Y';
			}
			else
			{
				AbsSum = 'N';
			}
			
			FileGeneration.location.href = "/Client/Text_Reports/Accounts/AccountSummary.cfm?" + commonParam +"&Client=&From_Date=" + From_Date.value + "&Family_Group=" + txtFamily.value +"&ReportType=GroupSummary&ReportName=Groupwise Summary&Group=FamilyGroupCode&DrCrFilter=" + CmbDrCr.value + "&Operator=" + CmbOperator.value + "&DrCrVal=" + txtFilterValue.value + "&NilBalance=" + NilBal + "&AbsSummary=" + AbsSum;
		}
		
		/*Account Detail*/
		if ( ReportButtonName.value == "cmdAcDet" )
		{
			var AccConfirm;
			AccConfirm  =  optAccConfirm.value;
			ShowMarginBalance1 = MarginBal.value;
			/*if ( optAccConfirm[0].checked )
			{
				AccConfirm = 'Y';
			}
			else
			{
				AccConfirm = 'N';
			}
			if ( MarginBal[0].checked )
			{
				ShowMarginBalance1 = 'Y';
			}
			else
			{
				ShowMarginBalance1 = 'N';
			}*/
			FileGeneration.location.href = "/Client/Text_Reports/Accounts/AccountDetail.cfm?" + commonParam +"&fileType="+ fileType +"&Client="+ txtBranch.value +"&From_Date=" + From_Date.value + "&To_Date=" + To_Date.value + "&ReportType=AcDetail&ReportName=Account Detail&Family_Group_List=" + txtFamily.value + "&Ledger_List=" + FromClient.value + "&ShowNarration=" + narr + "&Transaction_Type_List=" + vType + "&Output=" + outputType + "&FaPrintType=" + faPrintType +"&FaVoucherOrder=" + ord + "&AccConfirmation=" + AccConfirm +"&Form1=Detail&ShowMarginBalance="+ShowMarginBalance1+"&ShowSaudaDetail="+SaudaDetail.value;;
		} 
		// Cash Bank Book
		if( ReportButtonName.value == "cmdCashBankBook" )
		{
			FileGeneration.location.href = "/Client/Text_Reports/Accounts/AccountDetail.cfm?" + commonParam +"&fileType="+ fileType +"&Client="+ txtBranch.value +"&From_Date=" + From_Date.value + "&To_Date=" + To_Date.value + "&ReportType=AcDetail&ReportName=Account Detail&Family_Group_List=" + txtFamily.value + "&Ledger_List=" + FromClient.value + "&ShowNarration=" + narr + "&Transaction_Type_List=" + vType + "&Output=" + outputType + "&FaPrintType=" + faPrintType +"&FaVoucherOrder=" + ord +"&AccConfirmation=N&Form1=CashBank";
		}
		if ( ReportButtonName.value == "cmdVPrint" )
		{
			FileGeneration.location.href = "/Client/Text_Reports/Accounts/VoucherPrint.cfm?" + commonParam + "&Date=" + From_Date.value + "&BankCode=" + cmbBankCode.value + "&VNo=" + cmbVoucherNo.value +  "&ReportName=Voucher Print";
		} 

		/*Journal Report*/
		if ( ReportButtonName.value == "cmdJVReport" )
		{
			FileGeneration.location.href = "/Client/Text_Reports/Accounts/JournalReport.cfm?" + commonParam +"&fileType="+ fileType +"&Client=&From_Date=" + From_Date.value + "&To_Date=" + To_Date.value + "&ReportType=JV&ReportName=Journal Report&Family_Group_List=&Ledger_List=&ShowNarration=" + narr + "&Transaction_Type_List=" + vType + "&FaPrintType=&FaVoucherOrder=";
		}  
		
		/* Payout To Clients */
		if ( ReportButtonName.value == "cmdClientPayOut" )
		{
			if (OutputType == 'P')
			{
				FileGeneration.location.href = "/Client/Text_Reports/Stock/PayoutToCLient.cfm?"  + commonParam +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&Depository=" + Depo +"&ClientType=" + CType +"&PrintDate=" + txtPrintDate.value + "&SerialNo=" + txtSerialNo.value + "&BatchNo=" + batchNo;
			}
			if (OutputType == 'F')
			{
				if ( Depo == "NSDL" && CType == "NSDL")
				{
					FileGeneration.location.href = "/Client/IO_FOCAPS/Transactions/PayOutTextFileNSDLToNSDL_" + NsdlFileName + ".cfm?" + commonParam +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&Depository=" + Depo +"&ClientType=" + CType +"&PrintDate=" + txtPrintDate.value + "&SerialNo=" + txtSerialNo.value  + "&BatchNo=" + batchNo; //+ "&ExecutionDate=" + CmbExecDate.value 
				}
				else if ( Depo == "NSDL" && CType == "CDSL")
				{
					FileGeneration.location.href = "/Client/IO_FOCAPS/Transactions/PayOutTextFileNSDLToCDSL_" + NsdlFileName + ".cfm?" + commonParam +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&Depository=" + Depo +"&ClientType=" + CType +"&PrintDate=" + txtPrintDate.value + "&SerialNo=" + txtSerialNo.value +  "&BatchNo=" + batchNo; //+ "&ExecutionDate=" + CmbExecDate.value
				}
				
				if ( Depo == "CDSL" && CType == "NSDL")
				{
					FileGeneration.location.href = "/Client/IO_FOCAPS/Transactions/PayOutTextFileCDSLToNSDL_" + CdslFileName + ".cfm?"  + commonParam +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&Depository=" + Depo +"&ClientType=" + CType +"&PrintDate=" + txtPrintDate.value + "&SerialNo=" + txtSerialNo.value  + "&BatchNo=" + batchNo; //+ "&ExecutionDate=" + CmbExecDate.value 
				}
				else if ( Depo == "CDSL" && CType == "CDSL")
				{
					FileGeneration.location.href = "/Client/IO_FOCAPS/Transactions/PayOutTextFileCDSLToCDSL_" + CdslFileName + ".cfm?"  + commonParam +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&Depository=" + Depo +"&ClientType=" + CType +"&PrintDate=" + txtPrintDate.value + "&SerialNo=" + txtSerialNo.value +  "&BatchNo=" + batchNo; //+ "&ExecutionDate=" + CmbExecDate.value
				}
				
			}
		}
		
		/* InterSettlement Instructions */
		if ( ReportButtonName.value == "cmdInterSet" )
		{
			if (OutputType == 'P')
			{
				FileGeneration.location.href = "/Client/Text_Reports/Stock/InterSetInstruction.cfm?"  + commonParam +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&PrintDate=" + txtPrintDate.value + "&SerialNo=" + txtSerialNo.value + "&SlipNo=" + "&BatchNo=" + batchNo;
			}
			if (OutputType == 'F') //changed by mihir by 21-04-2006
			{
				var filename	=	"InterSettlementTextFile_";
				var fileObj = new ActiveXObject("Scripting.FileSystemObject");
				var f = ('\\\\' + SrvName.value + '\\' + Drive.value + '\\CFusionMX7\\wwwroot\\Client\\IO_FOCAPS\\Transactions\\InterSettlementTextFile_' + NsdlFileName + '.cfm');
				
				if (fileObj.FileExists(f))
				{
					FileGeneration.location.href = "/Client/IO_FOCAPS/Transactions/" +  filename + NsdlFileName + ".cfm?" + commonParam +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&PrintDate=" + txtPrintDate.value + "&SerialNo=" + txtSerialNo.value + "&SlipNo=" + "&BatchNo=" + batchNo; //+"&ExecutionDate=" + CmbExecDate.value
				}
				else
				{
					FileGeneration.location.href = "/Client/IO_FOCAPS/Transactions/InterSettlementTextFile.cfm?"  + commonParam +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&PrintDate=" + txtPrintDate.value + "&SerialNo=" + txtSerialNo.value + "&SlipNo=" + "&BatchNo=" + batchNo; //+"&ExecutionDate=" + CmbExecDate.value
				}
			}	
		}
		
		/* Export Payout To Clients */
		if ( ReportButtonName.value == "cmdClientPayOutToExport" )
		{	 
			if ( txtSlipNo.value == '' )
			{
			 	alert("Please enter SlipNo !");
			}
			if ( txtBatchNo.value == '' )
			{
			 	alert("Please enter BatchNo !");
			}
			else
			{
				FileGeneration.location.href = "/Client/Text_Reports/Stock/ExportPayoutToCLient.cfm?"  + commonParam +"&Client=&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&Depository=NSDL&ClientType=NSDL&ExecutionDate=" + CmbExecDate.value +"&PrintDate=" + txtPrintDate.value + "&BatchNo=" + txtBatchNo.value + "&SlipNo=" + txtSlipNo.value;
			}	
		}
	
		/*STT Certificate*/
		if ( ReportButtonName.value == "cmdSTTCerticate" )
		{
			FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/STT_Certificate.cfm?" + commonParam +"&Client=&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) + "&ToClient=&BillNo=" +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value  + "&SttRepGen=" + SttRepGen + "&From_Date=" + From_Date.value + "&To_Date=" + To_Date.value;
		}

		/* On Market Instructions */
		if ( ReportButtonName.value == "cmdBenOnMarket" )
		{
			if (OutputType == 'P')
			{
				FileGeneration.location.href = "/Client/Text_Reports/Stock/OnMarketInstruction.cfm?"  + commonParam +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&PrintDate=" + txtPrintDate.value + "&SerialNo=" + txtSerialNo.value + "&Depository=" + Depo + "&BatchNo=" + batchNo + "&PAYIN_FROM_BENPOOL=Ben" + "&Bene=" + CmbBenID.value;
			}
			if (OutputType == 'F')
			{	
				var fileObj = new ActiveXObject("Scripting.FileSystemObject");
				
				if(Depo == "Direct")
				{
					//alert();	
					FileGeneration.location.href = "/Client/IO_FOCAPS/Transactions/DIRECTPAYIN_ONMARKERTFILEGENERATION.cfm?"  + commonParam +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&PrintDate=" + txtPrintDate.value + "&SerialNo=" + txtSerialNo.value + "&Depository=" + Depo + "&BatchNo=" + batchNo + "&Bene=" + CmbBenID.value; 
				}
				else if (BenDepository.value == "NSDL")
				{
					var f = ('\\\\' + SrvName.value + '\\' + Drive.value + '\\CFusionMX7\\wwwroot\\Client\\IO_FOCAPS\\Transactions\\PayInFromBenTextFile_' + NsdlFileName + '.cfm');
					
					if (fileObj.FileExists(f))
					{
						FileGeneration.location.href = "/Client/IO_FOCAPS/Transactions/PayInFromBenTextFile_" + NsdlFileName + ".cfm?"  + commonParam +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&PrintDate=" + txtPrintDate.value + "&SerialNo=" + txtSerialNo.value + "&Depository=" + Depo + "&BatchNo=" + batchNo + "&Bene=" + CmbBenID.value; //+"&ExecutionDate=" + CmbExecDate.value
					}
					else
					{
						FileGeneration.location.href = "/Client/IO_FOCAPS/Transactions/PayInFromBenTextFile_" + NsdlFileName + ".cfm?"  + commonParam +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&PrintDate=" + txtPrintDate.value + "&SerialNo=" + txtSerialNo.value + "&Depository=" + Depo + "&BatchNo=" + batchNo + "&Bene=" + CmbBenID.value; //+"&ExecutionDate=" + CmbExecDate.value
						//*** FileGeneration.location.href = "/Client/IO_FOCAPS/Transactions/PayInFromBenTextFile_NSDL.cfm?"  + commonParam +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&PrintDate=" + txtPrintDate.value + "&SerialNo=" + txtSerialNo.value + "&Depository=" + Depo + "&BatchNo=" + batchNo + "&Bene=" + CmbBenID.value; //+"&ExecutionDate=" + CmbExecDate.value
					}
				}
				else if (BenDepository.value == "CDSL")
				{
					FileGeneration.location.href = "/Client/IO_FOCAPS/Transactions/PayInFromBenTextFile_" + CdslFileName + ".cfm?"  + commonParam +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&PrintDate=" + txtPrintDate.value + "&SerialNo=" + txtSerialNo.value + "&Depository=" + Depo + "&BatchNo=" + batchNo + "&Bene=" + CmbBenID.value; //+"&ExecutionDate=" + CmbExecDate.value
				}
			}
		}

		if ( ReportButtonName.value == "cmdPoolOnMarket" )
		{
			var fileObj = new ActiveXObject("Scripting.FileSystemObject");
			if (OutputType == 'P')
			{
				FileGeneration.location.href = "/Client/Text_Reports/Stock/OnMarketInstruction.cfm?"  + commonParam +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&PrintDate=" + txtPrintDate.value + "&SerialNo=" + txtSerialNo.value + "&Depository=" + Depo + "&BatchNo=" + batchNo + "&RType=" + RT + "&PAYIN_FROM_BENPOOL=Pool";
			}
			
			if (OutputType == 'F')
			{
				if (Depo == "NSDL")
				{
					var filename	=	"PayInTextFile_";
					
					var f = ('\\\\' + SrvName.value + '\\' + Drive.value + '\\CFusionMX7\\wwwroot\\Client\\IO_FOCAPS\\Transactions\\' + filename + NsdlFileName + '.cfm');
	
					if (fileObj.FileExists(f))
					{
						FileGeneration.location.href = "/Client/IO_FOCAPS/Transactions/" + filename + NsdlFileName + ".cfm?"  + commonParam +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&PrintDate=" + txtPrintDate.value + "&SerialNo=" + txtSerialNo.value + "&Depository=" + Depo + "&BatchNo=" + batchNo + "&RType=" + RT; //+"&ExecutionDate=" + CmbExecDate.value
					}
					else
					{
						FileGeneration.location.href = "/Client/IO_FOCAPS/Transactions/" + filename + NsdlFileName + ".cfm?"  + commonParam +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&PrintDate=" + txtPrintDate.value + "&SerialNo=" + txtSerialNo.value + "&Depository=" + Depo + "&BatchNo=" + batchNo + "&RType=" + RT; //+"&ExecutionDate=" + CmbExecDate.value
						//*** FileGeneration.location.href = "/Client/IO_FOCAPS/Transactions/" + filename + "NSDL.cfm?"  + commonParam +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&PrintDate=" + txtPrintDate.value + "&SerialNo=" + txtSerialNo.value + "&Depository=" + Depo + "&BatchNo=" + batchNo + "&RType=" + RT; //+"&ExecutionDate=" + CmbExecDate.value
					}
				}
				else
				{
					FileGeneration.location.href = "/Client/IO_FOCAPS/Transactions/PayInTextFile_CDSL.cfm?"  + commonParam +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&PrintDate=" + txtPrintDate.value + "&SerialNo=" + txtSerialNo.value + "&Depository=" + Depo + "&BatchNo=" + batchNo + "&RType=" + RT; //+"&ExecutionDate=" + CmbExecDate.value
				}
			}
		}
		
		/* Off Market Instructions And	InterDP File Instructions*/
		if ( 	ReportButtonName.value == "cmdBenOffMarket" || ReportButtonName.value == "cmdBenInterDP"  )
		{
			if (OutputType == 'P')
			{
				FileGeneration.location.href = "/Client/Text_Reports/Stock/OffInInstruction.cfm?"  + commonParam +"&From_Date=" + From_Date.value + "&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&ExecutionDate=" + CmbExecDate.value +"&BatchNo=" + batchNo +"&Beneficiary=" + CmbBenID.value + "&PrintDate=" + txtPrintDate.value + "&SerialNo=" + txtSerialNo.value;
			}
			else
			{	
				if ( ReportButtonName.value == "cmdBenOffMarket" )
				{	//alert(BenDepository.value + " " + CdslFileName);
					var fileObj = new ActiveXObject("Scripting.FileSystemObject");
					
					if (BenDepository.value == "NSDL")
					{
						var f = ('\\\\' + SrvName.value + '\\' + Drive.value + '\\CFusionMX7\\wwwroot\\Client\\IO_FOCAPS\\Transactions\\BenOffMarketFileGeneration_' + NsdlFileName + '.cfm');
						
						if (fileObj.FileExists(f))
						{
							FileGeneration.location.href = "/Client/IO_FOCAPS/Transactions/BenOffMarketFileGeneration_" + NsdlFileName + ".cfm?" + commonParam +"&From_Date=" + From_Date.value + "&MktType=" +Mkt_Type.value +"&SetlNo=" +Settlement_No.value +"&ExecutionDate=" + CmbExecDate.value +"&BatchNo=" + batchNo +"&Beneficiary=" + CmbBenID.value + "&FILE_TYPE=BrkBenToClient" +  "&SerialNo=" + txtSerialNo.value;
						}
						else
						{
							FileGeneration.location.href = "/Client/IO_FOCAPS/Transactions/BenOffMarketFileGeneration_" + NsdlFileName + ".cfm?" + commonParam +"&From_Date=" + From_Date.value + "&MktType=" +Mkt_Type.value +"&SetlNo=" +Settlement_No.value +"&ExecutionDate=" + CmbExecDate.value +"&BatchNo=" + batchNo +"&Beneficiary=" + CmbBenID.value + "&FILE_TYPE=BrkBenToClient" +  "&SerialNo=" + txtSerialNo.value;							
							//*** FileGeneration.location.href = "/Client/IO_FOCAPS/Transactions/BenOffMarketFileGeneration_NSDL.cfm?" + commonParam +"&From_Date=" + From_Date.value + "&MktType=" +Mkt_Type.value +"&SetlNo=" +Settlement_No.value +"&ExecutionDate=" + CmbExecDate.value +"&BatchNo=" + batchNo +"&Beneficiary=" + CmbBenID.value + "&FILE_TYPE=BrkBenToClient" +  "&SerialNo=" + txtSerialNo.value;
						}
					}
					else
					{
						FileGeneration.location.href = "/Client/IO_FOCAPS/Transactions/BenOffMarketFileGeneration_" + CdslFileName + ".cfm?" + commonParam +"&From_Date=" + From_Date.value + "&MktType=" +Mkt_Type.value +"&SetlNo=" +Settlement_No.value +"&ExecutionDate=" + CmbExecDate.value +"&BatchNo=" + batchNo +"&Beneficiary=" + CmbBenID.value + "&FILE_TYPE=BrkBenToClient" +  "&SerialNo=" + txtSerialNo.value;
					}
				}
				else if ( ReportButtonName.value == "cmdBenInterDP" )
				{
					var fileObj = new ActiveXObject("Scripting.FileSystemObject");
					
					if (BenDepository.value == "NSDL")
					{
						var f = ('\\\\' + SrvName.value + '\\' + Drive.value + '\\CFusionMX7\\wwwroot\\Client\\IO_FOCAPS\\Transactions\\BenInterDpFileGeneration_' + NsdlFileName + '.cfm');
						
						if (fileObj.FileExists(f))
						{
							FileGeneration.location.href = "/Client/IO_FOCAPS/Transactions/BenInterDpFileGeneration_" + NsdlFileName + ".cfm?" + commonParam +"&From_Date=" + From_Date.value + "&MktType=" +Mkt_Type.value +"&SetlNo=" +Settlement_No.value +"&ExecutionDate=" + CmbExecDate.value + "&BatchNo=" + batchNo +"&Beneficiary=" + CmbBenID.value + "&FILE_TYPE=BrkBenToClient" +  "&SerialNo=" + txtSerialNo.value;
						}
						else
						{
							FileGeneration.location.href = "/Client/IO_FOCAPS/Transactions/BenInterDpFileGeneration_" + NsdlFileName + ".cfm?" + commonParam +"&From_Date=" + From_Date.value + "&MktType=" +Mkt_Type.value +"&SetlNo=" +Settlement_No.value +"&ExecutionDate=" + CmbExecDate.value + "&BatchNo=" + batchNo +"&Beneficiary=" + CmbBenID.value + "&FILE_TYPE=BrkBenToClient" +  "&SerialNo=" + txtSerialNo.value;
							//**** FileGeneration.location.href = "/Client/IO_FOCAPS/Transactions/BenInterDpFileGeneration_NSDL.cfm?" + commonParam +"&From_Date=" + From_Date.value + "&MktType=" +Mkt_Type.value +"&SetlNo=" +Settlement_No.value +"&ExecutionDate=" + CmbExecDate.value + "&BatchNo=" + batchNo +"&Beneficiary=" + CmbBenID.value + "&FILE_TYPE=BrkBenToClient" +  "&SerialNo=" + txtSerialNo.value;
						}
					}
					else
					{
						FileGeneration.location.href = "/Client/IO_FOCAPS/Transactions/BenInterDpFileGeneration_" + CdslFileName + ".cfm?" + commonParam +"&From_Date=" + From_Date.value + "&MktType=" +Mkt_Type.value +"&SetlNo=" +Settlement_No.value +"&ExecutionDate=" + CmbExecDate.value + "&BatchNo=" + batchNo +"&Beneficiary=" + CmbBenID.value + "&FILE_TYPE=BrkBenToClient" +  "&SerialNo=" + txtSerialNo.value;
					}
				}	
			}	
		}
		
		if ( ReportButtonName.value == "cmdBenSummary" )
		{
			FileGeneration.location.href = "/Client/Text_Reports/Stock/BenSummary_Data.cfm?"  + commonParam + "&FrmDate=" + From_Date.value + "&ToDate=" + To_Date.value + "&FromClient=" +escape( FromClient.value ) +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value + "&InShort=" + InShort + "&OutShort=" + OutShort  + "&VBen=" + VBen + "&VBroker=" + VBroker + "&Beneficiary=" + CmbBenID.value; //+ "&VType=" + VType;
		}
		
		if ( ReportButtonName.value == "cmdBenDetail" )
		{
			FileGeneration.location.href = "/Client/Text_Reports/Stock/BenDetail_Data.cfm?"  + commonParam +"&FromClient=" +escape( FromClient.value ) +"&FamilyGroup=" + txtFamily.value +"&BranchID=" +txtBranch.value + "&FrmDate=" + txtFrmDate.value + "&ToDate=" + txtToDate.value + "&Beneficiary=" + CmbBenID.value;
		}
		if ( ReportButtonName.value == "cmdCdsltoNsdlIntSetl" )
		{
			FileGeneration.location.href = "/Client/Text_Reports/Stock/CDSLToNSDLIntSetl.cfm?"  + commonParam + "&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value + "&SerialNo=" + txtSerialNo.value + "&PrintDate=" + txtPrintDate.value + "&ToSettlementNo="+  CmbToSetlNo.value + "&BatchNo=" + batchNo; /* +"&ExecutionDate=" + CmbExecDate.value  + "&PrintDate=" + txtPrintDate.value + "&SerialNo=" + txtSerialNo.value;*/
		}
		if ( ReportButtonName.value == "cmdCdsltoNsdlTrans" )
		{
			FileGeneration.location.href = "/Client/Text_Reports/Stock/CDSLToNSDLTransfer.cfm?"  + commonParam + "&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value + "&SerialNo=" + txtSerialNo.value + "&PrintDate=" + txtPrintDate.value + "&BatchNo=" + batchNo;
		}
	}	
}

/*

if ( chkInShort.checked )
		{
			InShort		=	'Y';
		}
		
		if ( chkOutShort.checked )
		{
			OutShort	=	'Y';
		}
		
		if ( chkBen.checked )
		{
			VBen	=	'Y';
		}
		
		if ( chkBroker.checked )
		{
			VBroker	=	'Y';
		}
*/
/*if ( Exchange.value == "NSE")
{
	FileGeneration.location.href = "/Client/IO_FOCAPS/Transactions/OffMarketFileGeneration.cfm?"  + commonParam +"&From_Date=" + From_Date.value + "&MktType=" +Mkt_Type.value +"&SetlNo=" +Settlement_No.value +"&ExecutionDate=" + CmbExecDate.value +"&BatchNo=" + batchNo +"&Beneficiary=" + CmbBenID.value + "&FILE_TYPE=BrkBenToClient";
}
else if( Exchange.value == "BSE")
{
	FileGeneration.location.href = "/Client/IO_FOCAPS/Transactions/BENTONSDLTEXT.cfm?" + commonParam +"&From_Date=" + From_Date.value + "&MktType=" +Mkt_Type.value +"&SetlNo=" +Settlement_No.value +"&ExecutionDate=" + CmbExecDate.value + "&SerialNo=" + txtSerialNo.value + "&BatchNo=" + batchNo +"&Beneficiary=" + CmbBenID.value + "&FILE_TYPE=BrkBenToClient";	
}*/		
