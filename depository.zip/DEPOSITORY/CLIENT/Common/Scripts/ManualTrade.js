
HelpWindow = new Object();

/* ********************************************
	FUNCTION FOR CLOSING HELP POPUP WINDOW.
******************************************** */
function CloseWindow ( )
{
	try
	{
		if ( ( typeof( HelpWindow ) == "object" ) && ( !HelpWindow.closed ) )
		{
			HelpWindow.close();
			throw "e";
		}
	}
	catch ( e )
	{
		return ( e );
	}
}

 
/* ********************************************
	FUNCTION FOR OPENING HELP POPUP WINDOW.
******************************************** */
function OpenWindowForScrip( form, par, Type, InputType )
{
	with( form )
	{
		HelpWindow	=	open( "/Client/HelpSearch/TradingClients.cfm?COCD=" +cocd.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Market=" +market.value +"&Exchange=" +exchange.value +"&Broker=" +broker.value +"&ClientList=&Type=" +Type +"&InputType=" + InputType +"&ScrObj=Scrip&helpfor=" +par +"&title=Scrip Help", "HelpWindow", "width=700, height=525, scrollbar=no, top=0, left=0, menubar=no, titlebar=no, toolbar=no, status=no, resizeable=no" );
	}
}

function OpenWindowForScrip_OfflineEntry( form, par, Type, InputType )
{
	with( form )
	{
		HelpWindow	=	open( "/Client/HelpSearch/TradingClients.cfm?COCD=" +cocd.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Market=" +market.value +"&Exchange=" +exchange.value +"&Broker=" +broker.value +"&ClientList=&Type=" +Type +"&InputType=" + InputType +"&ScrObj=txtScripSymbol&helpfor=" +par +"&title=Scrip Help", "HelpWindow", "width=700, height=525, scrollbar=no, top=0, left=0, menubar=no, titlebar=no, toolbar=no, status=no, resizeable=no" );
	}
}

/* ********************************************
	FUNCTION FOR OPENING HELP POPUP WINDOW.
******************************************** */
function OpenSingleWindow( form, par )
{
	with( form )
	{
		try
		{
			HelpWindow	=	open( "/Client/HelpSearch/SingleChoice.cfm?COCD="+ cocd.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&FormObj=" +name +"&ClObj=Client&Title=Clients Help&helpfor=Client", "HelpWindow", "width=700, height=525, scrollbar=no, top=0, left=0, menubar=no, titlebar=no, toolbar=no, status=no, resizeable=no" );
		}
		catch( e )
		{ 
			HelpWindow	=	open( "/Client/HelpSearch/SingleChoice.cfm?COCD="+ cocd.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&FormObj=" +name +"&ClObj=Client&helpfor=Client", "HelpWindow", "width=700, height=525, scrollbar=no, top=0, left=0, menubar=no, titlebar=no, toolbar=no, status=no, resizeable=no" );
		}
	}
}

function chkForBlank( form )
{
	with ( form )
	{
		if ( Client.value.length == 0 || Client.value.charAt(0) == " ")
		{
			alert ("Please enter valid 'Client ID' !");
			Client.focus();
			return false;
		}
		if ( Scrip.value.length == 0 || Scrip.value.charAt(0) == " ")
		{
			alert ("Please enter valid 'Scrip Code' !");
			Scrip.focus();
			return false;
		}
	}
}
