function showHideRptType( hideShowFor )
{
	setlNoHTML	=	thSetlNo.innerHTML;
	
	with( ReportForm )
	{
		if( hideShowFor == "Dt" )
		{
			thMktType.innerHTML				=	"&nbsp;";
			Mkt_Type.style.display			=	"None";
			thSetlNo.innerHTML				=	"&nbsp;";
			Settlement_No.style.display		=	"None";
			
			thFromDate.innerHTML			=	"From Date :&nbsp;";
			FromDate.style.display			=	"";
			thToDate.innerHTML				=	"To Date :&nbsp;";
			ToDate.style.display			=	"";
		}
		else
		{
			thMktType.innerHTML				=	"Market Type :&nbsp;";
			Mkt_Type.style.display			=	"";
			thSetlNo.innerHTML				=	"Settlement :&nbsp;";
			Settlement_No.style.display		=	"";
			
			//<label style=Cursor : Help; onClick=OpenWindow( this.form, 'Settlement' );> Settlement :&nbsp; </label>
			
			thFromDate.innerHTML			=	"&nbsp;";
			FromDate.style.display			=	"None";
			thToDate.innerHTML				=	"&nbsp;";
			ToDate.style.display			=	"None";
		}
	}
}


function setReportType()
{
	with( ReportForm )
	{
		if( CO.checked )
		{
			D.checked				=	false;
			D.disabled				=	true;
			S.checked				=	true;
			FromClient.value		=	"";
			CmbFormat.disabled		=	false;
			FromClient.disabled		=	true;
		}
		else
		{
			D.disabled				=	false;
			CmbFormat.disabled		=	true;
			FromClient.disabled		=	false;
		}
	}
}

function setPeriod()
{
	with( ReportForm )
	{
		if( PeriodSelection[0].checked )
		{
			thFromDate.innerText="";
			FromDate.style.display="none";
			CmbPeriod.style.display="";
			Row6.style.display="none";
			HiddenRow6.style.display="";
		}
		else
		{
			thFromDate.innerHTML="From Date :&nbsp;";
			FromDate.style.display="";
			CmbPeriod.style.display="none";
			Row6.style.display="";
			HiddenRow6.style.display="none";
		}
	}
}