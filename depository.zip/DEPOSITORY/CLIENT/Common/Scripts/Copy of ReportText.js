function openReport( form, segment, btnName, btnValue, rptType )
{
	with ( form )
	{	
		var commonParam;
		ReportNo.value = rptType;
		ReportButtonName.value = btnName;
		ReportName.value = btnValue;
		ReportSegment.value = segment;
		
		commonParam = "COCD=" +COCD.value +"&CoName=" +CoName.value +"&CoGroup=" +CoGroup.value +"&StYr=" +FinStart.value +"&EndYr=" +FinEnd.value +"&CDSLPoolAccCode=&CDSLDPID=&CDSLDPName=&NSDLPoolAccCode=&NSDLDPID=&NSDLDPName=";
		//commonParam = "COCD=" +COCD.value +"&CoName=" +CoName.value +"&CoGroup=" +CoGroup.value +"&StYr=" +FinStart.value +"&EndYr=" +FinEnd.value;
		
		if ( btnName == "cmdSTTCerticate" )
		{
			ShowRepGen.value = "True";
		}
		
		if ( Market.value == "CAPS" )
		{
			if ( btnName == "cmdSTTCerticate" || btnName == "cmdBenOffMarket" || btnName == "cmdBenInterDP")
			{
				ShowSetlNo.value = "False";
			}
		}

		if ( btnName == "cmdBenSummary" )
		{
			//ShowViewType.value 		= "True";
			ShowInOutShort.value 	= "True";
			ShowWBrokBen.value		= "True";
		}
		
		if ( btnName == "cmdBenDetail" )
		{
			ShowFrmToDate.value	=	"True";
		}
		
		if	( btnName == "cmdPreCont" || btnName == "cmdSaudaSum" || btnName == "cmdSaudaSumCIDDateWise" || btnName == "cmdSaudaSumCID2DateWise" || btnName == "cmdMulOSP" ||
			  btnName == "cmdMulOSPWoBill" || btnName == "cmdOSP" || btnName == "cmdCFOSP" || btnName == "cmdAcDet")
		{
			ShowReportType.value	=	"True";
		}
		
		if	( btnName == "cmdPreCont" )
		{
			ShowStationaryType.value = "True";
			ShowOrderByInContract.value = "True";
			ShowECNPrintInContract.value = "True";
		}
	 
		if	( btnName == "cmdMulOSP" || btnName == "cmdMulOSPWoBill" )
		{
			ShowLastExpiry.value	=	"True";
			ShowFoType.value		=	"True";
			ShowOpenPrice.value		=	"True";
			ShowNetAmount.value		=	"True";
		}
		
		if	( 	  btnName == "cmdSaudaSum" || btnName == "cmdSaudaSumCIDDateWise" || btnName == "cmdSaudaSumCID2DateWise" || btnName == "cmdSaudaDet" || btnName == "cmdMulOSP" ||
				  btnName == "cmdMulOSPWoBill" || btnName == "cmdOSP"  || btnName == "cmdCFOSP"
			)
		{
			ShowPrintType.value	=	"True";
			if ( btnName != "cmdSaudaDet" )
			{
				ShowPaperSize.value	=	"True";
			}
		}
		
		if ( btnName == "cmdCFOSP" )
		{
			ShowLastTrDt.value = "True";
		}
		
		if	( 	( btnName == "cmdSaudaSum" || btnName == "cmdSaudaSumCIDDateWise" || btnName == "cmdSaudaSumCID2DateWise" || btnName == "cmdSaudaDet" || btnName == "cmdMulPreBill" || btnName == "cmdMulOSP" ||
				  btnName == "cmdMulOSPWoBill")
				 && Market.value == "FO"
			)
		{
			MultidateReport.value	=	"True";
		}
		
		if ( btnName == "cmdSaudaSumCIDDateWise" )
		{
		 	if (Market.value == "CAPS")
			{
				MultidateReport.value	=	"True";
				ShowSetlNo.value		=	"False";
				
				/*if (Exchange.value == "BSE")
				{
				 	ShowVarMargin.value = "True";
				}*/
			}
		}
		
		/*if ( btnName == "cmdSaudaSum" )
		{
			if (Market.value == "CAPS")
			{
			 	ShowClientID2.value = "True";
			}
		}*/

		if  ( btnName == "cmdAcDet" || btnName == "cmdClDet" || btnName == "cmdJVReport" || btnName == "cmdSTTCerticate")
		{
				MultidateReport.value	=	"True";
		}
		
		if  ( btnName == "cmdOSP" || btnName == "cmdCFOSP" )
		{
			if  ( btnName == "cmdOSP" )
			{
				ShowSpanMargin.value	=	"True";
			}
			ShowIncludeZero.value	=	"True";			
		}
		
		if	( 	btnName == "cmdSaudaSum" && btnName == "cmdSaudaSumCIDDateWise" && btnName == "cmdSaudaSumCID2DateWise" &&	btnName == "cmdMulOSP"  && btnName == "cmdMulOSPWoBill")
		{
			ShowLedgerBal.value 		=	"True";
		}
		
		if ( btnName == "cmdClientPayOutToExport" )
		{
			ShowBatchNo.value 			=	"True";
			ShowSlipNo.value 			=	"True";
		}
		
		if ( btnName == "cmdCFOSP" )
		{
			ShowBFPercentage.value		=	"True";
		}
		
		if	( btnName == "cmdSaudaSum" || btnName == "cmdSaudaSumCIDDateWise" || btnName == "cmdSaudaSumCID2DateWise")
		{
			ShowBrokerage.value 	=	"True";
			ShowFontType.value		=	"True";
			ShowClPrice.value		=	"True";
			
			if ( btnName == "cmdSaudaSumCIDDateWise" )
			{
				ShowOpening.value		=	"True";
			}
			
			if ( Market.value == "FO" )
			{
				ShowTransactionType.value	=	"True";
				ShowBillAmount.value 		=	"True";
			}
		}

		if ( btnName == "cmdSaudaDet" )
		{
			ShowScripNet.value			=	"True";
			ShowSortOrder.value			=	"True";
			ShowOrderTradeNo.value		=	"True";
			ShowBrokerage.value			=	"True";
			if ( Market.value == "FO" )
			{
				ShowTransactionType.value	=	"True";
				ShowBillAmount.value 		=	"True";
			}
		}
		
		if ( btnName == "cmdSaudaSumCID2DateWise" )
		{
		 	if (Market.value == "CAPS")
			{
				MultidateReport.value	=	"True";
				ShowBranch.value		=	"False";
				ShowFamily.value		=	"False";
				ShowReportType.value 	= 	"False";
				ShowBrokerage.value		=	"False";
				ShowBranchwise.value	=	"False";
			 	ShowClientID2.value 	= 	"True";
				ShowScripFilter.value	=	"True";
				ShowSetlNo.value		=	"False";
				ShowClients.value		=	"False";				
				ShowAbsolute.value		=	"True";
				ShowOpening.value		=	"True";
			}
		}
		
		if	( btnName == "cmdBillAbs" )
		{
			if ( Market.value == "FO" )
			{
				ShowBrokerage.value 	=	"False";
				ShowFontType.value		=	"False";
			}
			else
			{
				ShowBrokerage.value 	=	"True";
				ShowFontType.value		=	"True";
			}	
		}		
		
		if	( btnName == "cmdPreBill"	|| btnName == "cmdPlainBill")
		{
			if ( Market.value == "CAPS" )
			{
				ShowPrePrintedBillFormat.value = "True";
				ShowOrderByInContract.value = "True";
			}
			if ( Market.value == "FO" )
			{
				ShowNetMargin.value		=	"True";
				ShowNetFutMToM.value 	=	"True";
				ShowNetOption.value 	=	"True";
				ShowPostingMarginAc.value = 	"True";
			}
				ShowStationaryType.value = "True";
				ShowFamily.value 	=	"True";
		}
		
		if	(  btnName == "cmdTB" || btnName == "cmdClientPayOut" || btnName == "cmdInterSet" || btnName == "cmdClientPayOutToExport"
			|| btnName == "cmdClSum" || btnName == "cmdOpSum" || btnName == "cmdGrpSum" || btnName == "cmdJVReport"
			|| btnName == "cmdBenOnMarket" || btnName == "cmdBenInterDP" || btnName == "cmdBenOffMarket"
			//|| btnName == "cmdPoolOnMarket" || btnName == "cmdPoolInterDP" || btnName == "cmdPoolOffMarket"
			)
			
		{
			ShowClientFilter.value 	=	"True";
			if	( btnName != "cmdClSum" )
			{
				ShowBranch.value 		=	"False";
				ShowClientFilter.value 	=	"False";
			}
			
				ShowClients.value 		=	"False";
							
			if ( btnName != "cmdGrpSum" && btnName != "cmdAcDet" && btnName != "cmdClDet")
			{
				ShowFamily.value 	=	"False";
			}
			if	( btnName == "cmdTB" || btnName == "cmdClSum" || btnName == "cmdOpSum" || btnName == "cmdGrpSum")
			{ 
				ShowNilBalance.value=	"True";
				ShowDrCrFilter.value=	"True";
			}
			
			if ( btnName == "cmdGrpSum" )
			{
				ShowAbsGrpWiseSum.value = "True";
			}
		}

		if ( btnName == "cmdAcDet" || btnName == "cmdClDet" || btnName == "cmdJVReport")
		{
			ShowNarration.value			=	"True";
			ShowFaTransType.value		=	"True";
			if ( btnName != "cmdJVReport" )
			{
				ShowFaVoucherOrder.value	=	"True";
				ShowFaPrintType.value		=	"True";
			}	
		}
		
		if ( btnName == "cmdAcDet" )
		{
			ShowAccConfirmation.value = "True";
			ShowFamily.value = "False";
		}
		
		if ( btnName == "cmdVPrint")
		{
			ShowBranch.value 		=	"False";
			ShowFamily.value		=	"False";
 			ShowClients.value 		=	"False";
			ShowAccountCode.value	=	"True";
			ShowVoucherNo.value		=	"True";
		}
		
		if	( 	btnName == "cmdClientPayOut" || btnName == "cmdInterSet" || btnName == "cmdClientPayOutToExport" || 
				btnName == "cmdBenOnMarket" || btnName == "cmdBenOffMarket" || btnName == "cmdBenInterDP" //||
				//btnName == "cmdPoolOnMarket" || btnName == "cmdPoolOffMarket" || btnName == "cmdPoolInterDP"
			)
		{
			ShowPrintDate.value 		=	"True";
			ShowExecDate.value 			=	"True";
			
			if	( btnName != "cmdClientPayOutToExport" )
			{
				ShowSerialNo.value 		=	"True";
			}
			
			if	( btnName == "cmdClientPayOut" )
			{
				ShowDepository.value	 =	"True";
				ShowClientType.value	 =	"True";
				ShowIOSlipNo.value		 =	"True";
				ShowFileGenOutType.value =  "True";
				ShowExecDate.value 		 =	"False";
			}
		
			if ( btnName == "cmdBenOffMarket" || btnName == "cmdBenInterDP" )
			{
				ShowFileGenOutType.value =	"True";
			}
			
			if ( btnName == "cmdBenOnMarket" || btnName == "cmdPoolOnMarket" )
			{
				ShowDepository.value	=	"True";
				if ( Market.value == "CAPS" )
				{
					ShowExecDate.value 		 =	"False";
					ShowFileGenOutType.value =	"True";
					ShowIOSlipNo.value		 =	"True";
					ShowReversibleType.value =	"True";
				}	
			}

			if	( btnName == "cmdBenOffMarket" || btnName == "cmdBenInterDP")
			{
				ShowPrintBatchNo.value	=	"True";
				ShowBeneficiary.value	=	"True";
			}
			
			if ( btnName == "cmdInterSet" )
			{
			 	ShowExecDate.value 		 =	"False";
				ShowFileGenOutType.value =	"True";
				ShowIOSlipNo.value		 =	"False";
			}
		}

		if	( btnName == "cmdBillAbs" )
		{
			ShowBrokerage.value 	=	"True";
			ShowFontType.value		=	"True";
			ShowBilledOrNot.value	=	"True";
			//ShowFamily.value		=	"True";
		}		
		
		if	(
				btnName != "cmdFileUpload" || btnName != "cmdClientOverView" || btnName != "cmdRecVoucher"
			)
		{
			submit();
		}
		
		if	( btnName 	== "cmdFileUpload" )
		{
			uploadPath	=	"/Client/TradeUploads/";
			transParam	=	"COCD=" +COCD.value +"&CoName=" +CoName.value +"&CoGroup=" +CoGroup.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Client=&CDSLPoolAccCode=" +CDSLPoolAccCode.value +"&CDSLDPID=" +CDSLDPID.value +"&CDSLDPName=" +CDSLDPName.value +"&NSDLPoolAccCode=" +NSDLPoolAccCode.value +"&NSDLDPID=" +NSDLDPID.value +"&NSDLDPName=" +NSDLDPName.value;
			parent.parent.Display.location.href	=	uploadPath +"Upload.cfm?TemplateName=Trading_UploadsForm&" +transParam;		
		}
		
		if	( btnName 	== "cmdRecVoucher" )
		{
			mainPath	=	"/Client/FA_FOCAPS/Forms/"
			param		=	"COCD=" +COCD.value +"&CoName=" +CoName.value +"&CoGroup=" +CoGroup.value +"&StYr=" +FinStart.value +"&EndYr=" +FinEnd.value +"&CDSLPoolAccCode=" +CDSLPoolAccCode.value +"&CDSLDPID=" +CDSLDPID.value +"&CDSLDPName=" +CDSLDPName.value +"&NSDLPoolAccCode=" +NSDLPoolAccCode.value +"&NSDLDPID=" +NSDLDPID.value +"&NSDLDPName=" +NSDLDPName.value;
			parent.parent.Display.location.href	=	mainPath +"ReceiptPayment.cfm?TemplateName=Accounts_Receipt&Bank=Yes&TransactionType=Receipt&Tr_Type=R&" +param;
		}
	}	
}

/*function setVarStatus( form )
{
	with (form)
	{
	 	if (withVarMrg.disabled)
		{	alert("K");
			withVarMrg.disabled == "False";
		}
	}
} */

function setMktSetlValue( form, mkt_Type, setl_No, trdt )	
{
	with ( form )
	{
		if ( mkt_Type	!=	"" )
		{
			Mkt_Type.value		=	mkt_Type;
			Settlement_No.value	=	setl_No;
			From_Date.value		=	trdt;
			btnVal				=	ReportButtonName.value;
		}
		if ( btnVal == "cmdClientPayOut" || btnVal == "cmdOnMarket" )
		{
			parent.parent.fraPaneBar.location.href = "/Client/DynamicFrame/Fra_Hide.cfm?FormObject=parent.Display.SubRPTMenu.document.SubReportParameters&FormName=ReportText&COCD=" + COCD.value + "&Market=" + Market.value +"&Exchange=" + Exchange.value +"&Mkt_Type=" + mkt_Type + "&Settlement_No=" + setl_No + "&Trade_Date=" + trdt + "&ReportName=" + btnVal;
		}	
	}
}

function showHideBatch( form, ben_id, trdt )
{
	with (form)
	{
		parent.parent.fraPaneBar.location.href = "/Client/DynamicFrame/Fra_Hide.cfm?FormObject=parent.Display.SubRPTMenu.document.SubReportParameters&FormName=ReportText&COCD=" + COCD.value + "&Market=" + Market.value +"&Exchange=" + Exchange.value +"&Mkt_Type=&Settlement_No=&Trade_Date=" + trdt + "&BeneficiaryID=" + ben_id;
	}
}

function showHideSlip( form, mkt_type, setl_No, btnVal )
{
	with (form)
	{
		if ( btnVal == "cmdBenOnMarket" || btnVal == "cmdClientPayOut" || btnVal == "cmdInterSet" )
		{
			parent.parent.fraPaneBar.location.href = "/Client/DynamicFrame/Fra_Hide.cfm?FormObject=parent.Display.SubRPTMenu.document.SubReportParameters&FormName=ReportText&COCD=" + COCD.value + "&Market=" + Market.value +"&Exchange=" + Exchange.value +"&Mkt_Type=" + mkt_type + "&Settlement_No=" + setl_No + "&ReportName=" + btnVal +"&ReturnValue=SlipNo";
		}	
	}
}

function showHideVoucherNo( form, bankCode )
{
	with (form)
	{
		parent.parent.fraPaneBar.location.href = "/Client/DynamicFrame/Fra_Hide.cfm?FormObject=parent.Display.SubRPTMenu.document.SubReportParameters&FormName=ReportText&COCD=" + COCD.value + "&Market=" + Market.value +"&Exchange=" + Exchange.value +"&StYr=" +FinStart.value +"&EndYr=" +FinEnd.value + "&VDate=" + From_Date.value + "&BankCode=" + bankCode + "&ReturnValue=BankVoucherNo";
	}
}

function getLastExpiryDate( form, trdt )	
{
	with ( form )
	{
		if ( LastExpiry.checked )
		{
			parent.parent.fraPaneBar.location.href = "/Client/DynamicFrame/Fra_Hide.cfm?GetBranch=Yes&FormObject=parent.parent.Display.ReportParam&FormName=ReportText&GetLastExpiry=Yes&COCD=" + COCD.value + "&Market=" + Market.value +"&Exchange=" + Exchange.value +"&Trade_Date=" + trdt;
		}	
	}
}

function generateReport()
{
	with ( SubReportParameters )
	{
		var commonParam, lastExpiry, printType, DispBrk, DispLedBal, TransType, fontCondense, InShort, OutShort, VBen, VBroker, VType, SttRepGen;

		//commonParam 	= "COCD=" +COCD.value +"&CoName=" +CoName.value +"&CoGroup=" +CoGroup.value +"&Market=" + Market.value +"&Exchange=" + Exchange.value + "&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&CDSLPoolAccCode=" +CDSLPoolAccCode.value +"&CDSLDPID=" +CDSLDPID.value +"&CDSLDPName=" +CDSLDPName.value +"&NSDLPoolAccCode=" +NSDLPoolAccCode.value +"&NSDLDPID=" +NSDLDPID.value +"&NSDLDPName=" +NSDLDPName.value + "&ReportButtonName=" + ReportButtonName.value +"&PortName=" + PortName.value;
		commonParam 	= "COCD=" +COCD.value +"&CoName=" +CoName.value +"&CoGroup=" +CoGroup.value +"&Market=" + Market.value +"&Exchange=" + Exchange.value + "&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&ReportButtonName=" + ReportButtonName.value +"&PortName=prn";
		lastExpiry		=	"No";
		printType		=	"C";
		DispBrk			=	"N";
		DispBill		=	"N";
		DispLedBal		=	"N";
		TransType		=	"";
		fontCondense	=	"N";
		PaperSize		=	"Full";
		NilBal			=	"0";
		Depo			=	"NSDL";
		CType			=	"NSDL";
		netMar			=	"N";
		netFut			=	"N";
		netOpt			=	"N";
		narr			=	"True";
		ord				=	"S";
		vType 			=	"'R','P','J','SJ'";
		faPrintType 	= 	"C";
		DispOrd			=	"Y";
		DispScripNet	=	"Y";
		foType			=	"FO";
		inclZero		=	"N";
		spanMg			=	"N";
		fileType		=	"T";
		branchwiseFile	= 	"N";
		withBfPrice		=	"False";
		outputType		=	"Print";
		NetAmount 		= 	"True";
		batchNo			=	0;
		InShort			=	'N';
		OutShort		=	'N';
		VBen			=	'N';
		VBroker			=	'N';
				
		
		if ( ShowStationaryType.value == "True" )
		{
			if ( optStationary[0].checked )
			{
				stationary = 'L';
			}
			
			if ( optStationary[1].checked )
			{
				stationary = 'S';
			}
		}
		
		if ( ShowReversibleType.value == "True" )
		{
			if ( RevType[0].checked )
			{
				RT = '00';
			}
			else if ( RevType[1].checked )
			{
				RT = '01';
			}
		}
		
		if ( ShowAbsolute.value == "True" )
		{
			if ( optAbsolute.checked )
			{
				Absolute = 'Y';
			}
			else
			{
				Absolute = 'N';
			}
		}
		
		if ( ShowOpening.value == "True" )
		{
			if ( optOpening.checked )
			{
				Opening = 'Y';
			}
			else
			{
				Opening = 'N';
			}
		}
					
		if ( ShowFileGenOutType.value == "True" )
		{
			if (OutType[0].checked)
			{
				OutputType = 'P';
			}
			else if (OutType[1].checked)
			{
				OutputType = 'F';
			}
		}
		
		if ( ShowRepGen.value == "True" )
		{
			if (optSttRep[0].checked)
			{
				SttRepGen = 'I';
			}
			else
			{
				SttRepGen = 'S';
			}
		}

		if ( ShowClPrice.value == "True" )
		{		
			if ( withPur.checked )
			{
				WithPurchase = 'Y';
			}
			else
			{
				WithPurchase = 'N';
			}
		
			if ( withSale.checked )
			{
				WithSale = 'Y';
			}
			else
			{
				WithSale = 'N';
			}
		}
				
		//if (!( withPur.checked ) & !( withSale.checked ))
		//{
		//	WithPurchase = 'Y';
		//	WithSale = 'Y';
		//}
		
		if ( ShowInOutShort.value == "True" | ShowWBrokBen.value == "True" )
		{
			if (chkInShort.checked)
			{
				InShort = 'Y';
			}
			
			if (chkOutShort.checked)
			{
				OutShort = 'Y';
			}
			
			if (chkBroker.checked)
			{
				VBroker = 'Y';
			}
			
			if (chkBen.checked)
			{
				VBen = 'Y';
			}
		}
		
		//cmdGenerate.disabled = true;
		
		if 	( ShowPrintType.value == "True")
		{
			if ( PrintType[0].checked )
			{
				printType	=	"P";
			}
		}

		if 	( ShowBrokerage.value == "True")
		{
			if ( Brokerage[0].checked )
			{
				DispBrk		=	"Y";
			}
		}

		if 	( ShowBillAmount.value == "True")
		{
			if ( BillAmount[0].checked )
			{
				DispBill	=	"Y";
			}
		}
		
		if 	( ShowLedgerBal.value == "True")
		{
			if ( LedgerBal[0].checked )
			{
				DispLedBal	=	"Y";
			}
		}

		if 	( ShowTransactionType.value == "True")
		{
			if ( TransactionType[1].checked )
			{
				TransType	=	"N";
			}
			
			if ( TransactionType[0].checked )
			{
				TransType	=	"Y";
			}	
		}
		
		if 	( ShowFoType.value == "True")
		{
			if ( FoType[0].checked )
			{
				foType	=	"F";
			}
			
			if ( FoType[1].checked )
			{
				foType	=	"O";
			}
		}
		
		if 	( ShowNilBalance.value == "True")
		{
			if ( NilBalance[1].checked )
			{
				NilBal		=	"-1";
			}
		}
		
		if 	( ShowFontType.value == "True")
		{
			if ( FontType[1].checked )
			{
				fontCondense	=	"Y";
			}
		}

		if 	( ShowDepository.value == "True")
		{
			if ( Depository[0].checked )
			{
				Depo	=	"NSDL";
			}
			else if ( Depository[1].checked )
			{
				Depo	=	"CDSL";
			}
		}

		if 	( ShowClientType.value == "True")
		{
			if ( ClientType[0].checked )
			{
				CType	=	"NSDL";
			}
			else if ( ClientType[1].checked )
			{
				CType	=	"CDSL";
			}
		}
		
		if 	( ShowPaperSize.value == "True")
		{
			if ( Papersize[1].checked )
			{
				PaperSize	=	"Half";
			}
		}
		
		if	( ReportButtonName.value == "cmdMulOSP" || ReportButtonName.value == "cmdMulOSPWoBill" )
		{
			if ( LastExpiry.checked )
			{
				lastExpiry	=	"Yes";
			}
		}

		if 	( ShowNetMargin.value == "True")
		{
			if ( NetMargin[0].checked )
			{
				netMar		=	"Y";
			}
		}

		if 	( ShowNetFutMToM.value == "True")
		{
			if ( FutMTOM[0].checked )
			{
				netFut		=	"Y";
			}
		}

		if 	( ShowNetOption.value == "True")
		{
			if ( NetOption[0].checked )
			{
				netOpt		=	"Y";
			}
		}
		
		if 	( ShowIncludeZero.value == "True")
		{
			if ( IncludeZero[0].checked )
			{
				inclZero	=	"Y";
			}
		}
		
		if 	( ShowSpanMargin.value == "True")
		{
			if ( ShowSpan[0].checked )
			{
				spanMg		=	"Y";
			}
		}
		
		if ( ShowNarration.value == "True" )
		{	
			if ( Narration[1].checked )
			{
				narr 		=	"False";
			}
		}

		if ( ShowFaVoucherOrder.value == "True" )
		{
			if ( VoucherOrder[1].checked )
			{
				ord 		=	"M";
			}
		}

		if ( ShowFaTransType.value == "True" )
		{
			vType		=	"";
			if ( VoucherType[0].checked )
			{
				vType 	=	"'R'";	  
			}
			if ( VoucherType[1].checked )
			{
				vType 	=	vType + ",'P'";
			}
			if ( VoucherType[2].checked )
			{
				vType 	=	vType + ",'J'";
			}
			if ( VoucherType[3].checked )
			{
				vType 	=	vType + ",'SJ'";
			}
			
		}
		
		if ( ShowFaPrintType.value == "True" )
		{
			if ( FaPrintType[0].checked )
			{
				faPrintType = "P";
			}
		}
		
		if ( ShowOrderTradeNo.value	==	"True" )
		{
			if ( DispOrderNo[1].checked )
			{
				DispOrd		=	"N";
			}
		}
		
		if ( ShowScripNet.value	==	"True" )
		{
			if ( ScripwiseNet[1].checked )
			{
				DispScripNet =	"N";
			}
		}
		
		if 	( ShowReportType.value == "True")
		{
			if ( FileType[1].checked )
			{
				fileType	=	"E";
			}
			if ( FileType[2].checked )
			{
				fileType	=	"EM";
			}
			
			if ( OutputType[0].checked )
			{
				outputType	=	"Screen";
			}
			else if ( OutputType[1].checked )
			{
				outputType	=	"Print";
			}
		}

		if ( ShowOpenPrice.value == "True" )
		{
			if ( BFPrice.checked )
			{
				withBfPrice = "True";
			}
		}

		if ( ShowNetAmount.value == "True" )
		{
			if ( withNetAmount[1].checked )
			{
				NetAmount = "False";
			}
		}
		
		if ( ShowPrintBatchNo.value == "True" )
		{
			if ( BatchNo[1].checked )
			{
				batchNo	=	CmbBatchNo.value;
			}
		}
				
		billFormat = "D";
		if ( ShowPrePrintedBillFormat.value == "True" )
		{
			billFormat = "D";
			if (optBillFormat[1].checked)
			{
				billFormat = 'S';
			}
		}

		webXContract = "N";
		if ( ShowECNPrintInContract.value == "True" )
		{
			if (optWebXContract[0].checked)
			{
				webXContract = 'Y';
			}
		}

		orderBy = "Family";
		if ( ShowOrderByInContract.value == "True" )
		{
			if (optOrderByInContract[1].checked)
			{
				orderBy = 'Client';
			}
		}
		
		withMarginAc = "N";
		if ( ShowPostingMarginAc.value == "True" )
		{
			if (optShowMarginAcBalance[0].checked)
			{
				withMarginAc = 'Y';
			}
		}

		if ( ShowBilledOrNot.value == "True" )
		{
			if ( BilledOrAll[0].checked)
			{
				LedgerOp = "Billed";
			}
			else
			{
				 LedgerOp = "All";
			}
		}
		
		if ( ShowStationaryType.value == "True" )
		{
			if ( optStationary[0].checked )
			{
				stationary = 'L';
			}
			
			if ( optStationary[1].checked )
			{
				stationary = 'S';
			}
		}
		
		/*Pre-Printed Contract*/
		if ( ReportButtonName.value == "cmdPreCont" )
		{
			contType = "";
			if ( ContractType.value	==	"C2" )
			{								
				contType = "A4";
			}
			
			if ( fileType	==	"T" )
			{
				if (COCD.value == "NCDEX")
				{
					FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/NCDXPrePrintedContractTextType1.cfm?" + commonParam +"&Client="+ txtBranch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&ContractNo=&From_Date=" + From_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&Type=Detail&PrintDate=&ReportType &ShowNet=&Title=&Order=&RepID=" +ReportNo.value + "&StationaryType=" + stationary;
				}
				else if (COCD.value == "MCX")
				{
					FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/MCXPrePrintedContractTextType1.cfm?" + commonParam +"&Client="+ txtBranch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&ContractNo=&From_Date=" + From_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&Type=Detail&PrintDate=&ReportType &ShowNet=&Title=&Order=&RepID=" +ReportNo.value + "&StationaryType=" + stationary;
				}

				else
				{
					FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/" + contType + "PrePrintedContractText.cfm?" + commonParam +"&Client="+ txtBranch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&ContractNo=&From_Date=" + From_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&Type=Detail&PrintDate=&ReportType &ShowNet=&Title=&Order=&RepID=" +ReportNo.value + "&StationaryType=" + stationary +"&webXContract=" + webXContract +"&orderBy="+orderBy;
				}	
			}
			else
			{
				FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/"+ COCD.value +"ContractHTML.cfm?" + commonParam +"&Client="+ txtBranch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&ContractNo=&From_Date=" + From_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&Type=Detail&PrintDate=&ReportType=&ShowNet=&Title=&Order=&RepID=" +ReportNo.value + "&StationaryType=" + stationary;			
			}
		}
		
		/*Pre-Printed Bill*/
		if ( ReportButtonName.value == "cmdPreBill" )
		{
			//alert(ReportButtonName.value)
			if ( BillType.value	==	"BILL1" )
			{								 
				billType = "Type1";
			}
			else if( BillType.value	==	"BILL2" )
			{
				billType = "Type2";			
			}
			else
			{
				billType = "Type3";			
			}
			
			/*if (optPaperType[0].checked)
			{
				paperType = 'Printed';
			}
			if (optPaperType[1].checked)
			{
				paperType = 'Plain';
			}*/
			
			//if (paperType == 'Printed')
			//{
				if (COCD.value == "NCDEX")
				{
					FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/NCDXPrePrintedBillText" + billType +".cfm?" + commonParam +"&Client="+ txtBranch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=&From_Date=" + From_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&Type=Detail&PrintDate=&ReportType=&ShowNet=&Title=&Order=&ShowNetMargin="+ netMar +"&ShowNetFuture="+ netFut +"&ShowNetOption="+ netOpt +"&RepID=" +ReportNo.value+"&Branchwise=" + branchwiseFile;
				}
				else
				{
					FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/PrePrintedBillText" + billType +".cfm?" + commonParam +"&Client="+ txtBranch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=&From_Date=" + From_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&Type=Detail&PrintDate=&ReportType=&ShowNet=&Title=&Order=&ShowNetMargin="+ netMar +"&ShowNetFuture="+ netFut +"&ShowNetOption="+ netOpt +"&RepID=" +ReportNo.value +"&Branchwise=&BillFormat=" + billFormat +"&StationaryType="+ stationary + "&orderBy="+orderBy+ "&withMarginAc=" + withMarginAc;
				}
			//}
			/*else
			{
				FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/PlainBillText.cfm?" + commonParam +"&Client="+ txtBranch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=&From_Date=" + From_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&Type=Detail&PrintDate=&ReportType=&ShowNet=&Title=&Order=&ShowNetMargin="+ netMar +"&ShowNetFuture="+ netFut +"&ShowNetOption="+ netOpt +"&RepID=" +ReportNo.value +"&Branchwise=" + branchwiseFile;
			}*/	
		}

		if ( ReportButtonName.value == "cmdPlainBill" )
		{
			//alert(ReportButtonName.value)
			billType = "Type1";
			/*if (optPaperType[0].checked)
			{
				paperType = 'Printed';
			}
			if (optPaperType[1].checked)
			{
				paperType = 'Plain';
			}*/
			
			//if (paperType == 'Printed')
			//{
				if (COCD.value == "NCDEX")
				{
					FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/NCDXPrePrintedBillText" + billType +".cfm?" + commonParam +"&Client="+ txtBranch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=&From_Date=" + From_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&Type=Detail&PrintDate=&ReportType=&ShowNet=&Title=&Order=&ShowNetMargin="+ netMar +"&ShowNetFuture="+ netFut +"&ShowNetOption="+ netOpt +"&RepID=" +ReportNo.value+"&Branchwise=" + branchwiseFile;
				}
				else
				{
					FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/PrePrintedBillText" + billType +".cfm?" + commonParam +"&Client="+ txtBranch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=&From_Date=" + From_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&Type=Detail&PrintDate=&ReportType=&ShowNet=&Title=&Order=&ShowNetMargin="+ netMar +"&ShowNetFuture="+ netFut +"&ShowNetOption="+ netOpt +"&RepID=" +ReportNo.value +"&Branchwise=&BillFormat=" + billFormat +"&StationaryType="+ stationary + "&orderBy="+orderBy+ "&withMarginAc=" + withMarginAc;
				}
			//}
			/*else
			{
				FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/PlainBillText.cfm?" + commonParam +"&Client="+ txtBranch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=&From_Date=" + From_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&Type=Detail&PrintDate=&ReportType=&ShowNet=&Title=&Order=&ShowNetMargin="+ netMar +"&ShowNetFuture="+ netFut +"&ShowNetOption="+ netOpt +"&RepID=" +ReportNo.value +"&Branchwise=" + branchwiseFile;
			}*/	
		}

		/*Pre-Printed Bill*/
		if ( ReportButtonName.value == "cmdMulPreBill" )
		{
			FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/PrePrintedBillText.cfm?" + commonParam +"&Client="+ txtBranch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=&From_Date=" + From_Date.value +"&To_Date=" + To_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&Type=Detail&PrintDate=&ReportType=&ShowNet=&Title=&Order=&RepID=" +ReportNo.value;
		}
		
		/*Sauda Summary */
		if ( ReportButtonName.value == "cmdSaudaSum" )
		{
			if ( Market.value == "CAPS")
			{
				FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/Transaction_Summary.cfm?" + commonParam +"&fileType="+ fileType +"&Client="+ txtBranch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=&From_Date=" + From_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&PrintType=" + printType +"&DispBrk=" + DispBrk +"&DispLedBal=" + DispLedBal +"&fontCondense=" + fontCondense +"&PaperSize=" + PaperSize +"&RepID=" +ReportNo.value +"&Output=" + outputType +"&Branchwise=" + branchwiseFile + "&WithSale=" + WithSale + "&WithPurchase=" + WithPurchase; // + "&ClientID2=" + txtClientID2.value
			}
			else
			{
				FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/Transaction_Summary.cfm?" + commonParam +"&fileType="+ fileType +"&Client="+ txtBranch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=&From_Date=" + From_Date.value +"&To_Date=" + To_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&PrintType=" + printType +"&DispBrk=" + DispBrk +"&DispLedBal=" + DispLedBal +"&DispBill=" + DispBill + "&TransType=" + TransType +"&fontCondense=" + fontCondense +"&Output=" + outputType +"&PaperSize=" + PaperSize +"&RepID=" +ReportNo.value +"&Branchwise=" + branchwiseFile + "&WithSale=" + WithSale + "&WithPurchase=" + WithPurchase;
			}	
		}
		
		if ( ReportButtonName.value == "cmdSaudaSumCIDDateWise" )
		{
			if ( Market.value == "CAPS")
			{
				FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/Transaction_Summary_CID.cfm?" + commonParam +"&fileType="+ fileType +"&Client="+ txtBranch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=&From_Date=" + From_Date.value + "&To_Date=" + To_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&PrintType=" + printType +"&DispBrk=" + DispBrk +"&DispLedBal=" + DispLedBal +"&fontCondense=" + fontCondense +"&PaperSize=" + PaperSize +"&RepID=" +ReportNo.value +"&Output=" + outputType +"&Branchwise=" + branchwiseFile + "&WithSale=" + WithSale + "&WithPurchase=" + WithPurchase + "&Opening=" + Opening; // + "&ClientID2=" + txtClientID2.value
			}
		}
		
		if ( ReportButtonName.value == "cmdSaudaSumCID2DateWise" )
		{
			if ( Market.value == "CAPS")
			{
				FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/Transaction_Summary_CID2.cfm?" + commonParam +"&fileType="+ fileType +"&Client="+ "&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value + "&ToClient=&BillNo=&From_Date=" + From_Date.value + "&To_Date=" + To_Date.value +"&BranchID=" + "&FamilyGroup=" + "&PrintType=" + printType +"&DispBrk=" + DispBrk +"&DispLedBal=" + DispLedBal +"&fontCondense=" + fontCondense +"&PaperSize=" + PaperSize +"&RepID=" +ReportNo.value +"&Output=" + outputType +"&Branchwise=" + branchwiseFile + "&WithSale=" + WithSale + "&WithPurchase=" + WithPurchase + "&ClientID2=" + txtClientID2.value + "&Scrip=" + FromSymbol.value + "&Absolute=" + Absolute + "&Opening=" + Opening; //"&FromClient=" +escape( FromClient.value ) +
			}
		}
		
			/*Sauda Detail */
		if ( ReportButtonName.value == "cmdSaudaDet" )
		{
			if ( Market.value == "CAPS")
			{
				FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/Transaction_Detail.cfm?" + commonParam +"&Client=&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=&From_Date=" + From_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&PrintType=" + printType +"&DispBrk=" + DispBrk +"&DispLedBal=" + DispLedBal +"&fontCondense=" + fontCondense +"&PaperSize=" + PaperSize +"&ShowScripWiseNet=" + DispScripNet +"&ShowOrderNo=" + DispOrd + "&RepID=" +ReportNo.value;
			}
			else
			{
				FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/Transaction_Detail.cfm?" + commonParam +"&Client="+ txtBranch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=&From_Date=" + From_Date.value +"&To_Date=" + To_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&PrintType=" + printType +"&DispBrk=" + DispBrk +"&DispLedBal=" + DispLedBal +"&DispBill=" + DispBill + "&TransType=" + TransType +"&ShowScripWiseNet=" + DispScripNet +"&ShowOrderNo=" + DispOrd +"&RepID=" +ReportNo.value + "&Branchwise=" + branchwiseFile;
			}	
		}
		
		/* Bill Absolute Summary */		
		if ( ReportButtonName.value == "cmdBillAbs" )
		{
			if ( Market.value == "CAPS")
			{
				FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/BillAbsSummary.cfm?" + commonParam +"&Client="+ txtBranch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=&From_Date=" + From_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=&DispBrk=" + DispBrk +"&DispLedBal=" + DispLedBal +"&PaperSize=" + PaperSize +"&fontCondense=" + fontCondense +"&RepID=" +ReportNo.value+"&LedgerOp="+LedgerOp;
			}	
			else
			{
				FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/BillAbsSummary.cfm?" + commonParam +"&Client="+ txtBranch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=&From_Date=" + From_Date.value +"&To_Date=" + To_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=&PrintType=" + printType +"&DispBrk=" + DispBrk +"&DispLedBal=" + DispLedBal +"&DispBill=" + DispBill + "&TransType=" + TransType +"&ShowScripWiseNet=" + DispScripNet +"&ShowOrderNo=" + DispOrd +"&RepID=" +ReportNo.value;
			}	

		}
		
		/*Multidate OS-Position Office Copy*/
		if ( ReportButtonName.value == "cmdMulOSP" || ReportButtonName.value == "cmdMulOSPWoBill" || ReportButtonName.value == "cmdOSP" || ReportButtonName.value == "cmdCFOSP")
		{
			if ( ReportButtonName.value == "cmdCFOSP" )
			{
				cfPerc = txtCFPerc.value;
				lastTrDt = txtLastTrDt.value;
			}					
			else
			{
				cfPerc = 0;
				lastTrDt = "";
			}
			FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/MultiDateOSPosition.cfm?" + commonParam +"&fileType="+ fileType +"&Client="+ txtBranch.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&FROM_LAST_EXPIRY=" + lastExpiry +"&From_Date=" + From_Date.value +"&To_Date=" + To_Date.value +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value +"&FromSymbol=&ToSymbol=&LastTrDt=" + lastTrDt + "&FoType=" + foType + "&PrintType=" + printType + "&PaperSize=" + PaperSize +"&inclZero=" + inclZero +"&showSpan=" + spanMg + "&CFPerc=" + cfPerc + "&withBfPrice=" + withBfPrice + "&Output=" + outputType +"&ShowNetAmt=" + NetAmount +"&Branchwise=" + branchwiseFile + "&RepID=" +ReportNo.value;
		}

		/*Trial Balance*/
		if ( ReportButtonName.value == "cmdTB" )
		{
			FileGeneration.location.href = "/Client/Text_Reports/Accounts/AccountSummary.cfm?" + commonParam +"&Client=&From_Date=" + From_Date.value + "&ReportType=TrialBalance&ReportName=Trial Balance&Group=KindOfAccount&DrCrFilter=" + CmbDrCr.value + "&Operator=" + CmbOperator.value + "&DrCrVal=" + txtFilterValue.value + "&NilBalance=" + NilBal;
		}

		/*Client Summary*/
		if ( ReportButtonName.value == "cmdClSum" )
		{
			FileGeneration.location.href = "/Client/Text_Reports/Accounts/AccountSummary.cfm?" + commonParam +"&Client=&From_Date=" + From_Date.value + "&ReportType=ClientSummary&ReportName=Client Report&Group=CompanyCode&DrCrFilter=" + CmbDrCr.value + "&Operator=" + CmbOperator.value + "&DrCrVal=" + txtFilterValue.value + "&NilBalance=" + NilBal +"&FromClient=" + txtFromClient.value +"&ToClient=" + txtToClient.value + "&Branch_Code=" + txtBranch.value;
		}
		
		/*Opening Balance*/
		if ( ReportButtonName.value == "cmdOpSum" )
		{
			FileGeneration.location.href = "/Client/Text_Reports/Accounts/AccountSummary.cfm?" + commonParam +"&Client=&From_Date=" + From_Date.value + "&ReportType=FAOpening&ReportName=Fa Opening&Group=KindOfAccount&DrCrFilter=" + CmbDrCr.value + "&Operator=" + CmbOperator.value + "&DrCrVal=" + txtFilterValue.value + "&NilBalance=" + NilBal;
		}

		/*Opening Balance*/
		if ( ReportButtonName.value == "cmdGrpSum" )
		{
			var AbsSum;
			if ( chkAbs.checked )
			{
				AbsSum = 'Y';
			}
			else
			{
				AbsSum = 'N';
			}
			
			FileGeneration.location.href = "/Client/Text_Reports/Accounts/AccountSummary.cfm?" + commonParam +"&Client=&From_Date=" + From_Date.value + "&Family_Group=" + txtFamily.value +"&ReportType=GroupSummary&ReportName=Groupwise Summary&Group=FamilyGroupCode&DrCrFilter=" + CmbDrCr.value + "&Operator=" + CmbOperator.value + "&DrCrVal=" + txtFilterValue.value + "&NilBalance=" + NilBal + "&AbsSummary=" + AbsSum;
		}
		
		/*Account Detail*/
		if ( ReportButtonName.value == "cmdAcDet" )
		{
			var AccConfirm;
			if ( optAccConfirm[0].checked )
			{
				AccConfirm = 'Y';
			}
			else
			{
				AccConfirm = 'N';
			}
			
			FileGeneration.location.href = "/Client/Text_Reports/Accounts/AccountDetail.cfm?" + commonParam +"&fileType="+ fileType +"&From_Date=" + From_Date.value + "&To_Date=" + To_Date.value + "&ReportType=AcDetail&ReportName=Account Detail&Family_Group_List=&Ledger_List=" + FromClient.value + "&ShowNarration=" + narr + "&Transaction_Type_List=" + vType + "&Output=" + outputType + "&FaPrintType=" + faPrintType +"&FaVoucherOrder=" + ord + "&AccConfirmation=" + AccConfirm+"&Form1=Detail";
		} 
		
		if ( ReportButtonName.value == "cmdVPrint" )
		{
			FileGeneration.location.href = "/Client/Text_Reports/Accounts/VoucherPrint.cfm?" + commonParam + "&Date=" + From_Date.value + "&BankCode=" + cmbBankCode.value + "&VNo=" + cmbVoucherNo.value +  "&ReportName=Voucher Print&Form1=Detail";
		} 

		/*Journal Report*/
		if ( ReportButtonName.value == "cmdJVReport" )
		{
			FileGeneration.location.href = "/Client/Text_Reports/Accounts/JournalReport.cfm?" + commonParam +"&fileType="+ fileType +"&Client=&From_Date=" + From_Date.value + "&To_Date=" + To_Date.value + "&ReportType=JV&ReportName=Journal Report&Family_Group_List=&Ledger_List=&ShowNarration=" + narr + "&Transaction_Type_List=" + vType + "&FaPrintType=&FaVoucherOrder=";
		}  
		
		/* Payout To Clients */
		if ( ReportButtonName.value == "cmdClientPayOut" )
		{
			if (OutputType == 'P')
			{
				FileGeneration.location.href = "/Client/Text_Reports/Stock/PayoutToCLient.cfm?"  + commonParam +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&Depository=" + Depo +"&ClientType=" + CType +"&PrintDate=" + txtPrintDate.value + "&SerialNo=" + txtSerialNo.value + "&SlipNo=" + CmbIOSlipNo.value;
			}
			if (OutputType == 'F')
			{   alert(Depo + "  " + CType);
				if ( Depo == "NSDL" & CType == "NSDL")
				{
					FileGeneration.location.href = "/Client/IO_FOCAPS/Transactions/PayOutTextFile.cfm?"  + commonParam +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&Depository=" + Depo +"&ClientType=" + CType +"&PrintDate=" + txtPrintDate.value + "&SerialNo=" + txtSerialNo.value + "&SlipNo=" + CmbIOSlipNo.value; //+ "&ExecutionDate=" + CmbExecDate.value 
				}
				else if ( Depo == "NSDL" & CType == "CDSL")
				{
					FileGeneration.location.href = "/Client/IO_FOCAPS/Transactions/InterDPTextFile.cfm?"  + commonParam +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&Depository=" + Depo +"&ClientType=" + CType +"&PrintDate=" + txtPrintDate.value + "&SerialNo=" + txtSerialNo.value + "&SlipNo=" + CmbIOSlipNo.value; //+ "&ExecutionDate=" + CmbExecDate.value 
				}	
			}
		}
		
		/* InterSettlement Instructions */
		if ( ReportButtonName.value == "cmdInterSet" )
		{
			if (OutputType == 'P')
			{
				FileGeneration.location.href = "/Client/Text_Reports/Stock/InterSetInstruction.cfm?"  + commonParam +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&PrintDate=" + txtPrintDate.value + "&SerialNo=" + txtSerialNo.value + "&SlipNo=";
			}
			if (OutputType == 'F')
			{
				FileGeneration.location.href = "/Client/IO_FOCAPS/Transactions/InterSettlementTextFile.cfm?"  + commonParam +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&PrintDate=" + txtPrintDate.value + "&SerialNo=" + txtSerialNo.value + "&SlipNo="; //+"&ExecutionDate=" + CmbExecDate.value
			}	
		}
		
		/* Export Payout To Clients */
		if ( ReportButtonName.value == "cmdClientPayOutToExport" )
		{	 
			if ( txtSlipNo.value == '' )
			{
			 	alert("Please enter SlipNo !");
			}
			if ( txtBatchNo.value == '' )
			{
			 	alert("Please enter BatchNo !");
			}
			else
			{
				FileGeneration.location.href = "/Client/Text_Reports/Stock/ExportPayoutToCLient.cfm?"  + commonParam +"&Client=&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&Depository=NSDL&ClientType=NSDL&ExecutionDate=" + CmbExecDate.value +"&PrintDate=" + txtPrintDate.value + "&BatchNo=" + txtBatchNo.value + "&SlipNo=" + txtSlipNo.value;
			}	
		}
	
		/*STT Certificate*/
		if ( ReportButtonName.value == "cmdSTTCerticate" )
		{
			FileGeneration.location.href = "/Client/Text_Reports/Trading/"+Market.value+"/STT_Certificate.cfm?" + commonParam +"&Client=&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) + "&ToClient=&BillNo=" +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value  + "&SttRepGen=" + SttRepGen + "&From_Date=" + From_Date.value + "&To_Date=" + To_Date.value;
		}

		/* On Market Instructions */
		if ( ReportButtonName.value == "cmdBenOnMarket" || ReportButtonName.value == "cmdPoolOnMarket")
		{
			if (OutputType == 'P')
			{
				FileGeneration.location.href = "/Client/Text_Reports/Stock/OnMarketInstruction.cfm?"  + commonParam +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&PrintDate=" + txtPrintDate.value + "&SerialNo=" + txtSerialNo.value + "&Depository=" + Depo + "&SlipNo=" + CmbIOSlipNo.value + "&RType=" + RT;
			}
			if (OutputType == 'F')
			{
				FileGeneration.location.href = "/Client/IO_FOCAPS/Transactions/PayInTextFile.cfm?"  + commonParam +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&PrintDate=" + txtPrintDate.value + "&SerialNo=" + txtSerialNo.value + "&Depository=" + Depo + "&SlipNo=" + CmbIOSlipNo.value + "&RType=" + RT; //+"&ExecutionDate=" + CmbExecDate.value
			}	
		}
		
		/* Off Market Instructions And	InterDP File Instructions*/
		if ( 	ReportButtonName.value == "cmdBenOffMarket" || ReportButtonName.value == "cmdBenInterDP"  )
		{
			if (OutputType == 'P')
			{
				FileGeneration.location.href = "/Client/Text_Reports/Stock/OffInInstruction.cfm?"  + commonParam +"&From_Date=" + From_Date.value + "&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&ExecutionDate=" + CmbExecDate.value +"&BatchNo=" + batchNo +"&Beneficiary=" + CmbBenID.value + "&PrintDate=" + txtPrintDate.value + "&SerialNo=" + txtSerialNo.value;
			}
			else
			{	
				if ( ReportButtonName.value == "cmdBenOffMarket" )
				{
					FileGeneration.location.href = "/Client/IO_FOCAPS/Transactions/OffMarketFileGeneration.cfm?"  + commonParam +"&From_Date=" + From_Date.value + "&MktType=" +Mkt_Type.value +"&SetlNo=" +Settlement_No.value +"&ExecutionDate=" + CmbExecDate.value +"&BatchNo=" + batchNo +"&Beneficiary=" + CmbBenID.value + "&FILE_TYPE=BrkBenToClient";
				}
				else if ( ReportButtonName.value == "cmdBenInterDP" )
				{
					FileGeneration.location.href = "/Client/IO_FOCAPS/Transactions/InterDPFileGeneration.cfm?"  + commonParam +"&From_Date=" + From_Date.value + "&MktType=" +Mkt_Type.value +"&SetlNo=" +Settlement_No.value +"&ExecutionDate=" + CmbExecDate.value +"&BatchNo=" + batchNo +"&Beneficiary=" + CmbBenID.value + "&FILE_TYPE=BrkBenToClient";
				}	
			}	
		}
		
		if ( ReportButtonName.value == "cmdBenSummary" )
		{
			FileGeneration.location.href = "/Client/Text_Reports/Stock/BenSummary_Data.cfm?"  + commonParam +"&FromClient=" +escape( FromClient.value ) +"&BranchID=" +txtBranch.value +"&FamilyGroup=" + txtFamily.value + "&InShort=" + InShort + "&OutShort=" + OutShort  + "&VBen=" + VBen + "&VBroker=" + VBroker; //+ "&VType=" + VType;
		}
		
		if ( ReportButtonName.value == "cmdBenDetail" )
		{
			FileGeneration.location.href = "/Client/Text_Reports/Stock/BenDetail_Data.cfm?"  + commonParam +"&FromClient=" +escape( FromClient.value ) +"&FamilyGroup=" + txtFamily.value +"&BranchID=" +txtBranch.value + "&FrmDate=" + txtFrmDate.value + "&ToDate=" + txtToDate.value;
		}
	}	
}

/*

if ( chkInShort.checked )
		{
			InShort		=	'Y';
		}
		
		if ( chkOutShort.checked )
		{
			OutShort	=	'Y';
		}
		
		if ( chkBen.checked )
		{
			VBen	=	'Y';
		}
		
		if ( chkBroker.checked )
		{
			VBroker	=	'Y';
		}
*/ 				
		
			