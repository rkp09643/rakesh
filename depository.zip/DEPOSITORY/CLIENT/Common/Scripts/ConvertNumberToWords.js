var numberWords = "", decimalPointIndex;

 //VALIDATION FOR NUMBERS
function validateNumber( numObjVal, displayType )
{
	if( ( numObjVal == "" ) || ( numObjVal.charAt(0) == " " ) || ( numObjVal == "0" ) )
	{
		alert( "Please enter a value." );
		return "";
	}
	else
	{
		numObjVal = numObjVal.valueOf();
		
		//CHECKS ENTERED VALUE IS NOT A NUMBER(isNaN)
		if( isNaN( numObjVal ) )
		{
			alert( "Please enter a Numeric value." );
			return "";
		}
		else
		{
			numObjVal = new Number( numObjVal );
			
   			//CHECK FOR DECIMAL
			numObjVal = new String( numObjVal );
			decimalPointIndex = numObjVal.indexOf( "." );
			
			if( decimalPointIndex != -1 )
			{
				decimalNumber = numObjVal.substring( decimalPointIndex + 1, numObjVal.length );
				
				if( decimalNumber.length > 2 )
				{
					deciNumVal = numObjVal.substring( 0, decimalPointIndex + 3 );
					
					wholeNumber = deciNumVal.substring( 0, decimalPointIndex );
					wholeNumWords = numberToWords( new Number( wholeNumber ) );
					
					decimalNumber = deciNumVal.substring( decimalPointIndex + 1, deciNumVal.length );
					decimalNumWords = returnTens( decimalNumber );
				}
				else
				{
					wholeNumber = numObjVal.substring( 0, decimalPointIndex );
					wholeNumWords = numberToWords( new Number( wholeNumber ) );
					
					decimalNumWords = returnTens( decimalNumber );
				}
				
				if( displayType == "Money" )
				{
					if( decimalNumWords.length > 0 )
					{
						return "Rs." +wholeNumWords +" and Paise" +decimalNumWords +" Only.";
					}
					else
					{
						return "Rs." +wholeNumWords +" Only.";
					}
				}
				else if( displayType == "Qty" )
				{
					return wholeNumWords +" Only.";
				}
			}
			else
			{
				if( displayType == "Money" )
				{
					return "Rs." +numberToWords( new Number( numObjVal ) ) +" Only.";
				}
				else if( displayType == "Qty" )
				{								
					return numberToWords( new Number( numObjVal ) ) +" Only.";
				}
			}
		}
	}
}


//CALLING FUNCTION ACCORDING TO LENGTH
function numberToWords( numVal )
{
	numVal = new String( numVal );
	var numberLength = numVal.length;
	
	if( numberLength == 1 )
    {   
		numberWords = returnOnes( numVal );
	}
	else if( numberLength == 2 )
	{
		numberWords = returnTens( numVal );
	}
	else if( numberLength == 3)
	{
		numberWords = returnHundreds( numVal );
	}
	else if( numberLength == 4)
	{
		numberWords = returnThousands( numVal );
	}
	else if( numberLength == 5)
	{
		numberWords = returnTenThousands( numVal );
	}
	else if( numberLength == 6)
	{
		numberWords = returnLakhs( numVal );
	}
	else if( numberLength == 7)
	{
		numberWords = returnTenLakhs( numVal );
	}
	else if( numberLength == 8)
	{
		numberWords = returnCrores( numVal );
	}
	else if( numberLength == 9)
	{
		numberWords = returnTenCrores( numVal );
	}
	else if( numberLength == 10)
	{
		numberWords = returnHundredCrores( numVal );
	}
	else if( numberLength == 11)
	{
		numberWords = returnThousandCrores( numVal );
	}
	else
	{
		numberWords = "Others";
	}
	
	return numberWords;
}


// FUNCTION FOR ONE DIGHT
function returnOnes( numVal )
{
	var strOnes = "";
	
	switch( parseInt( numVal ) )
	{
		case 1:
			strOnes = " One";
			break;
		case 2:
			strOnes = " Two";
			break;
		case 3:
			strOnes = " Three";
			break;
		case 4:
			strOnes = " Four";
			break;
		case 5:
			strOnes = " Five";
			break;
		case 6:
			strOnes = " Six";
			break;
		case 7:
			strOnes = " Seven";
			break;
		case 8:
			strOnes = " Eight";
			break;
		case 9:
			strOnes = " Nine";
			break;
	}
	return strOnes;
}	


//FUNCTION FOR TWO DIGHTS
function returnTens( numVal )
{
	var strTens = "";
	var firstDigit = numVal.charAt(0);
	var secondDigit = numVal.charAt(1);
	
	if ( firstDigit == "1" ) 
	{
		switch( parseInt( numVal ) )
		{
			case 10:
				strTens = " Ten";
				break;
			case 11:
				strTens = " Eleven";
				break;
			case 12:
				strTens = " Twelve";
				break;
			case 13:
				strTens = " Thirteen";
				break;
			case 14:
				strTens = " Fourteen";
				break;
			case 15:
				strTens = " Fifteen";
				break;
			case 16:
				strTens = " Sixteen";
				break;
			case 17:
				strTens = " Seventeen";
				break;
			case 18:
				strTens = " Eighteen";
				break;
			case 19:
				strTens = " Nineteen";
				break;
		}
		
		return strTens;
	}
	else
	{
		switch( parseInt( firstDigit ) )
		{
			case 1:
				strTens = " Ten";
				break;
			case 2:
				strTens = " Twenty";
				break;
			case 3:
				strTens = " Thirty";
				break;
			case 4:
				strTens = " Fourty";
				break;
			case 5:
				strTens = " Fifty";
				break;
			case 6:
				strTens = " Sixty";
				break;
			case 7:
				strTens = " Seventy";
				break;
			case 8:
				strTens = " Eighty";
				break;
			case 9:
				strTens = " Ninety";
				break;
		}
		
		return strTens +returnOnes( secondDigit );
	}
}


//FUNCTION FOR HUNDREDS		
function returnHundreds( numVal )
{
	var firstDigit = numVal.charAt(0);
	var secondDigit = numVal.charAt(1);
	var restDigit = numVal.substring(1);
	
	if( firstDigit != "0" )
	{
		return returnOnes( firstDigit.valueOf() ) +" Hundred" +returnTens( restDigit.valueOf() );
	}
	else
	{
		return returnTens( restDigit.valueOf() );
	}
}

		   
//FUNCTIONS FOR THOUSANDS
function returnThousands( numVal )
{
	var firstDigit = numVal.charAt(0);
	var secondDigit = numVal.charAt(1);
	var last2Digit = numVal.substring(2);
	var restDigit = numVal.substring(1);
	
	if( firstDigit != "0" )
	{
		return returnOnes( firstDigit.valueOf() ) +" Thousand" +returnHundreds( restDigit.valueOf() );
	}
	else
	{
		return returnHundreds( restDigit.valueOf() );
	}
	
}


//FUNCTIONS FOR TEN THOUSANDS
function returnTenThousands( numVal )
{
	var firstDigit = numVal.charAt(0);
	var first2Digit = numVal.substring(0, 2);
	var last3Digit = numVal.substring(2);			
	var restDigit = numVal.substring(1);
	
	if( firstDigit != "0" )
	{
		return returnTens( first2Digit.valueOf() ) +" Thousand" +returnHundreds( last3Digit.valueOf() );
	}
	else
	{
		return returnThousands(  restDigit.valueOf() ); 
	}
}


//FUNCTIONS FOR LAKHS
function returnLakhs( numVal )
{
	var firstDigit = numVal.charAt(0);
	var restDigit = numVal.substring(1);
	
	if( firstDigit != "0" )
	{
		return returnOnes( firstDigit.valueOf() ) +" Lakh" +returnTenThousands( restDigit.valueOf() );
	}
	else
	{
		return returnTenThousands( restDigit.valueOf() );
	}
}


//FUNCTIONS FOR TEN LAKHS
function returnTenLakhs( numVal )
{
	var firstDigit = numVal.charAt(0);
	var first2Digit = numVal.substring(0, 2);
	var last5Digit = numVal.substring(2);
	var last6Digit = numVal.substring(1);
	var restDigit = numVal.substring(1);
	
	if( firstDigit != "0" )
	{
		return returnTens( first2Digit.valueOf() ) +" Lakh" +returnTenThousands( last5Digit.valueOf() );
	}
	else
	{
		return returnLakhs(last6Digit.valueOf() );
	}
}


//FUNCTIONS FOR CRORES
function returnCrores( numVal )
{
	var restDigit = numVal.substring(1);
	var firstDigit = numVal.charAt(0);
	
	if( firstDigit != "0" )
	{
		return returnOnes( firstDigit.valueOf() ) +" Crore" +returnTenLakhs( restDigit.valueOf() );
	}
	else
	{
		return returnTenLakhs( restDigit.valueOf() );
	}
}


//FUNCTIONS FOR TEN CRORES
function returnTenCrores( numVal )
{
	var firstDigit = numVal.charAt(0);
	var first2Digit = numVal.substring(0, 2);		
	var restDigit = numVal.substring(2);
	
	if( firstDigit != "0" )
	{
		return returnTens( first2Digit.valueOf() ) +" Crore" +returnTenLakhs( restDigit.valueOf() );
	}
	else
	{
		return returnTenLakhs( restDigit.valueOf() );
	}
}


//FUNCTIONS FOR HUNDRED CRORES
function returnHundredCrores( numVal )
{
	var firstDigit = numVal.charAt(0);
	var first3Digit = numVal.substring(0, 3);		
	var last7Digit = numVal.substring(3);
	var restDigit = numVal.substring(2);
	
	if( firstDigit != "0" )
	{
		return returnHundreds( first3Digit.valueOf() ) +" Crore" +returnTenLakhs( last7Digit.valueOf() );
	}
	else
	{
		return returnTenCrores( restDigit.valueOf() );
	}
}


//FUNCTIONS FOR THOUSANDS CRORES
function returnThousandCrores( numVal )
{
	var firstDigit = numVal.charAt(0);
	var first4Digit = numVal.substring(0, 4);		
	var last7Digit = numVal.substring(4);
	var restDigit = numVal.substring(2);
	
	if( firstDigit != "0" )
	{
		return returnThousands( first4Digit.valueOf() ) +" Crore" +returnTenLakhs( last7Digit.valueOf() );
	}
	else
	{
		return returnHundredCrores( restDigit.valueOf() );
	}
}