/* ####################################################################################
					JAVASCRIPT FILE FOR HELP POPUP WINDOW.
#################################################################################### */


HelpWindow = new Object();

/* ********************************************
	FUNCTION FOR CLOSING HELP POPUP WINDOW.
******************************************** */
function CloseWindow ( )
{
	//document.ReportForm.msg.value = "";
	
	try
	{
		if ( ( typeof( HelpWindow ) == "object" ) && ( !HelpWindow.closed ) )
		{
			HelpWindow.close();
			throw "e";
		}
	}
	catch ( e )
	{
		return ( e );
	}
}


/* ********************************************
	FUNCTION FOR OPENING HELP POPUP WINDOW.
******************************************** */
function OpenWindow( form, par )
{
	with( ReportForm )
	{
		if( par == "Settlement" )
		{
			HelpWindow = open( "/Client/HelpSearch/TradingClients.cfm?COCD=" +COCD.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&mkt_type=" +Mkt_Type.value +"&helpfor=" +par +"&title=Report - " +ReportName.value, "HelpWindow", "width=700, height=525, scrollbar=no, top=0, left=0, menubar=no, titlebar=no, toolbar=no, status=no, resizeable=no" );
		}
		
		if(par == "Client" )
		{
			try
			{
				if( FromDate && ToDate)
				{
					HelpWindow = open( "/Client/HelpSearch/TradingClients.cfm?COCD="+ COCD.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&FromDate=" +FromDate.value +"&ToDate=" +ToDate.value +"&helpfor=" +par +"&title=Report - " +ReportName.value, "HelpWindow", "width=700, height=525, scrollbar=no, top=0, left=0, menubar=no, titlebar=no, toolbar=no, status=no, resizeable=no" );
				}
			}
			catch( e )
			{
				try
				{
					if( FromDate )
					{
						HelpWindow = open("/Client/HELPSEARCH/TradingClients.cfm?COCD="+ COCD.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&FromDate=" +FromDate.value +"&helpfor=" +par +"&title=Report - " +ReportName.value, "HelpWindow", "width=700, height=525, scrollbar=no, top=0, left=0, menubar=no, titlebar=no, toolbar=no, status=no, resizeable=no" );
					}
				}
				catch( e )
				{
					HelpWindow = open("/Client/HELPSEARCH/TradingClients.cfm?COCD="+ COCD.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&FromDate=" +"&helpfor=" +par +"&title=Report - " +ReportName.value, "HelpWindow", "width=700, height=525, scrollbar=no, top=0, left=0, menubar=no, titlebar=no, toolbar=no, status=no, resizeable=no" );
				}
			}
			
			try
			{
				if( Mkt_Type )
				{
					HelpWindow = open("/Client/HELPSEARCH/TradingClients.cfm?COCD="+ COCD.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&mkt_type=" +Mkt_Type.value +"&settlement_no=" +Settlement_No.value +"&helpfor=" +par +"&title=Report - " +ReportName.value, "HelpWindow", "width=700, height=525, scrollbar=no, top=0, left=0, menubar=no, titlebar=no, toolbar=no, status=no, resizeable=no" );
				}
			}
			catch( e ){ }
		}						
	}
}
 
/* ********************************************
	FUNCTION FOR OPENING HELP POPUP WINDOW.
******************************************** */
function OpenTextWindow( form, par )
{
	with( form )
	{
		if( par == "Settlement" )
		{
			HelpWindow = open( "/Client/HelpSearch/TradingClients.cfm?COCD=" +COCD.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&mkt_type=" +Mkt_Type.value +"&helpfor=" +par +"&title=Report - " +ReportName.value, "HelpWindow", "width=700, height=525, scrollbar=no, top=0, left=0, menubar=no, titlebar=no, toolbar=no, status=no, resizeable=no" );
		}
		
		if(par == "TrdGroup" )
		{
			HelpWindow = open( "/Client/FA_FOCAPS/HelpSearch/MultiClientsHelp.cfm?cocd="+ COCD.value +"&coname="+ CoName.value +"&StYr="+ FinStart.value +"&EndYr="+ FinEnd.value +"&Market=" + Market.value + "&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromDate=" +From_Date.value +"&ToDate=" +To_Date.value +"&TradingGroupHelp=&Object=txtFamily&helpfor=Groupcode" ,"HelpWindow", "width= 700 , height= 525 , scrollbar = no, top=0, left=0 menubar=no, titlebar=no, toolbar=no, status=no, resizeable=no" );		
		}
		
		if(par == "Group" )
		{
			HelpWindow = open( "/Client/FA_FOCAPS/HelpSearch/MultiClientsHelp.cfm?cocd="+ COCD.value +"&coname="+ CoName.value +"&StYr="+ FinStart.value +"&EndYr="+ FinEnd.value +"&Market=" + Market.value + "&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromDate=" +From_Date.value +"&ToDate=" +To_Date.value +"&Object=txtFamily&helpfor=Groupcode" ,"HelpWindow", "width= 700 , height= 525 , scrollbar = no, top=0, left=0 menubar=no, titlebar=no, toolbar=no, status=no, resizeable=no" );		
		}
		
		if(par == "Client" )
		{
			try
			{
				//if( FromDate && ToDate)
				//{
				if	( Market.value == "CAPS" )
				{
					HelpWindow = open( "/Client/HelpSearch/TradingClients.cfm?COCD="+ COCD.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&Client=" + txtBranch.value +"&TXTSEARCH=" + txtFamily.value +"&Family_Group=" + txtFamily.value +"&helpfor=" +par +"&CmdSingleSearch=&CmbSearch=A.FAMILY_GROUP&title=Report Help", "HelpWindow", "width=700, height=525, scrollbar=no, top=0, left=0, menubar=no, titlebar=no, toolbar=no, status=no, resizeable=no" );
				}
				else
				{
					HelpWindow = open( "/Client/HelpSearch/TradingClients.cfm?COCD="+ COCD.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&FromDate=" +From_Date.value +"&ToDate=" +To_Date.value +"&Client=" + txtBranch.value +"&Family_Group=" + txtFamily.value +"&helpfor=" +par +"&title=Report Help", "HelpWindow", "width=700, height=525, scrollbar=no, top=0, left=0, menubar=no, titlebar=no, toolbar=no, status=no, resizeable=no" );
				}
				//}
			}
			catch( e )
			{}
			
			try
			{
				if( Mkt_Type )
				{
					HelpWindow = open("/Client/HELPSEARCH/TradingClients.cfm?COCD="+ COCD.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&mkt_type=" +Mkt_Type.value +"&settlement_no=" +Settlement_No.value +"&helpfor=" +par +"&title=Report - " +ReportName.value, "HelpWindow", "width=700, height=525, scrollbar=no, top=0, left=0, menubar=no, titlebar=no, toolbar=no, status=no, resizeable=no" );
				}
			}
			catch( e ){ }
		}
		
		if(par == "FA" )
		{
			HelpWindow = open( "/Client/FA_FOCAPS/HelpSearch/MultiClientsHelp.cfm?cocd="+ COCD.value +"&coname="+ CoName.value +"&StYr="+ FinStart.value +"&EndYr="+ FinEnd.value +"&Market=" + Market.value + "&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromDate=" +From_Date.value +"&ToDate=" +To_Date.value +"&Object=FromClient&helpfor=Accountcode" ,"HelpWindow", "width= 700 , height= 525 , scrollbar = no, top=0, left=0 menubar=no, titlebar=no, toolbar=no, status=no, resizeable=no" );		
		}
	}
}

/* ********************************************
	FUNCTION FOR OPENING HELP POPUP WINDOW.
******************************************** */
function OpenWindowForScrip( form, par, Type, InputType )
{
	with( ReportForm )
	{
		HelpWindow = open( "/Client/HelpSearch/TradingClients.cfm?COCD=" +COCD.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&ClientList=" +FromClient.value +"&Type=" +Type +"&InputType=" + InputType +"&helpfor=" +par +"&title=Report - " +ReportName.value, "HelpWindow", "width=700, height=525, scrollbar=no, top=0, left=0, menubar=no, titlebar=no, toolbar=no, status=no, resizeable=no" );
	}
}

/* ********************************************
	FUNCTION FOR OPENING HELP POPUP WINDOW.
******************************************** */
function OpenSingleWindow( form, par )
{
	with( ReportForm )
	{
		if( par == "Client" )
		{
			try
			{
				HelpWindow	=	open( "/Client/HelpSearch/SingleChoice.cfm?Client=&COCD="+ COCD.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&helpfor=" +par +"&FormObj=" +name +"&ClObj=" +FromClient.name +"&title=Report - " +ReportName.value, "HelpWindow", "width=700, height=525, scrollbar=no, top=0, left=0, menubar=no, titlebar=no, toolbar=no, status=no, resizeable=no" );
			}
			catch( e )
			{ 
				HelpWindow	=	open( "/Client/HelpSearch/SingleChoice.cfm?COCD="+ COCD.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&helpfor=" +par +"&FormObj=" +name +"&ClObj=" +FromClient.name +"&title=Report - " +ReportName.value, "HelpWindow", "width=700, height=525, scrollbar=no, top=0, left=0, menubar=no, titlebar=no, toolbar=no, status=no, resizeable=no" );
			}
		} 
	}
}

//HelpWindow = open ( "/Client/IO_FOCAPS/HelpSearch/ScripsHelp.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStYr=" +FinStYr.value +"&FinEndYr=" +FinEndYr.value +"&MktType=" +MktType.value +"&SetlNo=" +SetlNo.value +"&ClientList=" +ClientList.value +"&Object=" +Obj +"&FormName=ReportParameters&HelpFor=Scrip", "ScripListHelpPopupWindow", "top=50, left=50, width=700, height=450" );
