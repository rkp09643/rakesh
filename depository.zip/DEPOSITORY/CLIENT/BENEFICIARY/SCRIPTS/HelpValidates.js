/* ####################################################################################
					JAVASCRIPT FILE FOR CLIENT-ID HELP POPUP WINDOW.
#################################################################################### */

function ReturnValues( form, helpObject, helpObjectName, helpFormName, objType, appendReplace )
{
	with( form )
	{
		var HelpObject = eval( 'window.opener.document.forms[ "' +helpFormName +'" ].' +helpObject );
		
		if( objType == "Radio")
		{
			HelpObject.value = "";
		}
		if( appendReplace == "Replace" )
		{
			HelpObject.value = "";
		}
		/*
		if( helpObjectName != "" )
		{
			var HelpObjectName = eval( 'window.opener.document.forms[ "' +helpFormName +'" ].' +helpObjectName );
			
			if( objType == "Radio")
			{
				HelpObjectName.value = "";
			}
			
			if( appendReplace == "Replace" )
			{
				HelpObjectName.value = "";
			}
		}
		*/
		for( i = 0; i < SelectedValues.length; i++ )
		{
			if( HelpObject.value.length == 0 )
			{
				HelpObject.value = SelectedValues[i].value;
			}
			else
			{
				HelpObject.value = HelpObject.value +"," +SelectedValues[i].value;
			}
		}
		
		if ( helpObject != "Client_DPCode" )
		{
			HelpObject.focus();
		}
				
		eval( 'window.opener.document.forms[ "' +helpFormName +'" ].focus()' );
		window.close();
	}
}


/* ********************************************************
	FUNCTION FOR SELECTING A VALUE FROM CLIENT-ID LIST.
******************************************************** */
function CheckOneByOne( form, selectedObjValues, objType, objName )
{
	var x	=	-1;
	
	with( form )
	{
		if( objType == "Radio")
		{
			SelectedValues.length = 0;
		}
		
		objName = eval( "elements." +objName  );
		
		if( selectedObjValues == "All" )
		{
			SelectedValues.length = 0;
			
			if( SelectAll.checked )
			{
				for( i = 0; i < objName.length; i++ )
				{
					objName[ i ].checked = true;
					SelectedValues[ SelectedValues.length ] = new Option( objName[i].value, objName[i].value );
				}
			}
			else
			{
				for( i = 0; i < objName.length; i++ )
				{
					objName[i].checked = false;
				}
			}
		}
		else
		{
			for( i = 0; i < SelectedValues.length; i++ )
			{
				if( SelectedValues[i].value == selectedObjValues )
				{
					x = i;
				}
			}
			
			if( x == -1 )
			{
				SelectedValues[ SelectedValues.length ] = new Option( selectedObjValues, selectedObjValues );
			}
			else
			{
				try
				{
					SelectedValues[ x ] = SelectedValues[ x + 1 ];
				}
				catch( e ) { return e; }
			}
		}
		
	}
}
