//USED IN MISSINGISIN.CFM FOR VALIDATING SCRIP CODE.
function scripCodeValidation( form, ScripCode, objScripCode, objScripName, Checked )
{
	with( form )
	{
		eval( objScripName ).value = "";
		
		if( ( ScripCode.length > 0 ) || ( ScripCode.charAt(0) == " " ) )
		{	
			parent.HideAndShow.location.href = "/Client/DynamicFrame/Fra_Hide.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStYr=" +FinStYr.value +"&FinEndYr=" +FinEndYr.value +"&MissingValidation=ISIN" +"&ScripCode=" +ScripCode +"&objScripCode=" +objScripCode +"&objScripName=" +objScripName +"&Checked=" +Checked;
		}
		if( ( eval( objScripName ).value == "" && Checked == "True" ) )
		{
	 		alert( "Please enter a valid 'Scrip-Code'" );
			eval( objScripName ).value = "";
			eval( objScripCode ).value = "";
			eval( objScripCode ).focus();
		}	
	}
}


//USED IN MISSINGCLIENTDPCODE.CFM FOR VALIDATING CLIENT ID .
function clientIDValidation( form, ClientCode, objClientCode, objClientName, Checked )
{
	with( form )
	{
		eval( objClientName ).value = "";
		
		if( ( ClientCode.length > 0 ) || ( ClientCode.charAt(0) == " " ) )
		{
			parent.HideAndShow.location.href = "/Client/DynamicFrame/Fra_Hide.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStYr=" +FinStYr.value +"&FinEndYr=" +FinEndYr.value +"&MissingValidation=ClientDPCode" +"&ClientID=" +ClientCode +"&objClientCode=" +objClientCode +"&objClientName=" +objClientName +"&Checked=" +Checked;
		}
		if( eval( objClientName ).value == "" && Checked == "True" )
		{
	 		alert( "Please enter a valid 'Client-ID'" );
			eval( objClientName ).value = "";
			eval( objClientCode ).value = "";
			eval( objClientCode ).focus();
		}	
	}
}


//USED IN MISSINGISIN.CFM FOR VALIDATING SCRIP CODE IS BLANK OR NOT IF CHECKBOX IS SELECTED.
function checkForISIN( form )
{
	var checkedCount = 0;
	
	with( form )
	{
		var ScripCode, ScripName;
		
		for( i = 1; i <= Records.value; i++ )
		{
			ScripCode = eval( "ScripCode" +i );
			ScripName = eval( "ScripName" +i );
			
			if( eval( "Isin" +i +".checked" ) )
			{
				checkedCount = ( checkedCount + 1 );
				//scripCodeValidation ( form, ScripCode.value, ScripCode, ScripName, "True" );
				
				if( ScripCode.value == "" )
				{
					alert( "Please enter a valid 'Scrip-Code'" );
					ScripCode.focus();
					return false;
				}
			}
		}
		
		if( checkedCount > 0 )
		{
			UpdateData.value = "Update";
			submit();
		}
		else
		{
			alert( "Please select an 'ISIN' to Update." );
		}	
	}	
}


//USED IN MISSINGCLIENTDPCODE.CFM FOR VALIDATING CLIENTID IS BLANK OR NOT IF CHECKBOX IS SELECTED.
function checkForClientID( form )
{
	var checkedCount = 0;
	
	with( form )
	{
		var ClientCode, ClientName, ClientDPName, DPName;
		
		for ( i = 1; i <= Records.value; i++ )
		{				 
			ClientCode		= eval( "ClientID" +i );
			ClientName		= eval( "ClientName" +i );
			ClientDPName	= eval( "ClientDPName" +i );
			DPName			= eval( "DPName" +i );
			
			if( eval( "ClientDP" +i +".checked" ) )
			{
				checkedCount = checkedCount + 1;
				
				if( ( ClientCode.value == "" ) || ( ClientCode.value.charAt(0) == " " ) )
				{
			 		alert( "Please enter a valid 'Client-ID'" );
					ClientCode.focus();
					return false;
				}
			}
		}
		
		if( checkedCount > 0 )
		{
			InsertData.value = "Insert";
			submit();
		}
		else
		{
			alert( "Please select a 'Client-DP-Code' to Add." );
		}	
	}	
}


//USED IN MISSINGCLIENTDPCODE.CFM AND MISSINGISIN.CFM FOR SELECTING ALL CHECKBOX.
function selectAll( form, Type )
{
	with( form )
	{
		for( i = 1; i <= Records.value; i++ )
		{	
			if( Type == "ISIN" )
			{
	 			if( AllIsin.checked )
				{
					eval( "Isin" +i +".checked = true" );
				}
				else
				{
					eval( "Isin" +i +".checked = false" );
				}	
			}
			if( Type == "ClientDP" )
			{
	 			if( AllClientDP.checked )
				{
					eval( "ClientDP" +i +".checked = true" );
				}
				else
				{
					eval( "ClientDP" +i +".checked = false" );
				}	
			}
		}
	}
}


//USED IN MISSINGISIN.CFM FOR GETTING MISSING-ISIN-DETAILS POP-UP.
function getDetails( form, openFor, objVal1, objVal2, objVal3, transType )
{
	with( form )
	{
		var transPath = "/Client/IO_FOCAPS/Transactions/";
		var reportPath = "/Client/IO_FOCAPS/Reports/";
		var commonParams = "&COCD=" +escape( COCD.value ) +"&CoName=" +escape( CoName.value ) +"&CoGroup=" +escape( CoGroup.value ) +"&Market=" +escape( Market.value ) +"&Exchange=" +escape( Exchange.value ) +"&Broker=" +escape( Broker.value ) +"&FinStYr=" +escape( FinStYr.value ) +"&FinEndYr=" +escape( FinEndYr.value ) +"&Client=" +escape( Client.value );
		
		if( openFor == "ISIN" )
		{
			var templateName = "MissingTransDetails.cfm?GetDetailFor=" +openFor +"&ISIN=" +objVal1;
		}
		else if( openFor == "ClientDPDetail" )
		{
			var templateName = "MissingTransDetails.cfm?GetDetailFor=" +openFor +"&ClientDPCode=" +objVal1 +"&DPID=" +objVal2;
		}
		else if( ( openFor == "Scrip" ) || ( openFor == "Client" ) )
		{
			if( openFor == "Scrip" )
			{
				var ClientList = "";
				var ScripList = escape( objVal3 );
				var IOType = "ClientWise";
			}
			else if( openFor == "Client" )
			{
				var ClientList = escape( objVal3 );
				var ScripList = "";
				var IOType = "ScripWise";
			}
			
			if( transType == "R" )
			{
				var templateName = "InwardStockSummary.cfm?GetDetailFor=" +openFor +"&MktType=" +objVal1 +"&SetlNo=" +objVal2 +"&ClientList=" +ClientList +"&ScripList=" +ScripList +"&InwardType=" +IOType +"&FlgInterSettlement=N&FlgExcessQty=N&FlgShortQty=N";
			}
			else if( transType == "D" )
			{
				var templateName = "OutwardStockSummary.cfm?GetDetailFor=" +openFor +"&MktType=" +objVal1 +"&SetlNo=" +objVal2 +"&ClientList=" +ClientList +"&ScripList=" +ScripList +"&OutwardType=" +IOType +"&FlgInterSettlement=N&FlgExcessQty=N&FlgShortQty=N";
			}
		}
		
		if( ( openFor == "ISIN" ) || ( openFor == "ClientDPDetail" ) )
		{
			window.open( transPath +templateName +commonParams, "MissingTransDetailPopUp", "Top = 20, Left = 0, Width = 800, Height = 150" );
		}
		else
		{
			window.open( reportPath +templateName +commonParams, "MissingClientScripDetailPopUp", "Top = 200, Left = 0, Width = 800, Height = 330" );
		}
		//window.showModalDialog( "/Client/IO_FOCAPS/Transactions/" +templateName +commonParams, "Top = 20, Left = 0, Width = 800, Height = 150" );
		//window.showModelessDialog( "/Client/IO_FOCAPS/Transactions/" +templateName +commonParams, "Top = 20, Left = 0, Width = 800, Height = 150" );
	}
}