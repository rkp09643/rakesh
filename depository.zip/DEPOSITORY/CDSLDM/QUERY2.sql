USE CDSLDP_DM

DELETE BO_LIST

INSERT INTO BO_LIST
select DISTINCT b.BO_ID from onmarket a,missingonm b
where 
a.bo_id = b.bo_id
and a.buysell_flg = b.buysell
and a.isin = b.isin
and a.settl_dt = b.settl_dt
and a.settl_id = b.settlement_id
AND Month(A.Settl_DT) = 4
and a.quantity != cast(replace(B.quantity,',','') as numeric(9,0))
and CHARINDEX(',',b.quantity) <> 0
and buysell = 'S'
and right(b.bo_id,4) not in ('0568','7808')
order by b.bo_id

SELECT	A.*
INTO
 	ONMARKET_2104
FROM
	OnMarket A, MissingOnm B
Where	
	A.BO_ID			=	B.BO_ID
AND 	A.BUYSELL_FLG 		= 	B.BUYSELL
AND 	A.ISIN 			=	B.ISIN
AND 	A.SETTL_DT 		= 	B.SETTL_DT
AND 	A.SETTL_ID 		= 	B.SETTLEMENT_ID
AND 	MONTH(A.SETTL_DT) 	= 	4
AND 	A.QUANTITY 		!= 	CAST(REPLACE(B.QUANTITY,',','') AS NUMERIC(9,0))
AND 	CHARINDEX(',',B.QUANTITY)<> 	0


UPDATE ONMARKET
SET
	quantity = cast(replace(B.quantity,',','') as numeric(9,0))
FROM
	OnMarket A, MissingOnm B
Where	
	A.BO_ID			=	B.BO_ID
AND 	A.BUYSELL_FLG 		= 	B.BUYSELL
AND 	A.ISIN 			=	B.ISIN
AND 	A.SETTL_DT 		= 	B.SETTL_DT
AND 	A.SETTL_ID 		= 	B.SETTLEMENT_ID
AND 	MONTH(A.SETTL_DT) 	= 	4
AND	A.CTR_BO_ID		IS 	NULL
AND 	A.QUANTITY 		!= 	CAST(REPLACE(B.QUANTITY,',','') AS NUMERIC(9,0))
AND 	CHARINDEX(',',B.QUANTITY)<> 	0
