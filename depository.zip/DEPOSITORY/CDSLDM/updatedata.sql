delete fa_transactions

update fa_accountsubtype 
set dr_amt = 0,
cr_amt = 0,
openingbalance = 0,
openingbalancetype = 'Dr',
closingbalance = 0,
closingbalancetype = 'Dr'

update fa_subledger 
set dr_amt = 0,
cr_amt = 0,
openingbalance = 0,
openingbalancetype = 'Dr',
closingbalance = 0,
closingbalancetype = 'Dr'