select * from onmarket
where month(settl_dt) = 4

delete billno where billdate1 = '2004-04-01'
update onmarket set billno = 0 where month(settl_dt)=4 and year(settl_dt) = 2004 and billno <> '0'
update interdp set billno = 0 where month(settl_dt)=4 and year(settl_dt) = 2004 and billno <> '0'
update offmarket set billno = 0 where month(settl_dt)=4 and year(settl_dt) = 2004 and billno <> '0'
update demat set billno = 0 where month(de_setup_date)=4 and year(de_setup_date) = 2004 and billno <> '0'