select  distinct groupcode, count(bo_id) As GroupCount
from billno where billdate1 = '2004-04-01'
group by groupcode
order by groupcode