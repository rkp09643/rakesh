SET QUOTED_IDENTIFIER ON 
GO
SET ANSI_NULLS OFF 
GO





ALTER    Procedure HoldingUpload as


DELETE 	TEMP_SOH_FILE

exec master.dbo.xp_cmdshell 'dtsrun /F C:\DSNTextFiles\DTSPackage\Holding.DTS', no_output

DELETE	TempSOH

Declare	@DP_ID		AS VARCHAR(20),
	@BO_ID		AS VARCHAR(20),
	@From_Date	As DateTime,
	@To_Date	As DateTime,
	@Demat_Isin	AS VARCHAR(30),
	@PENDING_DEMAT	AS Numeric(9),
	@All_Bo_Id	As VARCHAR(4000),
	@All_Demat_Isin	As VARCHAR(4000)

Declare	@IDENTIFIER	AS VARCHAR(5),
	@DP_Isin	AS VARCHAR(30),
	@BO_SCRIP	AS VARCHAR(100),
	@DT_CUR_QTY	AS VARCHAR(20),
	@DT_FROZ_QTY	AS VARCHAR(20),
	@PLEDGED_QTY	AS VARCHAR(20),
	@FREE_QTY	AS VARCHAR(20),
	@LockedIn_QTY	AS VARCHAR(20),
	@EARMARKED_QTY	AS VARCHAR(20)

Set	@Pending_Demat	=	0

Declare @Demat TABLE
(
	BO_ID	VARCHAR(20),
	ISIN	VARCHAR(20),
	ISIN_NAME VARCHAR(100),
	DEMAT_QTY NUMERIC(30)
)

Declare SOH_DATA Cursor For	
		Select	IDENTIFIER, DP_Isin, BO_SCRIP, DT_CUR_QTY, DT_FROZ_QTY, 
		 	Pledged_Qty, Free_Qty, LockedIn_Qty, Earmarked_Qty
		From
			TEMP_SOH_FILE
		Where
			IDENTIFIER	In	('01','06','07')
		Order By RowNo
			
Open SOH_DATA
Fetch next from SOH_DATA Into	@IDENTIFIER, @DP_Isin, @BO_SCRIP, @DT_CUR_QTY, @DT_FROZ_QTY, 
			 	@Pledged_Qty, @Free_Qty, @LockedIn_Qty, @Earmarked_Qty

	WHILE @@FETCH_STATUS = 0
	BEGIN

		IF @IDENTIFIER = '01' 
		BEGIN
			SET	@DP_ID		=	@DP_Isin
			SET	@BO_ID		=	@BO_SCRIP
			SET	@FROM_DATE	=	CONVERT(DATETIME, @DT_CUR_QTY, 103)
			SET	@TO_DATE	=	CONVERT(DATETIME, @DT_FROZ_QTY, 103)
		END
	
		IF @IDENTIFIER = '02' 
		BEGIN
			SET	@Demat_Isin	=	@DP_Isin
			INSERT INTO @DEMAT
			VALUES
			(@BO_ID, @DP_Isin, @DP_Isin, Cast(@DT_Froz_Qty As Numeric(30)))
		END
		
	
		IF @IDENTIFIER = '06' 
		BEGIN
			--SET	@All_Bo_Id	=	@All_Bo_Id + ',' + @BO_ID
			--SET	@All_Demat_Isin	=	@All_Demat_Isin + ',' + @Demat_Isin
			SET	@Pending_Demat	=	@Pending_Demat + Cast(@DT_Froz_Qty As Numeric(9))
			UPDATE @DEMAT
			SET DEMAT_QTY = DEMAT_QTY +   Cast(@DT_Froz_Qty As Numeric(30))
			WHERE
			
		END

		IF @IDENTIFIER = '07' 
		BEGIN
			INSERT INTO TempSOH
				(DP_ID,BO_ID,FRM_DT,TO_DT,Isin,Isin_DESC,CURBALQTY,
			 	 FROZBALQTY,PLBALQTY, FREEBALQTY, LKBALQTY, EARMBALQTY)
			VALUES
				(
				 @DP_ID, @BO_ID, @FROM_DATE, @TO_DATE, @DP_ISIN, @BO_Scrip, @Dt_Cur_Qty, 
				 @Dt_Froz_Qty, @Pledged_Qty, @Free_Qty, @LockedIn_Qty, @Earmarked_Qty 
				)

			Set	@Pending_Demat	=	0
		End	
			

		Fetch next from SOH_DATA Into	@IDENTIFIER, @DP_Isin, @BO_SCRIP, @DT_CUR_QTY, @DT_FROZ_QTY, 
					 	@Pledged_Qty, @Free_Qty, @LockedIn_Qty, @Earmarked_Qty
	END

Close		SOH_DATA
DeAllocate 	SOH_DATA

SELECT BO_ID, ISIN, Sum(DEMAT_QTY)demat
INTO
	#DEMAT
FROM
	@DEMAT
group by
	BO_ID, ISIN

UPDATE	 TEMPSOH
SET
	PendingDemat	=	demat
from
	tempsoh a, #demat b
where
	a.bo_id = b.bo_id
and	a.isin = b.isin

Delete	SOH

Insert Soh 
		(DP_Id, Bo_Id, Frm_DT, To_DT, ISIN, ISIN_Desc, CurBalQty, FrozBalQty, PlBalQty, FreeBalQty, LkBalQty, EarmBalQty, PendingDemat)
SELECT 
		DP_Id, Bo_Id, Frm_DT, To_DT, ISIN, ISIN_Desc, CurBalQty, FrozBalQty, PlBalQty, FreeBalQty, LkBalQty, EarmBalQty, PendingDemat 
FROM TempSOH




GO
SET QUOTED_IDENTIFIER OFF 
GO
SET ANSI_NULLS ON 
GO

