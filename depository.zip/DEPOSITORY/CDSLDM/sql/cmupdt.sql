update clientmaster
set trading_client_id = ''
where 
trading_client_id is null