SELECT  Bo_id, BillNo, sum(Fee) Total, sndr_txn_ref_no TransNo,
		(sum(Fee) * Service_Tax) / 100 As Service_Tax
	FROM         interdp, Service_Tax_Master
where   --BillNo > '0' 
	Month(settl_dt) = Month(Period)
	and	Year(settl_dt) = Year(Period)
	and 	bo_id = '1201320000000568'
-- 	and 	settl_dt >= '2003-10-01'
-- 	and 	settl_dt <= '2004-10-30'
	group by Bo_id, BillNo, sndr_txn_ref_no, Service_Tax
	
	UNION ALL

	SELECT  Bo_id, BillNo, sum(Fee) Total, Cast(txn_id as VarChar(50)) TransNo,
		(sum(Fee) * Service_Tax) / 100 As Service_Tax
	FROM         offmarket, Service_Tax_Master
	where   BillNo > '0' 
	and	Month(settl_dt) = Month(Period)
	and	Year(settl_dt) = Year(Period)
	and 	bo_id = '1201320000000568'
	and 	settl_dt >= '2003-10-01'
	and 	settl_dt <= '2004-10-30'
	group by Bo_id, BillNo,txn_id, Service_Tax
	
	UNION ALL

	SELECT  Bo_id, BillNo, sum(Fee) Total,Txn_id TransNo,
		(sum(Fee) * Service_Tax) / 100 As Service_Tax
	FROM    onmarket, Service_Tax_Master
	where   BillNo > '0' 
	and	Month(settl_dt) = Month(Period)
	and	Year(settl_dt) = Year(Period)
	and 	bo_id = '1201320000000568'
	and 	settl_dt >= '2003-10-01'
	and 	settl_dt <= '2004-10-30'
	group by Bo_id, BillNo, Txn_id, Service_Tax
