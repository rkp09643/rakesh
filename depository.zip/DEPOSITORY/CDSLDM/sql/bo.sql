select * from vikas

select * from clientmaster
where trading_client_id is null
and bo_acct_status != 'CLOSED'

select a.* from clientmaster a
--set trading_client_id = clientcode
--From 
,vikas b
where a.bo_id = b.boid
and trading_client_id is null