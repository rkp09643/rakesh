var gdCtrl = new Object();
var gcGray = "inactivecaption";
var gcToggle = "buttonface";
var gcBG = "window";
var oDatePopup = window.createPopup();
var gMonths = new Array("January","February","March","April","May","June","July","August","September","October","November","December");

var giYear;
var giMonth;
var giDay;
fSetCurDate(new Date());


//To set current date of the Calendar
function fSetCurDate(dt)
{
	giYear = dt.getFullYear();
	giMonth = dt.getMonth()+1;
	giDay = dt.getDate();
}

//To format the date as it will be returned to the text box
function fSetDate(iYear, iMonth, iDay)
{
	var cMonth;
	if (iDay == 1 || iDay == 2 || iDay == 3 || iDay == 4 || iDay == 5 || iDay == 6 || iDay == 7 || iDay == 8 || iDay == 9)
	  iDay = '0'+iDay;
	
	cMonth = iMonth;
	if (iMonth == 1 || iMonth == 2 || iMonth == 3 || iMonth == 4 || iMonth == 5 || iMonth == 6 || iMonth == 7 || iMonth == 8 || iMonth == 9)
	  cMonth = '0'+iMonth;
	
	/*switch(iMonth)
	{
		case 1: cMonth="Jan"; break;
		case 2: cMonth="Feb"; break;
		case 3: cMonth="Mar"; break;
		case 4: cMonth="Apr"; break;
		case 5: cMonth="May"; break;
		case 6: cMonth="Jun"; break;
		case 7: cMonth="Jul"; break;
		case 8: cMonth="Aug"; break;
		case 9: cMonth="Sep"; break;
		case 10: cMonth="Oct"; break;
		case 11: cMonth="Nov"; break;
		case 12: cMonth="Dec";
	}*/
	return(iDay+"/" + cMonth + "/"+iYear);
}

//To set the currently selected date of the calendar in the text box
function fSetSelected(aCell,idx)
{
	var iOffset = 0;
	var iYear = parseInt(tbSelYear.value);
	var iMonth = parseInt(tbSelMonth.value);

	aCell.bgColor = gcBG;
	oDatePopup.hide();

	with (aCell)
	{
		var iDay = parseInt(innerText);
		if (style.color==gcGray)
			iOffset = (idx<7)?-1:1;
		iMonth += iOffset;
		if (iMonth<1) {
			iYear--;
			iMonth = 12;
		}
		else if (iMonth>12)
		{
			iYear++;
			iMonth = 1;
		}
	}
	gdCtrl.value = fSetDate(iYear, iMonth, iDay);
	gdCtrl.focus();
}

//Point class
function Point(iX, iY)
{
	this.x = iX;
	this.y = iY;
}

//To set a 2D array based on Year and Month
function fBuildCal(iYear, iMonth) 
{
	var aMonth=new Array();
	for(i=1;i<7;i++)
		aMonth[i]=new Array(i);

	var dCalDate=new Date(iYear, iMonth-1, 1);
	var iDayOfFirst=dCalDate.getDay();
	var iDaysInMonth=new Date(iYear, iMonth, 0).getDate();
	var iOffsetLast=new Date(iYear, iMonth-1, 0).getDate()-iDayOfFirst+1;
	var iDate = 1;
	var iNext = 1;

	for (d = 0; d < 7; d++)
		aMonth[1][d] = (d<iDayOfFirst)?-(iOffsetLast+d):iDate++;

	for (w = 2; w < 7; w++)
		for (d = 0; d < 7; d++)
			aMonth[w][d] = (iDate<=iDaysInMonth)?iDate++:-(iNext++);
	return aMonth;
}

//To darw the inner table for all the dates
function fDrawCal(iYear, iMonth, iCellHeight, sDateTextSize) 
{
	var WeekDay = new Array("S","M","T","W","T","F","S");
	var styleTD1 = " bgcolor='"+gcBG+"' bordercolor='"+gcBG+"' valign='middle' align='center' style='font:bold 8pt Tahoma;";
	var styleTD2 = " bgcolor='"+gcBG+"' bordercolor='"+gcBG+"' valign='middle' align='center' style='font:8pt Tahoma;";           

	with (oDatePopup.document) 
	{
		write("<tr>");
		for(i=0; i<7; i++)
			write("<td "+styleTD1+"color:buttontext' >" + WeekDay[i] + "</td>");
		write("</tr>");

		for (w = 1; w < 7; w++) {
			write("<tr>");
			for (d = 0; d < 7; d++)
				write("<td id=calCell "+styleTD2+"cursor:hand;' onMouseOver='this.bgColor=parent.gcToggle' onMouseOut='this.bgColor=parent.gcBG' onclick='parent.fSetSelected(this,"+ ((w-1)*7+d+1) +")'></TD>");
			write("</tr>");
		}
	}
}

//To update date values calculated using fBuildCal
function fUpdateCal(iYear, iMonth) 
{
	myMonth = fBuildCal(iYear, iMonth);
	var i = 0;
	for (w = 0; w < 6; w++)
		for (d = 0; d < 7; d++)
	  		with (oDatePopup.document.all("calCell")[(7*w)+d]) 
	  		{
	  			style.borderStyle='solid';
	  			if (myMonth[w+1][d]<0) 
	  			{
	  				style.color = gcGray;
	  				innerText = -myMonth[w+1][d];
	  				style.borderColor = gcBG;
	  			}
	  			else 
	  			{
	  				if(myMonth[w+1][d] == giDay && iMonth == giMonth && iYear == giYear) style.borderColor = "red";
	  				else style.borderColor = gcBG;
	  				style.color = ((d==0)||(d==6))?"red":"buttontext";
	  				innerText = myMonth[w+1][d];
	  			}
	  		}
}

//To set the current year and month
function fSetYearMon(iYear, iMon)
{
	tbSelMonth.options[iMon-1].selected = true;
	for (i = 0; i < tbSelYear.length; i++)
		if (tbSelYear.options[i].value == iYear)
			tbSelYear.options[i].selected = true;
	fUpdateCal(iYear, iMon);
}

//To set the previous month (with validation for current month as first month and others)
function fPrevMonth()
{
	var iMon = tbSelMonth.value;
	var iYear = tbSelYear.value;

	if(iMon==1 && iYear==tbSelYear.options[0].value) return;

	if (--iMon<1) 
	{
		iMon = 12;
		iYear--;
	}

	fSetYearMon(iYear, iMon);
}

//To set the next month (with validation for current month as last month)
function fNextMonth()
{
	var iMon = tbSelMonth.value;
	var iYear = tbSelYear.value;

	if (++iMon>12) 
	{
		iMon = 1;
		iYear++;
	}

	fSetYearMon(iYear, iMon);
}

//To get the XY location of the object where the calendar will be displayed
function fGetXY(aTag)
{
	var oTmp = aTag;
	var pt = new Point(0,0);
	do 
	{
		pt.x += oTmp.offsetLeft;
		pt.y += oTmp.offsetTop;
		oTmp = oTmp.offsetParent;
	} while(oTmp.tagName!="BODY");
	return pt;
}

// Main: popCtrl is the widget beyond which you want this calendar to appear;
//       dateCtrl is the widget into which you want to put the selected date.
// i.e.: <input type="text" name="dc" readonly><INPUT type="button" value="V" onclick="fPopCalendar(dc,dc);return false">
function fPopCalendar(popCtrl, dateCtrl)
{
	gdCtrl = dateCtrl;
	var sDt, mth;
	sDt = dateCtrl.value;
	if (sDt.length==10)
	{
		switch(sDt.substr(3,2))
		{
			case "01": mth="Jan"; break;
			case "02": mth="Feb"; break;
			case "03": mth="Mar"; break;
			case "04": mth="Apr"; break;
			case "05": mth="May"; break;
			case "06": mth="Jun"; break;
			case "07": mth="Jul"; break;
			case "08": mth="Aug"; break;
			case "09": mth="Sep"; break;
			case "10": mth="Oct"; break;
			case "11": mth="Nov"; break;
			case "12": mth="Dec";
		}

		sDt = mth + " " + sDt.substr(0,2) + "," + sDt.substr(6,4)
		fSetCurDate(new Date(sDt));
	}
	fSetYearMon(giYear, giMonth);
	var point = fGetXY(popCtrl);
	var l = point.x+2;
	var t  = point.y+popCtrl.offsetHeight+3;
	oDatePopup.show(l, t, 153, 182, document.body);
}

with (oDatePopup.document) 
{
	write("<BODY leftmargin=0 topmargin=0 scroll=no>")
	write("<table border='1' bgcolor='buttonface' cellpadding=0 cellspacing=0>");
	write("<TR height=25>");
	write("<td valign='middle' align='center'>");
	write("<select id='tbSelMonth' name='tbSelMonth' style='font:8pt;' onChange='parent.fUpdateCal(tbSelYear.value, tbSelMonth.value)'>");
	for (i=0; i<12; i++)
		write("<option value='"+(i+1)+"'>"+gMonths[i]+"</option>");
	write("</SELECT>");
	write("&nbsp;<SELECT id='tbSelYear' name='tbSelYear' style='font:8pt;' onChange='parent.fUpdateCal(tbSelYear.value, tbSelMonth.value)'>");
	for(i=2001;i<2051;i++)
		write("<OPTION value='"+i+"'>"+i+"</OPTION>");
	write("</SELECT>");
	write("</td>");
	write("</TR>");
	write("<TR height=20><TD align=center valign=middle style='color:buttontext;font:bold 9pt Tahoma;'>");
	write("<SPAN style='cursor:hand;' onclick='if(tbSelYear.value > tbSelYear.options[0].value) parent.fSetYearMon(parseInt(tbSelYear.value) - 1, tbSelMonth.value);'><A style='color:buttontext;font:bold 9pt Tahoma;text-decoration:none' href='#'>&lt;&lt;</A></SPAN>&nbsp;&nbsp;&nbsp;");
	write("<SPAN style='cursor:hand;' onclick='parent.fPrevMonth();'><A style='color:buttontext;font:bold 9pt Tahoma;text-decoration:none' href='#'>&lt;</A></SPAN>&nbsp;&nbsp;&nbsp;");
	write("<SPAN onclick='parent.fSetCurDate(new Date()); parent.fSetYearMon(parent.giYear, parent.giMonth);'><A style='color:buttontext;font:bold 9pt Tahoma;text-decoration:none' href='#'>Today</A></SPAN>&nbsp;&nbsp;&nbsp;");
	write("<SPAN style='cursor:hand;' onclick='parent.fNextMonth();'><A style='color:buttontext;font:bold 9pt Tahoma;text-decoration:none' href='#'>&gt;</A></SPAN>&nbsp;&nbsp;&nbsp;");
	write("<SPAN style='cursor:hand;' onclick='parent.fSetYearMon(parseInt(tbSelYear.value) + 1, tbSelMonth.value)'><A style='color:buttontext;font:bold 9pt Tahoma;text-decoration:none' href='#'>&gt;&gt;</A></SPAN>");
	write("</TR>");
	write("<TR><td align='center'>");
	write("<table width='100%' border='1' cellspacing=1 style='background-color:"+gcBG+"'>");
	fDrawCal(giYear, giMonth, 10, '8');
	write("</table>");
	write("</td>");
	write("</TR>");
	write("</TABLE>");
}
var tbSelMonth = oDatePopup.document.all("tbSelMonth");
var tbSelYear = oDatePopup.document.all("tbSelYear");
