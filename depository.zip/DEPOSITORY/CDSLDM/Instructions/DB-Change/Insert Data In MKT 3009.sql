USE CDSLDP_DM

Insert into Market_Type_Master
Values
('BSE','RM','RM','RM')