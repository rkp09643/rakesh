declare @fee numeric(20 , 2)
declare @Billfee numeric(20 , 2)
declare @Serv numeric(20 , 2)
declare @ServAmt numeric(20 , 2)
declare @ServTax numeric(20 , 2)
declare @Actfee numeric(20 , 2)
declare @Rndfee numeric(20 , 2)
declare @RndTotal numeric(20 , 2)
declare @TOTAL numeric(20 , 2)
declare @RndAmount numeric(20 , 2)
declare @VoucherNo numeric(20)

declare @cocd varchar(10)
declare @finstart Int
declare @finend int

set	@cocd = 'dm01'
set	@finstart = 2003
set	@finend = 2004

Set @Serv = 0

	Select 	@Serv = Service_Tax
	From	Service_Tax_Master
	Where	Period = @trdt

	SELECT  A.BO_ID, Isin, sum(fee) fee, Cast(Txn_id as VarChar(30)) TransNo, A.BillNo
	INTO 
		#BILLDATA
	FROM 
		OFFMARKET A, ClientMaster B
	WHERE 	
		A.BO_ID						= 	B.BO_ID
	And	Len(RTrim(IsNull(B.Trading_Client_ID, '')))	=	0
	And	Fee 						> 	0
	And 	SETTL_DT 	>= '2004-10-01'
	AND	SETTL_DT 	<= '2004-02-29'
	And 	A.Billno 					> 	'0'
	Group By	
		A.BO_ID, Isin, txn_id, A.BillNo

	UNION

	SELECT  A.BO_ID, Isin, sum(fee) fee, Txn_id TransNo, A.BillNo
	FROM 
		OnMarket A, ClientMaster B
	WHERE 	
		A.BO_ID						= 	B.BO_ID
	And	Len(RTrim(IsNull(B.Trading_Client_ID, '')))	=	0
	And	Fee 						> 	0 
	And 	SETTL_DT 	>= '2004-10-01'
	AND	SETTL_DT 	<= '2004-02-29'
	And 	A.Billno 					> 	'0'
	Group By 
		A.BO_ID, Isin, Txn_id, A.BillNo

	UNION

	SELECT  A.BO_ID, Isin, sum(fee) fee , sndr_txn_ref_no TransNo, A.BillNo
	FROM 
		InterDp A, ClientMaster B
	WHERE 	
		A.BO_ID						= 	B.BO_ID
	And	Len(RTrim(IsNull(B.Trading_Client_ID, '')))	=	0
	And	Fee 						> 	0 
	And 	SETTL_DT 	>= '2004-10-01'
	AND	SETTL_DT 	<= '2004-02-29'
	And 	A.Billno 					> 	'0'
	Group By 
		A.BO_ID, Isin, Sndr_Txn_Ref_No, A.BillNo

	UNION

	SELECT  A.BO_ID, Isin, sum(fee) fee, Txn_id TransNo, A.BillNo
	FROM 	
		Pledge A, ClientMaster B
	WHERE 	
		A.BO_ID						= 	B.BO_ID
	And	Len(RTrim(IsNull(B.Trading_Client_ID, '')))	=	0
	And	fee > 0 
	And 	TRANS_DATE 	>= '2004-10-01'
	AND	TRANS_DATE 	<= '2004-02-29'
	and 	A.Billno > '0'
	group by A.BO_ID, Isin, Txn_id, A.BillNo

	UNION

	SELECT  A.BO_ID, DE_ISIN Isin, sum(fees) fee, Cast(de_dr_numb as VarChar(30)) TransNo, A.BillNo
	FROM DEMAT A, ClientMaster B
	WHERE 	
		A.BO_ID						= 	B.BO_ID
	And	Len(RTrim(IsNull(B.Trading_Client_ID, '')))	=	0
	And	fees > 0 	
	And 	DE_SETUP_DATE 	>= '2004-10-01'
	AND	DE_SETUP_DATE 	<= '2004-02-29'
		and A.billno > '0'
	group by A.BO_ID, de_Isin, de_dr_numb, A.BillNo

	UNION

	SELECT  A.BO_ID, Isin, sum(fee) fee, Cast(txn_id as VarChar(30)) TransNo, A.BillNo
	FROM REMAT A, ClientMaster B
	WHERE 	
		A.BO_ID						= 	B.BO_ID
	And	Len(RTrim(IsNull(B.Trading_Client_ID, '')))	=	0
	And	fee > 0 	
	And 	TRANS_DATE	>= '2004-10-01'
	AND	TRANS_DATE	<= '2004-02-29'
	and 	A.billno > '0'
	group by A.BO_ID, Isin, txn_id, A.BillNo

	UNION

	select  A.Bo_id,'AMC' Isin, sum(amc_fee) fee , '1' TransNo, A.BillNo
	from amcmiscfeedata A, ClientMaster B
	WHERE 	
		A.BO_ID						= 	B.BO_ID
	And	Len(RTrim(IsNull(B.Trading_Client_ID, '')))	=	0
	And	IsNull(amc_fee, 0) > 0
		And ISNULL(A.BILLNO, '0') > '0'
	And 	NEXTAMCDUE	>= '2004-10-01'
	AND	NEXTAMCDUE	<= '2004-02-29'
	group by A.BO_ID, A.BillNo

	UNION ALL

	select  client_id as Bo_id,'MIS' Isin, sum(amount) fee , '2' TransNo, A.BillNo
	from Misselleneous A, ClientMaster B
	WHERE 	
		A.client_id						= 	B.BO_ID
	And	Len(RTrim(IsNull(B.Trading_Client_ID, '')))	=	0
	And	amount > 0
		and A.billno > '0'
	And 	AMC_date	>= '2004-10-01'
	AND	AMC_date	<= '2004-02-29'
	group by client_ID, A.BillNo


select 
	@Actfee = Round(sum(fee), 0) 
From 
	#BillData
	
Set 	@ServTax = @Actfee * @Serv/100

EXEC 	DELETE_OLD_TRANSACTIONS_FROM_FA @trdt, @COCD, @finstart

Select  Bo_ID, SUM(FEE) + (SUM(FEE) * @Serv /100)fee, BillNo
into 	#BillData1
From	#BillData
GROUP BY BO_ID, BillNo

Select  @fee = sum(Fee), @ServAmt = sum(Fee) * @Serv/100, 
	@RndFee = Sum(Fee) - @Actfee
from 	#BillData1

Set @VoucherNo = 1

-- INSERT CLIENT FEE
Insert into CAPSFO.dbo.FA_Transactions
	( cocd, AccountCode, Dr_amt, Cr_amt, VoucherDate, VoucherNo, FinStYr, FinEndYr,
	BillDate, BillNo, Trans_Type, Mkt_Type, Settlement_No, Narration)

Select  @cocd, A.Bo_ID, Fee, 0, @trdt, 'SJ'+cast(@VoucherNo as varchar(9) ),
	@finstart, @finend, @trdt, A.BillNo, 'SJ', 'DP', 0, 'JV Bill Entry For DP '+'-'+Replace(Convert(char(10), @trdt, 103), '/','')

From	#BillData1 a, ClientMaster B
Where	
	A.BO_ID = B.BO_ID
And	Len(RTrim(IsNull(B.Trading_Client_ID, '')))	=	0

Insert into CAPSFO.dbo.FA_Transactions
( cocd, AccountCode, Dr_amt, Cr_amt, VoucherDate, VoucherNo, FinStYr, FinEndYr,
  BillDate, BillNo, Trans_Type, Mkt_Type, Settlement_No, Narration)

Select distinct @cocd, 'FEES', 0, @Actfee, BillDate1, 'SJ'+cast(@VoucherNo as varchar(9) ),
	@finstart, @finend, BillDate1, 0, 'SJ', 'DP', CAST(Replace(Convert(varchar(10), BillDate1, 103), '/','') as numeric(10,0)) , 'JV Bill Entry For DP '+'-'+Replace(Convert(char(10), BillDate1, 103), '/','')
From	BillNo A, ClientMaster B
Where	
	A.BO_ID = B.BO_ID
And	Len(RTrim(IsNull(B.Trading_Client_ID, '')))	=	0
And 	BillDate1 >= '2004-10-01'
And 	BillDate1 <= '2004-02-29'
And	BillFlag = 'Y'

if @Serv > 0

begin

Insert into CAPSFO.dbo.FA_Transactions

( cocd, AccountCode, Dr_amt, Cr_amt, VoucherDate, VoucherNo, FinStYr, FinEndYr,
  BillDate, BillNo, Trans_Type, Mkt_Type, Settlement_No, Narration)

Select distinct @cocd, 'ServiceTax', 0, @ServTax, billDate1, 'SJ'+cast(@VoucherNo as varchar(9) ),
@finstart, @finend, BillDate1, 0, 'SJ', 'DP', CAST(Replace(Convert(varchar(10), BillDate1, 103), '/','') as numeric(10,0)) , 'JV Bill Entry For DP '+'-'+Replace(Convert(char(10), BillDate1, 103), '/','')
From	BillNo A, ClientMaster B
Where	
	A.BO_ID = B.BO_ID
And	Len(RTrim(IsNull(B.Trading_Client_ID, '')))	=	0
And 	BillDate1 >= '2004-10-01'
And 	BillDate1 <= '2004-02-29'
And	BillFlag = 'Y'