function setOnLoad( form )
{
	with( form )
	{
		BrokerCode.focus();
		hideShowHelpNotes( form, 'ALL' );
		/*if ( Market.value == "CAPS" )
		{
			CounterClientPOA.style.display = "None";
			CounterID.style.display = "None";
		}*/
	}
}


function resetDoc( form )
{
	with( form )
	{		
		reset();
		setOnLoad( form );
		
		if( typeof( layerResult ) != "undefined" )
		{
			layerResult.innerHTML		=	"";
		}
		else if( typeof( layerRaiseError ) != "undefined" )
		{
			layerRaiseError.innerHTML	=	"";
		}
	}
}


function validateForm( form )
{
	with( form )
	{
		for( i = 0; i < elements.length; i++ )
		{
			if( i > 8 && i < 23 )
			{
				obj			=	elements[i];
				objName		=	elements[i].name;
				objValue	=	elements[i].value;
				
				if( objValue == "" || objValue.charAt(0) == " " )
				{
					if( objName == "BrokerCode" )
					{
						alert( "Please enter a value for 'Broker Code'." );
					}
					else if( objName == "ClearingMemberCode" )
					{
						alert( "Please enter a value for 'Clearing Member Code'." );
					}
					else if( objName == "FTPIPAddress" )
					{
						alert( "Please enter a value for 'FTP IP-Address'." );
					}
					else if( objName == "StartingRowPoint" )
					{
						alert( "Please enter a value for 'Starting Row Point'." );
					}
					else if( objName == "ClientInterSettlement" )
					{
						alert( "Please enter a value for 'No. of Client Inter-Settled Settlments'." );
					}
					else if( objName == "PoolInterSettlement" )
					{
						alert( "Please enter a value for 'No. of Pool Inter-Settled Settlments'." );
					}
					
					if
					(
						objName == "BrokerCode" || objName == "ClearingMemberCode" || 
						objName == "FTPIPAddress" || objName == "StartingRowPoint" || 
						objName == "ClientInterSettlement" || objName == "PoolInterSettlement"
					)
					{
						obj.focus();
						return false;
					}

					/*if ( Market.value == "CAPS")
					{
						if ( PostingPOA[0].checked )
						{
							if ((! CClientPOA[0].checked ) & (! CClientPOA[1].checked ) & (! CClientPOA[2].checked))
							{
								alert("Please select Counter Client for POA");
								return false;
							}
							if ( POACounterID.value.length == 0 || POACounterID.value.charAt(0) == " " )
							{
								alert("Please Counter Client ID for POA");
								return false;
							}
						}
					}*/
				}
			}
		}
	}
}

function hideShowHelpNotes( form, obj )
{	
	with(form)	
	{		
		if( obj == "ALL" )
		{					
			objName										=	"";
			
			BrokerCodeHelp.style.display				=	"None";
			ClearingMemberCodeHelp.style.display		=	"None";
			DefaultClientIDHelp.style.display			=	"None";
			DefaultHairCutHelp.style.display			=	"None";
			FTPIPAddressHelp.style.display				=	"None";
			CmbContFieldHelp.style.display				=	"None";
			CmbContField1Help.style.display				=	"None";
			CmbContTypeHelp.style.display				=	"None";
			StartingRowPointHelp.style.display			=	"None";
			ClientInterSettlementHelp.style.display		=	"None";
			PoolInterSettlementHelp.style.display		=	"None";
			FlgMarginTypeHelp.style.display				=	"None";
			FlgInvalidCLTrdsInsertHelp.style.display	=	"None";
			FlgDeleteCLTrdsHelp.style.display			=	"None";
			FlgResetContractHelp.style.display			=	"None";
			FlgLdgrBalInSMSHelp.style.display			=	"None";
		}
		else
		{
			objName	=	obj.name;
		}
		
		if( objName == "BrokerCode" )
		{
			BrokerCodeHelp.style.display				=	"";
			ClearingMemberCodeHelp.style.display		=	"None";
			DefaultClientIDHelp.style.display			=	"None";
			DefaultHairCutHelp.style.display			=	"None";
			FTPIPAddressHelp.style.display				=	"None";
			CmbContFieldHelp.style.display				=	"None";
			CmbContField1Help.style.display				=	"None";
			CmbContTypeHelp.style.display				=	"None";
			StartingRowPointHelp.style.display			=	"None";
			ClientInterSettlementHelp.style.display		=	"None";
			PoolInterSettlementHelp.style.display		=	"None";
			FlgMarginTypeHelp.style.display				=	"None";
			FlgInvalidCLTrdsInsertHelp.style.display	=	"None";
			FlgDeleteCLTrdsHelp.style.display			=	"None";
			FlgResetContractHelp.style.display			=	"None";
			FlgLdgrBalInSMSHelp.style.display			=	"None";
		}
		else if( objName == "ClearingMemberCode" )
		{
			BrokerCodeHelp.style.display				=	"None";
			ClearingMemberCodeHelp.style.display		=	"";
			DefaultClientIDHelp.style.display			=	"None";
			DefaultHairCutHelp.style.display			=	"None";
			FTPIPAddressHelp.style.display				=	"None";
			CmbContFieldHelp.style.display				=	"None";
			CmbContField1Help.style.display				=	"None";
			CmbContTypeHelp.style.display				=	"None";
			StartingRowPointHelp.style.display			=	"None";
			ClientInterSettlementHelp.style.display		=	"None";
			PoolInterSettlementHelp.style.display		=	"None";
			FlgMarginTypeHelp.style.display				=	"None";
			FlgInvalidCLTrdsInsertHelp.style.display	=	"None";
			FlgDeleteCLTrdsHelp.style.display			=	"None";
			FlgResetContractHelp.style.display			=	"None";
			FlgLdgrBalInSMSHelp.style.display			=	"None";
		}
		else if( objName == "DefaultClientID" )
		{
			BrokerCodeHelp.style.display				=	"None";
			ClearingMemberCodeHelp.style.display		=	"None";
			DefaultClientIDHelp.style.display			=	"";
			DefaultHairCutHelp.style.display			=	"None";
			FTPIPAddressHelp.style.display				=	"None";
			CmbContFieldHelp.style.display				=	"None";
			CmbContField1Help.style.display				=	"None";
			CmbContTypeHelp.style.display				=	"None";
			StartingRowPointHelp.style.display			=	"None";
			ClientInterSettlementHelp.style.display		=	"None";
			PoolInterSettlementHelp.style.display		=	"None";
			FlgMarginTypeHelp.style.display				=	"None";
			FlgInvalidCLTrdsInsertHelp.style.display	=	"None";
			FlgDeleteCLTrdsHelp.style.display			=	"None";
			FlgResetContractHelp.style.display			=	"None";
			FlgLdgrBalInSMSHelp.style.display			=	"None";
		}
		else if( objName == "DefaultHairCut" )
		{
			BrokerCodeHelp.style.display				=	"None";
			ClearingMemberCodeHelp.style.display		=	"None";
			DefaultClientIDHelp.style.display			=	"None";
			DefaultHairCutHelp.style.display			=	"";
			FTPIPAddressHelp.style.display				=	"None";
			CmbContFieldHelp.style.display				=	"None";
			CmbContField1Help.style.display				=	"None";
			CmbContTypeHelp.style.display				=	"None";
			StartingRowPointHelp.style.display			=	"None";
			ClientInterSettlementHelp.style.display		=	"None";
			PoolInterSettlementHelp.style.display		=	"None";
			FlgMarginTypeHelp.style.display				=	"None";
			FlgInvalidCLTrdsInsertHelp.style.display	=	"None";
			FlgDeleteCLTrdsHelp.style.display			=	"None";
			FlgResetContractHelp.style.display			=	"None";
			FlgLdgrBalInSMSHelp.style.display			=	"None";
		}
		else if( objName == "FTPIPAddress" )
		{
			BrokerCodeHelp.style.display				=	"None";
			ClearingMemberCodeHelp.style.display		=	"None";
			DefaultClientIDHelp.style.display			=	"None";
			DefaultHairCutHelp.style.display			=	"None";
			FTPIPAddressHelp.style.display				=	"";
			CmbContFieldHelp.style.display				=	"None";
			CmbContField1Help.style.display				=	"None";
			CmbContTypeHelp.style.display				=	"None";
			StartingRowPointHelp.style.display			=	"None";
			ClientInterSettlementHelp.style.display		=	"None";
			PoolInterSettlementHelp.style.display		=	"None";
			FlgMarginTypeHelp.style.display				=	"None";
			FlgInvalidCLTrdsInsertHelp.style.display	=	"None";
			FlgDeleteCLTrdsHelp.style.display			=	"None";
			FlgResetContractHelp.style.display			=	"None";
			FlgLdgrBalInSMSHelp.style.display			=	"None";
		}
		else if( objName == "CmbContField" )
		{
			BrokerCodeHelp.style.display				=	"None";
			ClearingMemberCodeHelp.style.display		=	"None";
			DefaultClientIDHelp.style.display			=	"None";
			DefaultHairCutHelp.style.display			=	"None";
			FTPIPAddressHelp.style.display				=	"None";
			CmbContFieldHelp.style.display				=	"";
			CmbContField1Help.style.display				=	"None";
			CmbContTypeHelp.style.display				=	"None";
			StartingRowPointHelp.style.display			=	"None";
			ClientInterSettlementHelp.style.display		=	"None";
			PoolInterSettlementHelp.style.display		=	"None";
			FlgMarginTypeHelp.style.display				=	"None";
			FlgInvalidCLTrdsInsertHelp.style.display	=	"None";
			FlgDeleteCLTrdsHelp.style.display			=	"None";
			FlgResetContractHelp.style.display			=	"None";
			FlgLdgrBalInSMSHelp.style.display			=	"None";
		}
		else if( objName == "CmbContField1" )
		{
			BrokerCodeHelp.style.display				=	"None";
			ClearingMemberCodeHelp.style.display		=	"None";
			DefaultClientIDHelp.style.display			=	"None";
			DefaultHairCutHelp.style.display			=	"None";
			FTPIPAddressHelp.style.display				=	"None";
			CmbContFieldHelp.style.display				=	"None";
			CmbContField1Help.style.display				=	"";
			CmbContTypeHelp.style.display				=	"None";
			StartingRowPointHelp.style.display			=	"None";
			ClientInterSettlementHelp.style.display		=	"None";
			PoolInterSettlementHelp.style.display		=	"None";
			FlgMarginTypeHelp.style.display				=	"None";
			FlgInvalidCLTrdsInsertHelp.style.display	=	"None";
			FlgDeleteCLTrdsHelp.style.display			=	"None";
			FlgResetContractHelp.style.display			=	"None";
			FlgLdgrBalInSMSHelp.style.display			=	"None";
		}
		else if( objName == "CmbContType" )
		{
			BrokerCodeHelp.style.display				=	"None";
			ClearingMemberCodeHelp.style.display		=	"None";
			DefaultClientIDHelp.style.display			=	"None";
			DefaultHairCutHelp.style.display			=	"None";
			FTPIPAddressHelp.style.display				=	"None";
			CmbContFieldHelp.style.display				=	"None";
			CmbContField1Help.style.display				=	"None";
			CmbContTypeHelp.style.display				=	"";
			StartingRowPointHelp.style.display			=	"None";
			ClientInterSettlementHelp.style.display		=	"None";
			PoolInterSettlementHelp.style.display		=	"None";
			FlgMarginTypeHelp.style.display				=	"None";
			FlgInvalidCLTrdsInsertHelp.style.display	=	"None";
			FlgDeleteCLTrdsHelp.style.display			=	"None";
			FlgResetContractHelp.style.display			=	"None";
			FlgLdgrBalInSMSHelp.style.display			=	"None";
		}
		else if( objName == "StartingRowPoint" )
		{
			BrokerCodeHelp.style.display				=	"None";
			ClearingMemberCodeHelp.style.display		=	"None";
			DefaultClientIDHelp.style.display			=	"None";
			DefaultHairCutHelp.style.display			=	"None";
			FTPIPAddressHelp.style.display				=	"None";
			CmbContFieldHelp.style.display				=	"None";
			CmbContField1Help.style.display				=	"None";
			CmbContTypeHelp.style.display				=	"None";
			StartingRowPointHelp.style.display			=	"";
			ClientInterSettlementHelp.style.display		=	"None";
			PoolInterSettlementHelp.style.display		=	"None";
			FlgMarginTypeHelp.style.display				=	"None";
			FlgInvalidCLTrdsInsertHelp.style.display	=	"None";
			FlgDeleteCLTrdsHelp.style.display			=	"None";
			FlgResetContractHelp.style.display			=	"None";
			FlgLdgrBalInSMSHelp.style.display			=	"None";
		}
		else if( objName == "ClientInterSettlement" )
		{
			BrokerCodeHelp.style.display				=	"None";
			ClearingMemberCodeHelp.style.display		=	"None";
			DefaultClientIDHelp.style.display			=	"None";
			DefaultHairCutHelp.style.display			=	"None";
			FTPIPAddressHelp.style.display				=	"None";
			CmbContFieldHelp.style.display				=	"None";
			CmbContField1Help.style.display				=	"None";
			CmbContTypeHelp.style.display				=	"None";
			StartingRowPointHelp.style.display			=	"None";
			ClientInterSettlementHelp.style.display		=	"";
			PoolInterSettlementHelp.style.display		=	"None";
			FlgMarginTypeHelp.style.display				=	"None";
			FlgInvalidCLTrdsInsertHelp.style.display	=	"None";
			FlgDeleteCLTrdsHelp.style.display			=	"None";
			FlgResetContractHelp.style.display			=	"None";
			FlgLdgrBalInSMSHelp.style.display			=	"None";
		}
		else if( objName == "PoolInterSettlement" )
		{
			BrokerCodeHelp.style.display				=	"None";
			ClearingMemberCodeHelp.style.display		=	"None";
			DefaultClientIDHelp.style.display			=	"None";
			DefaultHairCutHelp.style.display			=	"None";
			FTPIPAddressHelp.style.display				=	"None";
			CmbContFieldHelp.style.display				=	"None";
			CmbContField1Help.style.display				=	"None";
			CmbContTypeHelp.style.display				=	"None";
			StartingRowPointHelp.style.display			=	"None";
			ClientInterSettlementHelp.style.display		=	"None";
			PoolInterSettlementHelp.style.display		=	"";
			FlgMarginTypeHelp.style.display				=	"None";
			FlgInvalidCLTrdsInsertHelp.style.display	=	"None";
			FlgDeleteCLTrdsHelp.style.display			=	"None";
			FlgResetContractHelp.style.display			=	"None";
			FlgLdgrBalInSMSHelp.style.display			=	"None";
		}
		else if( objName == "FlgMarginType" )
		{
			BrokerCodeHelp.style.display				=	"None";
			ClearingMemberCodeHelp.style.display		=	"None";
			DefaultClientIDHelp.style.display			=	"None";
			DefaultHairCutHelp.style.display			=	"None";
			FTPIPAddressHelp.style.display				=	"None";
			CmbContFieldHelp.style.display				=	"None";
			CmbContField1Help.style.display				=	"None";
			CmbContTypeHelp.style.display				=	"None";
			StartingRowPointHelp.style.display			=	"None";
			ClientInterSettlementHelp.style.display		=	"None";
			PoolInterSettlementHelp.style.display		=	"None";
			FlgMarginTypeHelp.style.display				=	"";
			FlgInvalidCLTrdsInsertHelp.style.display	=	"None";
			FlgDeleteCLTrdsHelp.style.display			=	"None";
			FlgResetContractHelp.style.display			=	"None";
			FlgLdgrBalInSMSHelp.style.display			=	"None";
		}
		else if( objName == "FlgInvalidCLTrdsInsert" )
		{
			BrokerCodeHelp.style.display				=	"None";
			ClearingMemberCodeHelp.style.display		=	"None";
			DefaultClientIDHelp.style.display			=	"None";
			DefaultHairCutHelp.style.display			=	"None";
			FTPIPAddressHelp.style.display				=	"None";
			CmbContFieldHelp.style.display				=	"None";
			CmbContField1Help.style.display				=	"None";
			CmbContTypeHelp.style.display				=	"None";
			StartingRowPointHelp.style.display			=	"None";
			ClientInterSettlementHelp.style.display		=	"None";
			PoolInterSettlementHelp.style.display		=	"None";
			FlgMarginTypeHelp.style.display				=	"None";
			FlgInvalidCLTrdsInsertHelp.style.display	=	"";
			FlgDeleteCLTrdsHelp.style.display			=	"None";
			FlgResetContractHelp.style.display			=	"None";
			FlgLdgrBalInSMSHelp.style.display			=	"None";
		}
		else if( objName == "FlgDeleteCLTrds" )
		{
			BrokerCodeHelp.style.display				=	"None";
			ClearingMemberCodeHelp.style.display		=	"None";
			DefaultClientIDHelp.style.display			=	"None";
			DefaultHairCutHelp.style.display			=	"None";
			FTPIPAddressHelp.style.display				=	"None";
			CmbContFieldHelp.style.display				=	"None";
			CmbContField1Help.style.display				=	"None";
			CmbContTypeHelp.style.display				=	"None";
			StartingRowPointHelp.style.display			=	"None";
			ClientInterSettlementHelp.style.display		=	"None";
			PoolInterSettlementHelp.style.display		=	"None";
			FlgMarginTypeHelp.style.display				=	"None";
			FlgInvalidCLTrdsInsertHelp.style.display	=	"None";
			FlgDeleteCLTrdsHelp.style.display			=	"";
			FlgResetContractHelp.style.display			=	"None";
			FlgLdgrBalInSMSHelp.style.display			=	"None";
		}
		else if( objName == "FlgResetContract" )
		{
			BrokerCodeHelp.style.display				=	"None";
			ClearingMemberCodeHelp.style.display		=	"None";
			DefaultClientIDHelp.style.display			=	"None";
			DefaultHairCutHelp.style.display			=	"None";
			FTPIPAddressHelp.style.display				=	"None";
			CmbContFieldHelp.style.display				=	"None";
			CmbContField1Help.style.display				=	"None";
			CmbContTypeHelp.style.display				=	"None";
			StartingRowPointHelp.style.display			=	"None";
			ClientInterSettlementHelp.style.display		=	"None";
			PoolInterSettlementHelp.style.display		=	"None";
			FlgMarginTypeHelp.style.display				=	"None";
			FlgInvalidCLTrdsInsertHelp.style.display	=	"None";
			FlgDeleteCLTrdsHelp.style.display			=	"None";
			FlgResetContractHelp.style.display			=	"";
			FlgLdgrBalInSMSHelp.style.display			=	"None";
		}
		else if( objName == "FlgLdgrBalInSMS" )
		{
			BrokerCodeHelp.style.display				=	"None";
			ClearingMemberCodeHelp.style.display		=	"None";
			DefaultClientIDHelp.style.display			=	"None";
			DefaultHairCutHelp.style.display			=	"None";
			FTPIPAddressHelp.style.display				=	"None";
			CmbContFieldHelp.style.display				=	"None";
			CmbContField1Help.style.display				=	"None";
			CmbContTypeHelp.style.display				=	"None";
			StartingRowPointHelp.style.display			=	"None";
			ClientInterSettlementHelp.style.display		=	"None";
			PoolInterSettlementHelp.style.display		=	"None";
			FlgMarginTypeHelp.style.display				=	"None";
			FlgInvalidCLTrdsInsertHelp.style.display	=	"None";
			FlgDeleteCLTrdsHelp.style.display			=	"None";
			FlgResetContractHelp.style.display			=	"None";
			FlgLdgrBalInSMSHelp.style.display			=	"";
		}
	}
}

function ShowOption(form, val)
{
	with (form)
	{
		if (val == "Y")
		{			
			CounterClientPOA.style.display = "";
		}
		else
		{
			CounterClientPOA.style.display = "None";
			CounterID.style.display = "None";
		}
	}
}

function ShowPOAClId()
{
	CounterID.style.display = "";
}	

function SetStatus (form,status)
{
	with(form)
	{
		if (status == 'N')
		{
			PreorSufix.style.display = "none";
			Valuefor.style.display = "none";
			AsMarginOrSub.style.display = "none";
		}
		
		else
		{
			PreorSufix.style.display = "";
			Valuefor.style.display = "";
			AsMarginOrSub.style.display = "";
		}			
	}
}	

function SetStatus1 (form,status)
{
	with(form)
	{
		if (status == 'N')
		{
			ControlAcCode.style.display = "none";
		}
		
		else
		{
			ControlAcCode.style.display = "";
		}			
	}
}	


function HidefoBilling(form,value)
{
	with(form)
	{
		if (value == 'N')
		{
			FoBillingTime.style.display = "none";	
		}
		else
		{
			FoBillingTime.style.display = "";
		}
	}
}