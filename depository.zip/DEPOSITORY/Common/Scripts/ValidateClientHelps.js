function CloseWindow()
{
	try
	{
		if( typeof( HelpWindow ) == "object" && !HelpWindow.closed )
		{
			HelpWindow.close();
			throw "e";
		}
	}
	catch( e )
	{
		return( e );
	}
}

function OpenWindow( form, clientIDObj, clientNameObj, showClientName, showCMCode, currClient )
{
	with( form )
	{
		HelpWindow	=	open( "/DEPOSITORY/HelpSearch/SingleChoice.cfm?COCD=" +COCD.value +"&Title=Clients Help&HelpFor=&ClObj=" +clientIDObj +"&ClNameObj=" +clientNameObj +"&ShowClName=" +showClientName +"&ShowCMCode=" +showCMCode +"&CurrClient=" +currClient, "ClientIDHelpWindow", "Top=50, Left=100, Width=600, Height=400, Resizeable=no" );
	}
}