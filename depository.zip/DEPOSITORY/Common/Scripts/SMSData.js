function openReports()
{
	with (SMSReport)
	{
		DrCrFilter.disabled = false;
		action='SMSReport.cfm';	
	}
}

function setObjects(rptID)
{
	with (SMSReport)
	{
		
		setFilterObject(rptID);
		
	}
}




function setFilterObject(rptID)
{
	with(SMSReport)
	{
  
		
		
		
		if (rptID != 6 )
		{	
			FromAmt.disabled = true;
			ToAmt.disabled = true;
		}
		else
		{	
			FromAmt.disabled = false;
			ToAmt.disabled = false;
		}
		
		if (rptID != 8 && rptID != 6 )
		{	
			To_Date.disabled = true;
		}
		else
		{	
			To_Date.disabled = false;
		}
		
		if (rptID != 7 )
		{	
			BalanceDate.disabled = true;
		}
		else
		{	
			BalanceDate.disabled = false;
		}
				
	}
}
