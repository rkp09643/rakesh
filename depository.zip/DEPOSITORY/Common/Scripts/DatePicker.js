var gdCtrl = new Object();
var gcGray = "inactivecaption";
var gcToggle = "buttonface";
var gcBG = "window";
var oDatePopup = window.createPopup();
var gMonths = new Array("January","February","March","April","May","June","July","August","September","October","November","December");

var giYear;
var giMonth;
var giDay;
fSetCurDate(new Date());


//To set current date of the Calendar
function fSetCurDate(dt)
{
	giYear = dt.getFullYear();
	giMonth = dt.getMonth()+1;
	giDay = dt.getDate();
}

//To format the date as it will be returned to the text box
function fSetDate(iYear, iMonth, iDay)
{
	var cMonth;
	if (iDay == 1 || iDay == 2 || iDay == 3 || iDay == 4 || iDay == 5 || iDay == 6 || iDay == 7 || iDay == 8 || iDay == 9)
	  iDay = '0'+iDay;
	
	cMonth = iMonth;
	if (iMonth == 1 || iMonth == 2 || iMonth == 3 || iMonth == 4 || iMonth == 5 || iMonth == 6 || iMonth == 7 || iMonth == 8 || iMonth == 9)
	  cMonth = '0'+iMonth;
	
	/*switch(iMonth)
	{
		case 1: cMonth="Jan"; break;
		case 2: cMonth="Feb"; break;
		case 3: cMonth="Mar"; break;
		case 4: cMonth="Apr"; break;
		case 5: cMonth="May"; break;
		case 6: cMonth="Jun"; break;
		case 7: cMonth="Jul"; break;
		case 8: cMonth="Aug"; break;
		case 9: cMonth="Sep"; break;
		case 10: cMonth="Oct"; break;
		case 11: cMonth="Nov"; break;
		case 12: cMonth="Dec";
	}*/
	return(iDay+"/" + cMonth + "/"+iYear);
}

//To set the currently selected date of the calendar in the text box
function fSetSelected(aCell,idx)
{
	var iOffset = 0;
	var iYear = parseInt(tbSelYear.value);
	var iMonth = parseInt(tbSelMonth.value);

	aCell.bgColor = gcBG;
	oDatePopup.hide();

	with (aCell)
	{
		var iDay = parseInt(innerText);
		if (style.color==gcGray)
			iOffset = (idx<7)?-1:1;
		iMonth += iOffset;
		if (iMonth<1) {
			iYear--;
			iMonth = 12;
		}
		else if (iMonth>12)
		{
			iYear++;
			iMonth = 1;
		}
	}
	gdCtrl.value = fSetDate(iYear, iMonth, iDay);
	gdCtrl.focus();
}

//Point class
function Point(iX, iY)
{
	this.x = iX;
	this.y = iY;
}

//To set a 2D array based on Year and Month
function fBuildCal(iYear, iMonth) 
{
	var aMonth=new Array();
	for(i=1;i<7;i++)
		aMonth[i]=new Array(i);

	var dCalDate=new Date(iYear, iMonth-1, 1);
	var iDayOfFirst=dCalDate.getDay();
	var iDaysInMonth=new Date(iYear, iMonth, 0).getDate();
	var iOffsetLast=new Date(iYear, iMonth-1, 0).getDate()-iDayOfFirst+1;
	var iDate = 1;
	var iNext = 1;

	for (d = 0; d < 7; d++)
		aMonth[1][d] = (d<iDayOfFirst)?-(iOffsetLast+d):iDate++;

	for (w = 2; w < 7; w++)
		for (d = 0; d < 7; d++)
			aMonth[w][d] = (iDate<=iDaysInMonth)?iDate++:-(iNext++);
	return aMonth;
}

//To darw the inner table for all the dates
function fDrawCal(iYear, iMonth, iCellHeight, sDateTextSize) 
{
	var WeekDay = new Array("S","M","T","W","T","F","S");
	var styleTD1 = " bgcolor='"+gcBG+"' bordercolor='"+gcBG+"' valign='middle' align='center' style='font:bold 8pt Tahoma;";
	var styleTD2 = " bgcolor='"+gcBG+"' bordercolor='"+gcBG+"' valign='middle' align='center' style='font:8pt Tahoma;";           

	with (oDatePopup.document) 
	{
		write("<tr>");
		for(i=0; i<7; i++)
			write("<td "+styleTD1+"color:buttontext' >" + WeekDay[i] + "</td>");
		write("</tr>");

		for (w = 1; w < 7; w++) {
			write("<tr>");
			for (d = 0; d < 7; d++)
				write("<td id=calCell "+styleTD2+"cursor:hand;' onMouseOver='this.bgColor=parent.gcToggle' onMouseOut='this.bgColor=parent.gcBG' onclick='parent.fSetSelected(this,"+ ((w-1)*7+d+1) +")'></TD>");
			write("</tr>");
		}
	}
}

//To update date values calculated using fBuildCal
function fUpdateCal(iYear, iMonth) 
{
	myMonth = fBuildCal(iYear, iMonth);
	var i = 0;
	for (w = 0; w < 6; w++)
		for (d = 0; d < 7; d++)
	  		with (oDatePopup.document.all("calCell")[(7*w)+d]) 
	  		{
	  			style.borderStyle='solid';
	  			if (myMonth[w+1][d]<0) 
	  			{
	  				style.color = gcGray;
	  				innerText = -myMonth[w+1][d];
	  				style.borderColor = gcBG;
	  			}
	  			else 
	  			{
	  				if(myMonth[w+1][d] == giDay && iMonth == giMonth && iYear == giYear) style.borderColor = "red";
	  				else style.borderColor = gcBG;
	  				style.color = ((d==0)||(d==6))?"red":"buttontext";
	  				innerText = myMonth[w+1][d];
	  			}
	  		}
}

//To set the current year and month
function fSetYearMon(iYear, iMon)
{
	tbSelMonth.options[iMon-1].selected = true;
	for (i = 0; i < tbSelYear.length; i++)
		if (tbSelYear.options[i].value == iYear)
			tbSelYear.options[i].selected = true;
	fUpdateCal(iYear, iMon);
}

//To set the previous month (with validation for current month as first month and others)
function fPrevMonth()
{
	var iMon = tbSelMonth.value;
	var iYear = tbSelYear.value;

	if(iMon==1 && iYear==tbSelYear.options[0].value) return;

	if (--iMon<1) 
	{
		iMon = 12;
		iYear--;
	}

	fSetYearMon(iYear, iMon);
}

//To set the next month (with validation for current month as last month)
function fNextMonth()
{
	var iMon = tbSelMonth.value;
	var iYear = tbSelYear.value;

	if (++iMon>12) 
	{
		iMon = 1;
		iYear++;
	}

	fSetYearMon(iYear, iMon);
}

//To get the XY location of the object where the calendar will be displayed
function fGetXY(aTag)
{
	var oTmp = aTag;
	var pt = new Point(0,0);
	do 
	{
		pt.x += oTmp.offsetLeft;
		pt.y += oTmp.offsetTop;
		oTmp = oTmp.offsetParent;
	} while(oTmp.tagName!="BODY");
	return pt;
}

// Main: popCtrl is the widget beyond which you want this calendar to appear;
//       dateCtrl is the widget into which you want to put the selected date.
// i.e.: <input type="text" name="dc" readonly><INPUT type="button" value="V" onclick="fPopCalendar(dc,dc);return false">
function fPopCalendar(popCtrl, dateCtrl)
{

	gdCtrl = dateCtrl;
	var sDt, mth;
	sDt = dateCtrl.value;
	if (sDt.length==10)
	{
		switch(sDt.substr(3,2))
		{
			case "01": mth="Jan"; break;
			case "02": mth="Feb"; break;
			case "03": mth="Mar"; break;
			case "04": mth="Apr"; break;
			case "05": mth="May"; break;
			case "06": mth="Jun"; break;
			case "07": mth="Jul"; break;
			case "08": mth="Aug"; break;
			case "09": mth="Sep"; break;
			case "10": mth="Oct"; break;
			case "11": mth="Nov"; break;
			case "12": mth="Dec";
		}

		sDt = mth + " " + sDt.substr(0,2) + "," + sDt.substr(6,4)
		fSetCurDate(new Date(sDt));
	}
	fSetYearMon(giYear, giMonth);
	var point = fGetXY(popCtrl);
	var l = point.x+2;
	var t  = point.y+popCtrl.offsetHeight+3;
	oDatePopup.show(l, t, 153, 182, document.body);
}

with (oDatePopup.document) 
{
	write("<BODY leftmargin=0 topmargin=0 scroll=no>")
	write("<table border='1' bgcolor='buttonface' cellpadding=0 cellspacing=0>");
	write("<TR height=25>");
	write("<td valign='middle' align='center'>");
	write("<select id='tbSelMonth' name='tbSelMonth' style='font:8pt;' onChange='parent.fUpdateCal(tbSelYear.value, tbSelMonth.value)'>");
	for (i=0; i<12; i++)
		write("<option value='"+(i+1)+"'>"+gMonths[i]+"</option>");
	write("</SELECT>");
	write("&nbsp;<SELECT id='tbSelYear' name='tbSelYear' style='font:8pt;' onChange='parent.fUpdateCal(tbSelYear.value, tbSelMonth.value)'>");
	for(i=2001;i<2051;i++)
		write("<OPTION value='"+i+"'>"+i+"</OPTION>");
	write("</SELECT>");
	write("</td>");
	write("</TR>");
	write("<TR height=20><TD align=center valign=middle style='color:buttontext;font:bold 9pt Tahoma;'>");
	write("<SPAN style='cursor:hand;' onclick='if(tbSelYear.value > tbSelYear.options[0].value) parent.fSetYearMon(parseInt(tbSelYear.value) - 1, tbSelMonth.value);'><A style='color:buttontext;font:bold 9pt Tahoma;text-decoration:none' href='#'>&lt;&lt;</A></SPAN>&nbsp;&nbsp;&nbsp;");
	write("<SPAN style='cursor:hand;' onclick='parent.fPrevMonth();'><A style='color:buttontext;font:bold 9pt Tahoma;text-decoration:none' href='#'>&lt;</A></SPAN>&nbsp;&nbsp;&nbsp;");
	write("<SPAN onclick='parent.fSetCurDate(new Date()); parent.fSetYearMon(parent.giYear, parent.giMonth);'><A style='color:buttontext;font:bold 9pt Tahoma;text-decoration:none' href='#'>Today</A></SPAN>&nbsp;&nbsp;&nbsp;");
	write("<SPAN style='cursor:hand;' onclick='parent.fNextMonth();'><A style='color:buttontext;font:bold 9pt Tahoma;text-decoration:none' href='#'>&gt;</A></SPAN>&nbsp;&nbsp;&nbsp;");
	write("<SPAN style='cursor:hand;' onclick='parent.fSetYearMon(parseInt(tbSelYear.value) + 1, tbSelMonth.value)'><A style='color:buttontext;font:bold 9pt Tahoma;text-decoration:none' href='#'>&gt;&gt;</A></SPAN>");
	write("</TR>");
	write("<TR><td align='center'>");
	write("<table width='100%' border='1' cellspacing=1 style='background-color:"+gcBG+"'>");
	fDrawCal(giYear, giMonth, 10, '8');
	write("</table>");
	write("</td>");
	write("</TR>");
	write("</TABLE>");
}
var tbSelMonth = oDatePopup.document.all("tbSelMonth");
var tbSelYear = oDatePopup.document.all("tbSelYear");


function dateOnKeyDown() {
/* Purpose : Formats date text field so it adheres to
* the dd/mm/yyyy format
*
* Effects : Sets the value of the text field
*
* Inputs : None
*
* Returns : None
*/

var DATE_DIVIDER = "/";
var SPACE_CHARACTER = "_";

var objTextBox = window.event.srcElement;
var iKeyCode = window.event.keyCode;
var bSelectedText = false;

// Exit if field is read-only
if (window.event.srcElement.readOnly) return;

// Allow key presses of <cursor arrow> or <Home> or <End>
if ((iKeyCode > 36 && iKeyCode < 41) || (iKeyCode > 34 && iKeyCode <
37)) {
return 1;
}

// Allow <Ctrl+C>, <Ctrl+V>, <Ctrl+X> and <Ctrl+Z>
if (window.event.ctrlKey && (iKeyCode == 67 || iKeyCode == 86 ||
iKeyCode == 88 || iKeyCode == 90)) {
return 1;
}

// Get the position of the cursor
var iCaretPosition = getCaretPosition(objTextBox);

// Get the selected text
var objSelectedText = document.selection.createRange();

// Determine if some text has been selected
if (objSelectedText.parentElement() == objTextBox &&
objSelectedText.text.length > 0)
{
bSelectedText = true;
}

// Get the element next to the cursor (to be used later)
var sFirstElement = objTextBox.value.substring(iCaretPosition,
iCaretPosition-1);

// Do not enter number if there's no space for it
if ((sFirstElement != SPACE_CHARACTER) && !(iKeyCode == 8 || iKeyCode
== 46) && objSelectedText.text == 0) {
return 0;
}

// If key pressed is <0-9>
if ((iKeyCode > 47 && iKeyCode < 58) ||
(iKeyCode > 95 && iKeyCode < 106)) {
if (iKeyCode > 95) iKeyCode -= (95-47);

// Do not update text/move cursor if it is at the end of the textbox
if (iCaretPosition != 11) {

// Only write the character if it's filling an empty gap
// ie don't overwrite existing number or '/' characters
var sNextElement = objTextBox.value.substring(iCaretPosition-1,
iCaretPosition);

if (!bSelectedText && sNextElement == SPACE_CHARACTER) {
// Get the text before the cursor
var sElement1 = objTextBox.value.substring(0, iCaretPosition-1);
// Get the text after the cursor
var sElement2 = objTextBox.value.substring(iCaretPosition +
objSelectedText.text.length, objTextBox.value.length);
// Append the new character
sElement1 += String.fromCharCode(iKeyCode);
// Append the text from after the cursor
sElement1 += sElement2;
objTextBox.value = sElement1;

// Move the cursor position on one for "/" charcters
switch (iCaretPosition) {
case 2:
case 5:
iCaretPosition = iCaretPosition+1;
default:
}
}

// Handle selected text
if (bSelectedText) {

// Get the text before the selected text
var sElement1 = objTextBox.value.substring(0, iCaretPosition-1);

// We need to keep "/" characters
if (sFirstElement == DATE_DIVIDER) {
sElement1 += DATE_DIVIDER;
}

// Append the new character
sElement1 += String.fromCharCode(iKeyCode);

// Replace the remaining selected text with blank spaces
for (var i=1; i<objSelectedText.text.length; i++) {
var sDeletedChar = objSelectedText.text.substring(i, i+1);
if (sDeletedChar == DATE_DIVIDER) {
// Keep the slash characters
sElement1 += DATE_DIVIDER;
} else {
// Do not insert extra space if the first selected character is a "/"
if (!(i==1 && sFirstElement == DATE_DIVIDER)) {
// Replace numbers with a space
sElement1 += SPACE_CHARACTER;
}
}
}

// Get the text after the selected text and append
var sElement2 = objTextBox.value.substring(iCaretPosition +
objSelectedText.text.length-1, objTextBox.value.length);
sElement1 += sElement2;
objTextBox.value = sElement1;
}

// Put the cursor in the correct position
objSelectedRange = objTextBox.createTextRange();

// Move cursor on 1 if the first selected character is a "/"
if (bSelectedText && sFirstElement == DATE_DIVIDER) iCaretPosition
= iCaretPosition+1;
objSelectedRange.move("character", iCaretPosition)
objSelectedRange.select();

}
} // End if key pressed is <0-9>

// If key pressed is <Del>
if (iKeyCode == 8 || iKeyCode == 46) {

// Handle selected text
if (bSelectedText) {

// Get the text before the selected text

var sElement1 = objTextBox.value.substring(0, iCaretPosition-1);

// We need to keep "/" characters
if (sFirstElement == DATE_DIVIDER) {
sElement1 += DATE_DIVIDER;
}

// Append the new character
sElement1 += SPACE_CHARACTER;

// Replace the remaining selected text with blank spaces
for (var i=1; i<objSelectedText.text.length; i++) {
var sDeletedChar = objSelectedText.text.substring(i, i+1);
if (sDeletedChar == DATE_DIVIDER) {
// Keep the slash characters
sElement1 += DATE_DIVIDER;
} else {
// Do not insert extra space if the first selected character is a
"/"
if (!(i==1 && sFirstElement == DATE_DIVIDER)) {
// Replace numbers with a space
sElement1 += SPACE_CHARACTER;
}
}
}

// Get the text after the selected text and append
var sElement2 = objTextBox.value.substring(iCaretPosition +
objSelectedText.text.length-1, objTextBox.value.length);
sElement1 += sElement2;
objTextBox.value = sElement1;

iCaretPosition = iCaretPosition+1;

} else {
// We need to delete character by character
if (iCaretPosition != 11 || iKeyCode != 46) {

if (iKeyCode == 46) iCaretPosition = iCaretPosition+1;

if (iCaretPosition != 1 && iCaretPosition != 4 && iCaretPosition
!= 7){
var sElement1 = objTextBox.value.substring(0, iCaretPosition-2);
var sElement2 = objTextBox.value.substring(iCaretPosition-1,
objTextBox.value.length);
sElement1 += SPACE_CHARACTER;
sElement1 += sElement2;
objTextBox.value = sElement1;
}
}
}

// Put the cursor in the correct position
objRange = objTextBox.createTextRange();
// Move cursor on 1 if the first selected character is a "/"
if (bSelectedText && sFirstElement == DATE_DIVIDER) iCaretPosition =
iCaretPosition+1;
objRange.move("character", iCaretPosition - 2)
objRange.select();

} // End if key pressed is <Del>

// If key pressed is <Tab>
if (iKeyCode != 9) {
event.returnValue = false;
}
}


function getCaretPosition(objTextBox){
/* Purpose : Returns the caret position of the cursor
* in the text box
*
* Effects : None
*
* Inputs : objTextBox - a text box
*
* Returns : Integer indicating the caret position
* in the text box
*/

var i = objTextBox.value.length+1;

if (objTextBox.createTextRange){
objCaret = document.selection.createRange().duplicate();
while (objCaret.parentElement()==objTextBox &&
objCaret.move("character",1)==1) --i;
}

return i;
}

function dateOnPaste(objTextBox) {
/* Purpose : Handles paste event
*
* Effects : Copies the clipboard value to the text field
*
* Inputs : None
*
* Returns : None
*/

var sClipboard = window.clipboardData.getData('Text');

// Validate that the pasted text is in nn/nn/nnnn format
if (sClipboard.match(/^[0-9]{2}\/[0-9]{2}\/[0-9]{4}$/)) {
objTextBox.value = sClipboard;
} else {
// Do not allow paste
window.event.returnValue = 0;
}
}
