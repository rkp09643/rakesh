function openReports()
{
	with (MISReport)
	{
		for (i = 1; i <= Company_Count.value; i++)
		{
			eval("chk" + i).disabled=false;
		}
		TrFOBalanceObject.disabled = false;
		FOCLCOLAMT.disabled = false;
		DrCrFilter.disabled = false;
		action='MISReport.cfm';	
	}
}

function setObjects(rptID)
{
	with (MISReport)
	{
		setCustomDayObject(rptID);
		setCompanyListObject(rptID);
		setFilterObject(rptID);
		setFoBalanceObject(rptID);
		
		if (rptID == 7)
		{
			ClStkValuation.disabled=true;
			BenStkValuation.disabled=true;
			ShrtIn.disabled=true;
			ShrtOut.disabled=true;
			ShortConsiderationWorkingDays.disabled=true;
		}
		else
		{
				ClStkValuation.disabled=false;
				BenStkValuation.disabled=false;
			ShrtIn.disabled=false
			ShrtOut.disabled=false;
						ShortConsiderationWorkingDays.disabled=false;
		}
	}
}

function setCustomDayObject(rptID)
{
	with(MISReport)
	{
		if ( rptID == 3 || rptID == 4 || rptID == 8)
		{	
			trCustomDays.disabled=false;
			CustomDays.disabled=false;
		}
		else
		{	
			trCustomDays.disabled=true;
			CustomDays.disabled=true;
		}
	}
}

function setCompanyListObject(rptID)
{
	with(MISReport)
	{
		if (rptID == 1 || rptID == 7)
		{	
			for (i = 1; i <= Company_Count.value; i++)
			{
				eval("chk" + i).checked=true;
				eval("chk" + i).disabled=false;
			}
		}
		else
		{	
			for (i = 1; i <= Company_Count.value; i++)
			{
				if ( eval("chk" + i).value == COCD.value )
				{
					eval("chk" + i).checked=true;
				}
				else
				{
					eval("chk" + i).checked=false;
				}
					eval("chk" + i).disabled=true;
			}
		}
	}
}

function setFoBalanceObject(rptID)
{
	with (MISReport)
	{
		if (rptID != 1)
		{
			if ( Market.value == "FO" )
			{
				TrFOBalanceObject.disabled = false;
			}
			else
			{
				TrFOBalanceObject.disabled = true;
				FOClAmt.checked = true;
				FOCLCOLAMT.disabled = true;
			}
		}
	}
}

function setFilterObject(rptID)
{
	with(MISReport)
	{
		if (rptID == 2 || rptID == 4)
		{	
			DrCrFilter.selectedIndex = 1;
			DrCrFilter.disabled=true;
		}
		else if (rptID == 5)
		{	
			DrCrFilter.selectedIndex = 2;
			DrCrFilter.disabled=true;
		}
		else
		{	
			DrCrFilter.selectedIndex = 0;
			DrCrFilter.disabled=false;
		}
	}
}
