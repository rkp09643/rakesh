/* ####################################################################################
					JAVASCRIPT FILE FOR OPENING/MAILING CAPITAL REPORTS.
#################################################################################### */


function setOnLoad( form, rptID )
{
	with( form )
	{
		msg.value	=	"";
		PrintDate.focus();
		
		if( rptID == 1 )
		{
			MailReport.style.display	=	"";
			SMSReport.style.display		=	"None";
		}
		else if( rptID == 2 )
		{
			MailReport.style.display	=	"";
			
			if( D.checked || S.checked )
			{
				SMSReport.style.display	=	"None";
			}
			else if( A.checked )
			{
				SMSReport.style.display	=	"";
			}
		}
		else
		{
			MailReport.style.display	=	"None";
			SMSReport.style.display		=	"None";
		}
	}
}


function openReports( form )
{
	with( form )
	{
		msg.value = "Please wait ....";

		//************************ REPORT 1: CONTRACT **********************
		if( ReportNo.value == 1 )
		{
			if( Selection[0].checked )
			{

				if( parseInt( PaperSize.value ) == 0 )
				{
					title1	=	"Contract ";
				}
				else
				{
					title1	=	"Trade Done ";
				}
			
				title2	=	"Detail";
				
				/*if ( ChkShowNet.checked )
				{
					ShowNet = "Y";
				}
				else
				{
					ShowNet = "N";
				}*/
				ShowNet = "N";
				
				if( flgReportTextGenerate.value == "True" )
				{
					parent.Display.location.href = "/DEPOSITORY/Text_Reports/CAPS/PrePrintedContractText.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&Trade_Date=&FromClient=" +escape( FromClient.value ) +"&ToClient=&ContractNo=" +ContractNo.value +"&Trade_Date=" + FromDate.value +"&BranchID=" +BranchID.value +"&Type=Detail&PrintDate=" +PrintDate.value +"&ReportType=" +PaperSize.value +"&ShowNet=" + ShowNet +"&Title=" +title1 +title2 +"&Order=" + PrintOrder.value +"&RepID=" +ReportNo.value;
				}
				else if( parseInt( PaperSize.value ) == 0 )
				{
					parent.Display.location.href = "/DEPOSITORY/Reports/CAPS/PrePrintedContract.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&Trade_Date=&FromClient=" +escape( FromClient.value ) +"&ToClient=&ContractNo=" +ContractNo.value +"&Trade_Date=" + FromDate.value +"&BranchID=" +BranchID.value +"&Type=Detail&PrintDate=" +PrintDate.value +"&ReportType=" +PaperSize.value +"&ShowNet=" + ShowNet +"&Title=" +title1 +title2 +"&Order=" + PrintOrder.value +"&RepID=" +ReportNo.value;
				}
				else if( parseInt( PaperSize.value ) == 70)
				{
					parent.Display.location.href = "/DEPOSITORY/Reports/CAPS/ContractDetails.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&ContractNo=" +"&Trade_Date=" + FromDate.value +"&BranchID=" +BranchID.value +"&Type=Detail&PrintDate=" +PrintDate.value +"&ReportType=" +PaperSize.value +"&ShowNet=" + ShowNet +"&Title=" +title1 +title2 +"&Order=" + PrintOrder.value +"&RepID=" +ReportNo.value;
				}
				else
				{
					parent.Display.location.href = "/DEPOSITORY/Reports/CAPS/PrePrintedContract1.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&Trade_Date=&FromClient=" +escape( FromClient.value ) +"&ToClient=&ContractNo=" +ContractNo.value +"&BranchID=" +BranchID.value +"&Type=Detail&PrintDate=" +PrintDate.value +"&ReportType=" +PaperSize.value +"&ShowNet=" + ShowNet +"&Title=" +title1 +title2 +"&RepID=" +ReportNo.value;					
				}
			}
			if( Selection[1].checked )
			{

				title1 = "Trade Done ";
				title2 = "Summary";
				
				if( parseInt( PaperSize.value ) == 0 )
				{
					parent.Display.location.href = "/DEPOSITORY/Reports/CAPS/PrePrintedContract.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&Trade_Date=&Report_Type=S&FromClient=" +escape( FromClient.value ) +"&ToClient=&ContractNo=" +ContractNo.value +"&BranchID=" +BranchID.value +"&Type=Detail&PrintDate=" +PrintDate.value +"&ReportType=" +PaperSize.value +"&Title=" +title1 +title2 +"&RepID=" +ReportNo.value;
				}
				else
				{
					parent.Display.location.href = "/DEPOSITORY/Reports/CAPS/ContractSummary.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&Trade_Date=&FromClient=" +escape( FromClient.value ) +"&ToClient=&ContractNo=" +ContractNo.value +"&BranchID=" +BranchID.value +"&Type=Summ&PrintDate=" +PrintDate.value +"&ReportType=" +PaperSize.value +"&Title=" +title1 +title2 +"&RepID=" +ReportNo.value;
				}	
			}
		}


		//************************** REPORT 2: BILL ************************
		if( ReportNo.value == 2 )
		{
			title1 = "Bill ";
			
			if( Selection[0].checked )
			{
				title2 = "Detail";
				if( flgReportTextGenerate.value == "True" )
				{
					parent.Display.location.href = "/DEPOSITORY/Text_Reports/CAPS/PrePrintedBillText.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=" +BillNo.value +"&BranchID=" +BranchID.value +"&Type=Detail&PrintDate=" +PrintDate.value +"&ReportType=" +PaperSize.value +"&Title=" +title1 +title2 +"&RepID=" +ReportNo.value;
				}
				else if( parseInt( PaperSize.value ) == 0 )
				{
					
					parent.Display.location.href = "/DEPOSITORY/Reports/CAPS/PreprintedBill.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=" +BillNo.value +"&BranchID=" +BranchID.value +"&Type=Detail&PrintDate=" +PrintDate.value +"&ReportType=" +PaperSize.value +"&Title=" +title1 +title2 +"&RepID=" +ReportNo.value;
				}
				else
				{
					parent.Display.location.href = "/DEPOSITORY/Reports/CAPS/BillDetails.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=" +BillNo.value +"&BranchID=" +BranchID.value +"&Type=Detail&PrintDate=" +PrintDate.value +"&ReportType=" +PaperSize.value +"&Title=" +title1 +title2 +"&RepID=" +ReportNo.value;
				}	
			}
			if( Selection[1].checked )
			{
				title2 = "Summary";
				parent.Display.location.href = "/DEPOSITORY/Reports/CAPS/BillSummary.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=" +BillNo.value +"&BranchID=" +BranchID.value +"&Type=Summ&PrintDate=" +PrintDate.value +"&ReportType=" +PaperSize.value +"&Title=" +title1 +title2 +"&RepID=" +ReportNo.value;
			}
			if( Selection[2].checked )	
			{
				title2 = "Abs. Bill Summary";
				parent.Display.location.href = "/DEPOSITORY/Reports/CAPS/BillAbsSummary.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=" +BillNo.value +"&BranchID=" +BranchID.value +"&Type=AbsSumm&PrintDate=" +PrintDate.value +"&ReportType=" +PaperSize.value +"&Title=" +title2 +"&RepID=" +ReportNo.value;
			}
		}

		//*********************** REPORT 3: BROKERAGE **********************
		if( ReportNo.value == 3 )
		{
			if( ToDate.value == "" || ToDate.value.charAt(0) == " " )
			{
				toDate = FromDate.value;
			}
			else
			{
				toDate = ToDate.value;
			}

			if( Selection[0].checked )
			{
				parent.Display.location.href = "/DEPOSITORY/Reports/CAPS/BrokerageDetails.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&FromDate=" +FromDate.value +"&ToDate=" +toDate +"&FamilyGroup=" + FamilyGroup.value + "&FromClient=" +escape( FromClient.value ) +"&ToClient=&BranchID=" +BranchID.value +"&Type=Detail&PrintDate=" +PrintDate.value +"&RepID=" +ReportNo.value;
			}
			
			if( Selection[1].checked )
			{	
				//alert(escape( FromClient.value.substring(0,10) ))
				parent.Display.location.href = "/DEPOSITORY/Reports/CAPS/BrokerageSummary.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&FromDate=" +FromDate.value +"&ToDate=" +toDate +"&FamilyGroup=" + FamilyGroup.value + "&FromClient=" +escape( FromClient.value.substring(0, 750) ) +"&ToClient=&BranchID=" +BranchID.value +"&Type=Summary&PrintDate=" +PrintDate.value +"&RepID=" +ReportNo.value;
			}
			if( Selection[2].checked )
			{	
				//alert(escape( FromClient.value.substring(0,10) ))
				parent.Display.location.href = "/DEPOSITORY/Reports/CAPS/BrokerageAbsSummery.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&FromDate=" +FromDate.value +"&ToDate=" +toDate +"&FamilyGroup=" + FamilyGroup.value + "&FromClient=" +escape( FromClient.value.substring(0, 750) ) +"&ToClient=&BranchID=" +BranchID.value +"&Type=Abs&PrintDate=" +PrintDate.value +"&RepID=" +ReportNo.value;
			}
		}


		//************************ REPORT 4: EXPENSE ***********************
		if( ReportNo.value == 4 )
		{
			if( ToDate.value == "" || ToDate.value.charAt(0) == " " )
			{
				toDate = FromDate.value;
			}
			else
			{
				toDate = ToDate.value;
			}
			
			if( Selection[0].checked )
			{
				parent.Display.location.href = "/DEPOSITORY/Reports/CAPS/ExpenseDetails.cfm?COCD="+ COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&FromDate=" +FromDate.value +"&ToDate=" +toDate +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BranchID=" +BranchID.value +"&Type=Detail&PrintDate=" +PrintDate.value +"&RepID=" +ReportNo.value;
			}
			
			if( Selection[1].checked )
			{
				parent.Display.location.href = "/DEPOSITORY/Reports/CAPS/ExpenseSummary.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&FromDate=" +FromDate.value +"&ToDate=" +toDate +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BranchID=" +BranchID.value +"&Type=Summary&PrintDate=" +PrintDate.value +"&RepID=" +ReportNo.value;
			}
		}


		//******************* REPORT 5: STAMP-DUTY PAYABLE *****************
		if( ReportNo.value == 5 )
		{
			if( ToDate.value == "" || ToDate.value.charAt(0) == " " )
			{
				toDate = FromDate.value;
			}
			else
			{
				toDate = ToDate.value;
			}

			if( Selection[0].checked )
			{
				v = "";
			}
			else if( Selection[1].checked )
			{
				v = "Y";
			}
			else if( Selection[2].checked )
			{
				v = "N";
			}
			
			parent.Display.location.href = "/DEPOSITORY/Reports/CAPS/StampDutyPayable.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&FromDate=" +FromDate.value +"&ToDate=" +toDate +"&FromClient=" +v +"&BT=" +BT.value +"&ST=" +ST.value +"&BD=" +BD.value +"&SD=" +SD.value +"&PrintDate="+ PrintDate.value +"&RepID=" +ReportNo.value;
		}


		//********************* REPORT 6: NET POSITION *********************
		if( ReportNo.value == 6 )
		{
			if( Selection[0].checked )
			{
				parent.Display.location.href = "/DEPOSITORY/Reports/CAPS/NetPosition.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BranchID=" +BranchID.value +"&FromSymbol=" +escape( FromSymbol.value ) +"&ToSymbol=&Type=Clientwise&PrintDate=" +PrintDate.value +"&RepID=" +ReportNo.value;
			}
			if( Selection[1].checked )
			{
				parent.Display.location.href = "/DEPOSITORY/Reports/CAPS/NetPositionScripWise.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BranchID=" +BranchID.value +"&FromSymbol=" +escape( FromSymbol.value ) +"&ToSymbol=&Type=ScripWise&PrintDate=" +PrintDate.value +"&RepID=" +ReportNo.value;
			}
		}

		//********************* REPORT 7: JOBBER POSITION *********************
		if( ReportNo.value == 7 )
		{
			if( PrintSelection[0].checked )
			{
				PageSelection = "P"
			}
			else
			{
				PageSelection = "C"
			}
			
			parent.Display.location.href = "/DEPOSITORY/Reports/CAPS/JobberPosition.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&Mkt_Type=&Settlement_No=&FromDate=" +FromDate.value +"&ToDate=" +ToDate.value +"&TPER="+ Selection.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&JobberPerParam=" + JobberPerParam.value +"&PrintSelection=" + PageSelection +"&PrintDate=" +PrintDate.value +"&RepID=" +ReportNo.value;
		}

		//****************** REPORT 10: REMESHIRE BROKERAGE ****************
		if( ReportNo.value == 10 )
		{
			if( Selection[0].checked )
			{
				title2 = "Detail";
			}			
			if( Selection[1].checked )
			{
				title2 = "Summary";
			}
			if( Selection[2].checked )	
			{
				title2 = "AbsSummary";				
			}
			
			if( DispType[0].checked )
			{
				DType = "Y";
			}			
			if( DispType[1].checked )
			{
				DType = "N";
			}
			if( DispType[2].checked )	
			{
				DType = "";				
			}
			if ( Report_option[0].checked )
			{
				rpttype = "Remeshire";	
			}
			if ( Report_option[1].checked )
			{
				rpttype = "Client";	
			}			
			if( ToDate.value == "" || ToDate.value.charAt(0) == " " )
			{
				toDate = FromDate.value;
			}
			else
			{
				toDate = ToDate.value;
			}				
			if ( rpttype == "Remeshire")
			{
				parent.Display.location.href = "/DEPOSITORY/Reports/CAPS/RemeshireReport.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&Mkt_Type=&FromDate=" +FromDate.value +"&ToDate=" +toDate +"&PrintDate=" +PrintDate.value + "&RepType=" + title2 + "&DispType=" + DType + "&RemGroup=" + RemGroup.value +  "&RepID=" + ReportNo.value;
			}
			else if ( rpttype == "Client" )
			{
				if ( title2 == "AbsSummary" )
				{
					parent.Display.location.href = "/DEPOSITORY/Reports/CAPS/RemeshireReport.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&Mkt_Type=&FromDate=" +FromDate.value +"&ToDate=" +toDate +"&PrintDate=" +PrintDate.value + "&RepType=" + title2 + "&DispType=" + DType + "&RemGroup=" + RemGroup.value +  "&RepID=" + ReportNo.value;
				}
				else
				{
					
					parent.Display.location.href = "/DEPOSITORY/Reports/CAPS/Client_Remeshire.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&Mkt_Type=&FromDate=" +FromDate.value +"&ToDate=" +toDate +"&PrintDate=" +PrintDate.value + "&RepType=" + title2 + "&DispType=" + DType + "&RemGroup=" + RemGroup.value +  "&RepID=" + ReportNo.value;	
				}
			}				
		}


		//*********************** REPORT 11: SAUDA BOOK ********************
		if( ReportNo.value == 11 )
		{
			if( DateWise.checked )
			{
				rptType		=	"DateWise";
				mktType		=	"";
				setlNo		=	"";
				
				if( ToDate.value == "" || ToDate.value.charAt(0) == " " )
				{
					frDate	=	toDate	=	FromDate.value;
				}
				else
				{
					frDate	=	FromDate.value;
					toDate	=	ToDate.value;
				}
			}
			else
			{
				rptType		=	"SettlementWise";
				mktType		=	Mkt_Type.value;
				setlNo		=	Settlement_No.value;
				
				frDate		=	"";
				toDate		=	"";
			}
			
			parent.Display.location.href = "/DEPOSITORY/Reports/CAPS/TransRegParam.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&TypeOfRpt=" +rptType +"&Mkt_Type=" +mktType +"&Settlement_No=" +setlNo +"&FromDate=" +frDate +"&ToDate=" +toDate +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BranchID=" +BranchID.value +"&FromSymbol=" +escape( FromSymbol.value ) +"&ToSymbol=&Terminal="+ Terminal.value +"&PrintDate=" +PrintDate.value +"&RepID=" +ReportNo.value;
		}


		//*********************** REPORT 12: ANNUAL PROFIT OR LOSS ********************
		if( ReportNo.value == 12 )
		{
			
			
			if(Process.value == 'Yes')
			{
					parent.Display.location.href = "/DEPOSITORY/Reports/MIS/ClientPortFolioProcess.cfm"
			}
			else if(
				( 
					(escape( FromClient.value ) == "" || escape( FromClient.value ).charAt(0) == " " )
				&& 	(escape( FamilyGroup.value ) == "" || escape( FamilyGroup.value ).charAt(0) == " " )
				)
			  )		
			{
				alert( "Please enter 'Client ID'.\nOr\nPlease select 'Family Group Code'." );
			}
			else if (escape( ToDate.value ) == "" || escape( ToDate.value ).charAt(0) == " " )
			{
			 	alert( "Please enter 'To Date'" );
			}
			else
			{
				var vType;
				var CType;
				var ShowClRate = "N";
				
				if( chkClRate.checked )	ShowClRate = "Y";
				/*if( Selection[1].checked )	v = "2";*/
				v	=	"1";
				
				if (VType[0].checked)
				{
					vType = "D";
				}
				else if (VType[1].checked)
				{
				 	vType = "S";
				}
				
				if (ClType[0].checked)
				{
					CType = "ClientId";
				}
				else if (ClType[1].checked)
				{
					CType = "ClientId2";
				}
				
				parent.Display.location.href = "/DEPOSITORY/Reports/MIS/ClientPortFolio.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&FromDate=" +FromDate.value + "&ToDate=" + ToDate.value +"&FamilyGroup=" + FamilyGroup.value +"&FromClient=" +escape( FromClient.value ) +"&type=" +v +"&PrintDate=" +PrintDate.value +"&RepID=" +ReportNo.value +"&Selection=" + cmbSelection.value +"&ShowClRate=" + ShowClRate + "&VType=" + vType + "&ClType=" + CType;
			}
		}

		if( ReportNo.value == 34 )
		{
			if(
				( 
					(escape( FromClient.value ) == "" || escape( FromClient.value ).charAt(0) == " " )
				&& 	(escape( FamilyGroup.value ) == "" || escape( FamilyGroup.value ).charAt(0) == " " )
				)
			  )		
			{
				alert( "Please enter 'Client ID'.\nOr\nPlease select 'Family Group Code'." );
			}
			else
			{
				var vType;
				var CType;
				var ShowClRate = "N";
				
				if( chkClRate.checked )	ShowClRate = "Y";
				/*if( Selection[1].checked )	v = "2";*/
				v	=	"1";
				
				if (VType[0].checked)
				{
					vType = "D";
				}
				else if (VType[1].checked)
				{
				 	vType = "S";
				}
				parent.Display.location.href = "/DEPOSITORY/PROCESSDATA/PMS_ClientPortFolio.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value  +"&FamilyGroup=" + FamilyGroup.value +"&FromClient=" +escape( FromClient.value ) +"&type=" +v +"&PrintDate=" +PrintDate.value +"&RepID=" +ReportNo.value +"&Selection=" + cmbSelection.value +"&ShowClRate=" + ShowClRate + "&VType=" + vType + "&ClType=" + CType;

			}
		}
		
		if( ReportNo.value == 35 )
		{
			if( ToDate.value == "" || ToDate.value.charAt(0) == " " )
			{
				toDate = FromDate.value;
			}
			else
			{
				toDate = ToDate.value;
			}
			
			if(optAction[0].checked)
			{
				action = 'B';
			}
			else if(optAction[1].checked)
			{
				action = 'S';
			}
			else if(optAction[2].checked)
			{
				action = 'M';
			}
			else if(optAction[3].checked)
			{
				action = 'D';
			}
			
			parent.Display.location.href	=	"/DEPOSITORY/Reports/Caps/Corporate_Action.cfm?COCD="+COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Branch=" +BranchID.value +"&FromDate=" + FromDate.value +"&ToDate="+ ToDate.value +"&RepID="+ ReportNo.value +"&BranchID=" + BranchID.value +"&FamilyGroup=" + FamilyGroup.value + "&ScripList=" + escape( FromSymbol.value ) + "&Action=" + action + "&Ben=" + CmbBenCode.value + "&FinStart=" + FinStart.value + "&FinEnd=" + FinEnd.value;
		}
		//*********************** REPORT 13: MULTI-REPORT ********************
		if( ReportNo.value == 13 )
		{
			if( ToDate.value == "" || ToDate.value.charAt(0) == " " )
			{
				toDate = FromDate.value;
			}
			else
			{
				toDate = ToDate.value;
			}
			
			parent.Display.location.href = "/DEPOSITORY/Reports/CAPS/MultiReportParams.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&FromDate=" +FromDate.value +"&ToDate=" +toDate +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BranchID=" +BranchID.value +"&PrintDate=" +PrintDate.value +"&RepID=" +ReportNo.value;
		}

		//*********************** REPORT 14: CONTRACT-REGISTER ********************
		if( ReportNo.value == 14 )
		{
			if( ToDate.value == "" || ToDate.value.charAt(0) == " " )
			{
				toDate = FromDate.value;
			}
			else
			{
				toDate = ToDate.value;
			}
			
			if( DateWise.checked )
			{
				rptType		=	"DateWise";
				mktType		=	"";
				setlNo		=	"";
				
				if( ToDate.value == "" || ToDate.value.charAt(0) == " " )
				{
					frDate	=	toDate	=	FromDate.value;
				}
				else
				{
					frDate	=	FromDate.value;
					toDate	=	ToDate.value;
				}
			}
			else
			{	
				rptType		=	"SettlementWise";
				mktType		=	Mkt_Type.value;
				setlNo		=	Settlement_No.value;
				
				frDate		=	"";
				toDate		=	"";
			}
			
			if (DisplayType[0].checked)
			{
			 	dispType	=	"Family";
			}
			else
			{
			 	dispType	=	"Contract";
			}
			
			parent.Display.location.href = "/DEPOSITORY/Reports/CAPS/ContractRegister.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&Mkt_type=" + mktType +"&Settlement_No=" + setlNo +"&FromDate=" +frDate +"&ToDate=" +toDate +"&FromClient=" +escape( FromClient.value ) +"&Order=" + dispType + "&BranchID=&PrintDate=" +PrintDate.value +"&RepID=" +ReportNo.value;
		}


		//*********************** REPORT 15: BILL-JV DATA ********************
		if( ReportNo.value == 15 )
		{
			parent.Display.location.href = "/DEPOSITORY/Reports/CAPS/ViewBillForm.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&Mkt_type=" + Mkt_Type.value +"&Settlement_No=" + Settlement_No.value +"&Ok=Yes&BranchID=&PrintDate=" +PrintDate.value +"&RepID=" +ReportNo.value;
		}


		//*********************** REPORT 20: CLIENT BALANCE ********************
		if( ReportNo.value == 20 )
		{
			parent.Display.location.href = "/DEPOSITORY/REPORTS/MIS/ClientBalance.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value + "&FROM_CLIENT=" + escape( FromClient.value ) + "&BILL_DATE=" + FromDate.value +"&BranchID=&PrintDate=" +PrintDate.value +"&RepID=" +ReportNo.value;
		}
	
		//*********************** REPORT 44: WELCOME REPORT********************
		if( ReportNo.value == 44 )
		{
			parent.Display.location.href = "/DEPOSITORY/Reports/CAPS/WelComeReport.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value + "&FROM_CLIENT=" + escape( FromClient.value ) + "&From_DATE=" + FromDate.value + "&FromClient=" +escape( FromClient.value )+"&BranchID=&PrintDate=" +PrintDate.value + "&To_DATE=" + ToDate.value +"&RepID=" +ReportNo.value ;
		}

		//*********************** REPORT 21: MIS Net Brokerage ********************
		if( ReportNo.value == 21 )
		{
			var coList;
			
			for (i = 1; i <= Company_Count.value; i++)
			{
			 	if ( eval("chk" + i).checked )
				{
					coList	=	coList + "," + eval("chk" + i).value;	
					
				}
			}
			
			if (RPTType[1].checked)
			{
				if ( Selection[0].checked )
				{
					parent.Display.location.href = "/DEPOSITORY/REPORTS/MIS/NetBrokerage.cfm?COGROUP=" + COGROUP.value + "&COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value + "&Company_List=" + coList +"&FROM_CLIENT=" + escape( FromClient.value ) + "&FROM_DATE=" + FromDate.value + "&TO_DATE=" + ToDate.value +"&BranchID=&PrintDate=" +PrintDate.value +"&RepID=" +ReportNo.value;
				}
				else
				{
					parent.Display.location.href = "/DEPOSITORY/REPORTS/MIS/NetBrokerageSummary.cfm?RPTType=Clientwise&COGROUP=" + COGROUP.value + "&COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value + "&Company_List=" + coList +"&FROM_CLIENT=" + escape( FromClient.value ) + "&FROM_DATE=" + FromDate.value + "&TO_DATE=" + ToDate.value +"&BranchID=&PrintDate=" +PrintDate.value +"&RepID=" +ReportNo.value;
				}
			}
			else
			{
				parent.Display.location.href = "/DEPOSITORY/REPORTS/MIS/NetBrokerageSummary.cfm?RPTType=Companywise&COGROUP=" + COGROUP.value + "&COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value + "&Company_List=" + coList +"&FROM_CLIENT=" + escape( FromClient.value ) + "&FROM_DATE=" + FromDate.value + "&TO_DATE=" + ToDate.value +"&DispType=" + CmbFormat.value +"&BranchID=&PrintDate=" +PrintDate.value +"&RepID=" +ReportNo.value;
			}	
		}


		//*********************** REPORT 22: MIS Brokerage Status ********************
		if( ReportNo.value == 22 )
		{
			if( Selection[0].checked )	v = "D";
			if( Selection[1].checked )	v = "M";
			if( Selection[2].checked )	v = "Q";
			if( Selection[3].checked )	v = "Y";

			parent.Display.location.href = "/DEPOSITORY/REPORTS/MIS/BrokerageStatus.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value + "&FROM_CLIENT=" + escape( FromClient.value ) + "&FROM_DATE=" + FromDate.value + "&TO_DATE=" + ToDate.value + "&TYPE=" + v +"&BranchID=&PrintDate=" +PrintDate.value +"&RepID=" +ReportNo.value;
		}


		//******************* REPORT 23: STAMP-DUTY PAYABLE *****************
		if( ReportNo.value == 23 )
		{
			if( PeriodSelection[0].checked )
			{
				parent.Display.location.href = "/DEPOSITORY/Reports/CAPS/StampDuty.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&FromDate=" +CmbPeriod.value +"&ClientSelection=" +ClientSelection.value +"&Trd=" +Trading.value +"&Del=" +Delivery.value + "&Branch=" + BranchList.value +"&PrintDate="+ PrintDate.value + "&Branch=" + BranchList.value +"&Mkt_Type="+ TXTMKTTYPE.value +"&RepID=" +ReportNo.value;
			}
			if( PeriodSelection[1].checked )
			{ 
				if( ToDate.value == "" || ToDate.value.charAt(0) == " " )
				{
					toDate = FromDate.value;
				}
				else
				{
					toDate = ToDate.value;
				}
				parent.Display.location.href = "/DEPOSITORY/Reports/CAPS/StampDuty.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&FromDate=" +FromDate.value + "," + toDate +"&ToDate=" +toDate +"&ClientSelection=" +ClientSelection.value +"&Trd=" +Trading.value +"&Del=" +Delivery.value + "&Branch=" + BranchList.value +"&PrintDate="+ PrintDate.value +"&Mkt_Type="+ TXTMKTTYPE.value +"&RepID=" +ReportNo.value;
			}
		}


		//******************* REPORT 24: SERVICE-TAX PAYABLE *****************
		if( ReportNo.value == 24 )
		{
			if( PeriodSelection[0].checked )
			{
				periodSelection	=	PeriodSelection[0].value;
				monthDate		=	CmbPeriod.value;
				
				frDate			=	"";
				toDate			=	"";
			}
			else if( PeriodSelection[1].checked )
			{
				periodSelection	=	PeriodSelection[1].value;
				monthDate		=	"";
				
				if( ToDate.value == "" || ToDate.value.charAt(0) == " " )
				{
					frDate		=	FromDate.value;
					toDate		=	FromDate.value;
				}
				else
				{
					frDate		=	FromDate.value;
					toDate		=	ToDate.value;
				}
			}
			
			if( ShowOptionalCols.checked )
			{
				showOptionalCols	=	"Y";
			}
			else
			{
				showOptionalCols	=	"N";
			}
			
			if( ShowRefundBrk.checked )
			{
				showRefCols	=	"Y";
			}
			else
			{
				showRefCols	=	"N";
			}
			
			parent.Display.location.href	=	"/DEPOSITORY/Reports/ServiceTaxPayable.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&PeriodSelection=" +periodSelection +"&MonthDate=" +monthDate +"&FromDate=" +frDate +"&ToDate=" +toDate +"&ClientSelection=" +ClientSelection.value +"&ShowOptionalCols=" +showOptionalCols +"&ShowRefundCols=" + showRefCols + "&PrintDate=" +PrintDate.value + "&Branch=" + BranchList.value +"&RepID=" +ReportNo.value;
		}


		//*********************** REPORT 26: STT **********************
		if( ReportNo.value == 26 )
		{
			if( ToDate.value == "" || ToDate.value.charAt(0) == " " )
			{
				toDate = FromDate.value;
			}
			else
			{
				toDate = ToDate.value;
			}

			parent.Display.location.href = "/DEPOSITORY/Reports/CAPS/STTMisMatchReport.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&FromClient=" +escape( FromClient.value ) +"&FromDate=" +FromDate.value +"&ToDate=" +toDate +"&STTDifference=" +STTDifference.value +"&ToClient=&PrintDate=" +PrintDate.value +"&RepID=" +ReportNo.value;
		}

		//*********************** REPORT 27 STT Mismatch **********************
		if( ReportNo.value == 27 )
		{
			if (DispType[0].checked)
			{
				rptType	=	"";
			}	
			else if (DispType[1].checked)
			{
				rptType = "Match";
			}
			else if (DispType[2].checked)
			{
				rptType = "MisMatch";
			}
			parent.Display.location.href = "/DEPOSITORY/Reports/CAPS/STTMisMatchReport.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&FromClient=" +escape( FromClient.value ) +"&FromDate=" +FromDate.value +"DispType="+ rptType + "&PrintDate=" +PrintDate.value +"&RepID=" +ReportNo.value;
		}
		//*************************** REPORT 28 Exchange Obligation***********************
		if( ReportNo.value == 28 )
		{
			mktType		=	Mkt_Type.value;
			setlNo		=	Settlement_No.value;
				
			parent.Display.location.href = "/DEPOSITORY/Reports/CAPS/CheckExchangeObligation.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&Mkt_type=" + mktType +"&Settlement_No=" + setlNo +"&BranchID=&PrintDate=" +PrintDate.value +"&RepID=" +ReportNo.value;
		}
		
		if( ReportNo.value == 29 )
		{
			if ( ExposurePer.value == 0 || ExposurePer.value.length == 0 )
			{
				alert("Please Enter the Correct Exposure Value");				
				ExposurePer.focus();
			}
			else
			{
				parent.Display.location.href	=	"/DEPOSITORY/Reports/Caps/BulkDeal.cfm?COCD="+COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&FromDate=" + FromDate.value +"&Exposure="+ ExposurePer.value;
			}
		}
		if( ReportNo.value == 30 )
		{
			parent.Display.location.href	=	"/DEPOSITORY/Reports/Caps/Turnover.cfm?COCD="+COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&FromDate=" + FromDate.value +"&ToDate="+ ToDate.value +"&RepID="+ ReportNo.value +"&BranchID=" + BranchID.value +"&FromClient="+FromClient.value ;
		}
		
		//*********************** REPORT 21: MIS Net Brokerage ********************
		if( ReportNo.value == 31 )
		{
			var coList;
			
			for (i = 1; i <= Company_Count.value; i++)
			{
			 	if ( eval("chk" + i).checked )
				{
					coList	=	coList + "," + eval("chk" + i).value;	 	
				}
			}
			
			if( DispType[0].checked )
			{
				Remeshire_Type = "Y";
			}			
			if( DispType[1].checked )
			{
				Remeshire_Type = "N";
			}
			if( DispType[2].checked )	
			{
				Remeshire_Type = "";
			}

			if ( Selection[0].checked )
			{
				reportType	=	"Datewise";
			}
			else if ( Selection[1].checked )
			{
				reportType	=	"Monthwise";
			}
			else if ( Selection[2].checked )
			{
				reportType	=	"Summary";
			}
				parent.Display.location.href = "/DEPOSITORY/REPORTS/MIS/MISBrokerage.cfm?COGROUP=" + COGROUP.value + "&COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value + "&Company_List=" + coList +"&FROM_CLIENT=" + escape( FromClient.value ) + "&FROM_DATE=" + FromDate.value + "&TO_DATE=" + ToDate.value +"&DispType=" + reportType +"&Remeshire_Type=" + Remeshire_Type +"&BranchID=" + BranchID.value +"&PrintDate=" +PrintDate.value +"&RepID=" +ReportNo.value;
				
		}
		
		//*********************** REPORT 32: MIS Net Balance ********************
		if( ReportNo.value == 32 )
		{
			var coList;
			
			for (i = 1; i <= Company_Count.value; i++)
			{
			 	if ( eval("chk" + i).checked )
				{
					coList	=	coList + "," + eval("chk" + i).value;	 	
				}
			}
			
			if ( FOClAmtOption[0].checked )
			{
				FOClColAmt	=	"Closing_Amt";
			}
			else
			{
				FOClColAmt	=	"Day_FODue_Amount";
			}
			
			processData	=	"No";
			if( Process.value == "Yes" )
			{
				processData	=	"Yes";
			}
			
			parent.Display.location.href = "/DEPOSITORY/REPORTS/MIS/MISFaBalance.cfm?COGROUP=" + COGROUP.value + "&COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Company_List=" + coList +"&FROM_CLIENT=" + escape( FromClient.value ) + "&FROM_DATE=" + FromDate.value + "&Process=" + processData +"&DrCrFilter=" + cmbDrCrFilter.value + "&FilterBy=" + cmbFilter.value +"&Filtervalue=" + txtFilter.value +"&FOClColAmt=" + FOClColAmt +"&BranchID=" + BranchID.value +"&PrintDate=" +PrintDate.value +"&RepID=" +ReportNo.value;
		}
		if( ReportNo.value == 33 )
		{
			parent.Display.location.href = "/DEPOSITORY/REPORTS/caps/LablePrint.cfm?COCD="+COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&RepID="+ ReportNo.value +"&BranchID=" + BranchID.value +"&FromClient="+FromClient.value ;;
		}
		if( ReportNo.value == 36 )
		{
			parent.Display.location.href = "/DEPOSITORY/REPORTS/caps/StampDutyFormA.cfm?COCD="+COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&RepID="+ ReportNo.value+"&FromDate=" + FromDate.value +"&ToDate="+ ToDate.value + "&MktType=" + TXTMKTTYPE.value;
		}
		if( ReportNo.value == 37 )
		{
			parent.Display.location.href = "/DEPOSITORY/Reports/MIS/ClientAnnualPL.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&FromDate=" +FromDate.value + "&ToDate=" + ToDate.value +"&FamilyGroup=" + FamilyGroup.value +"&FromClient=" +escape( FromClient.value ) +"&RepID=" +ReportNo.value+"&txtNotes="+txtNotes.value+"&txtNotes1="+txtNotes1.value;
		}
		if( ReportNo.value == 42 )
		{
			parent.Display.location.href = "/DEPOSITORY/Reports/MIS/VallanSummary.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&FromDate=" +FromDate.value + "&RepID=" +ReportNo.value;
		}
		if( ReportNo.value == 43 )
		{
			var coList,s;
			for (i = 1; i <= Company_Count.value; i++)
			{
			 	if ( eval("chk" + i).checked )
				{
					coList	=	coList + "," + eval("chk" + i).value;	
					
				}
			}
			s= 'S'; 
			for (i = 0; i <= 4; i++)
			{
				
			 	if (Selection[i].checked)
				{
					s= Selection[i].value;
				}
			}
			parent.Display.location.href = "/DEPOSITORY/Reports/MIS/BrokerReport.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&FromDate=" +FromDate.value +  "&ToDate=" + ToDate.value +"&RepID=" +ReportNo.value+"&Selection=" +s+"&Company_List="+coList;
		}

	}
}


function emailReports( form )
{
	if( confirm( "Do you want to add any additional information to the E-Mail Message?." ) )
	{
		mailMsg = prompt( "Enter your Message.", "" );
		
		if( ( mailMsg != null ) && ( mailMsg != "" ) && ( mailMsg.charAt(0) != " " ) )
		{
			mailMsg = mailMsg;
		}
		else
		{
			mailMsg = "";
		}
	}
	else
	{
		mailMsg = "";
	}
	
	with( form )
	{
		msg.value = "Please wait ....";

		//************************ REPORT 1: CONTRACT **********************
		if( ReportNo.value == 1 )
		{
			title1 = "Trade Done ";
			
			if( Selection[0].checked )
			{
				title2 = "Detail";
				parent.Display.location.href = "/DEPOSITORY/Reports/ContractMail.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&Trade_Date=&FromClient=" +escape( FromClient.value ) +"&ToClient=&ContractNo=" +ContractNo.value +"&BranchID=" +BranchID.value +"&Type=Detail&PrintDate=" +PrintDate.value +"&ReportType=" +PaperSize.value +"&Title=" +title1 +title2 +"&RepID=" +ReportNo.value +"&EMail=Yes&MessageType=EMail&MailMessage=" +mailMsg;
			}
			if( Selection[1].checked )
			{
				title2 = "Summary";
				parent.Display.location.href = "/DEPOSITORY/Reports/ContractMail.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&Trade_Date=&FromClient=" +escape( FromClient.value ) +"&ToClient=&ContractNo=" +ContractNo.value +"&BranchID=" +BranchID.value +"&Type=Summ&PrintDate=" +PrintDate.value +"&ReportType=" +PaperSize.value +"&Title=" +title1 +title2 +"&RepID=" +ReportNo.value +"&EMail=Yes&MessageType=EMail&MailMessage=" +mailMsg;
			}
		}


		//************************** REPORT 2: BILL ************************
		if( ReportNo.value == 2 )
		{
			title1 = "Bill ";
			
			if( Selection[0].checked )
			{
				title2 = "Detail";
				parent.Display.location.href = "/DEPOSITORY/Reports/BillMail.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=" +BillNo.value +"&BranchID=" +BranchID.value +"&Type=Detail&PrintDate=" +PrintDate.value +"&ReportType=" +PaperSize.value +"&Title=" +title1 +title2 +"&RepID=" +ReportNo.value +"&EMail=Yes&MessageType=EMail&MailMessage=" +mailMsg;
			}
			if( Selection[1].checked )
			{
				title2 = "Summary";
				parent.Display.location.href = "/DEPOSITORY/Reports/BillMail.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=" +BillNo.value +"&BranchID=" +BranchID.value +"&Type=Summ&PrintDate=" +PrintDate.value +"&ReportType=" +PaperSize.value +"&Title=" +title1 +title2 +"&RepID=" +ReportNo.value +"&EMail=Yes&MessageType=EMail&MailMessage=" +mailMsg;
			}
			if( Selection[2].checked )
			{
				title2 = "Absolute Summary";
				parent.Display.location.href = "/DEPOSITORY/Reports/BillMail.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=" +BillNo.value +"&BranchID=" +BranchID.value +"&Type=AbsSumm&PrintDate=" +PrintDate.value +"&ReportType=" +PaperSize.value +"&Title=" +title1 +title2 +"&RepID=" +ReportNo.value +"&EMail=Yes&MessageType=EMail&MailMessage=" +mailMsg;
			}
		}
	}
}


function smsReports( form )
{
	with( form )
	{
		//************************** REPORT 2: BILL ************************
		if( ReportNo.value == 2 )
		{
			title = "Bill Absolute Summary";
			
			if( Selection[2].checked )
			{
				parent.Display.location.href = "/DEPOSITORY/Reports/CAPS/BillAbsSMS.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=" +Branch.value +"&Mkt_Type=" +Mkt_Type.value +"&Settlement_No=" +Settlement_No.value +"&FromClient=" +escape( FromClient.value ) +"&ToClient=&BillNo=" +BillNo.value +"&BranchID=" +BranchID.value +"&Type=AbsSumm&PrintDate=" +PrintDate.value +"&ReportType=" +PaperSize.value +"&Title=" +title +"&RepID=" +ReportNo.value +"&EMail=Yes&MessageType=SMS";
			}
		}
	}
}