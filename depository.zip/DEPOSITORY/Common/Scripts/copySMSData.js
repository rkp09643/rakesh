function openReports()
{
	with (SMSReport)
	{
		DrCrFilter.disabled = false;
		action='SMSReport.cfm';	
	}
}

function setObjects(rptID)
{
	with (SMSReport)
	{
		setFilterObject(rptID);
		
	}
}




function setFilterObject(rptID)
{
	with(SMSReport)
	{
		if (rptID != 1 )
		{	
			DrCrFilter.disabled=true;
			FilterBy.disabled=true;
			Filtervalue.disabled=true;
		}
		else
		{	
			DrCrFilter.disabled=false;
			FilterBy.disabled=false;
			Filtervalue.disabled=false;
		}
		if (rptID != 2 )
		{	
			Suada.disabled=true;
		}
		else
		{	
			Suada.disabled=false;
		}
		if (rptID != 5 )
		{	
			SendOpt.disabled = true;
		}
		else
		{	
			SendOpt.disabled = false;
		}
		if (rptID != 6 )
		{	
			FromAmt.disabled = true;
			ToAmt.disabled = true;
		}
		else
		{	
			FromAmt.disabled = false;
			ToAmt.disabled = false;
		}
		
	}
}
