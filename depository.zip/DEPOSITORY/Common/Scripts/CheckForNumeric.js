/* #####################################################################################
					JAVASCRIPT FILE FOR VALIDATING THE NUMERIC FORM FIELDS.
##################################################################################### */


/* *********************************************************
		FUNCTION FOR VALIDATING NUMERIC FORM FIELDS.
********************************************************* */
function chkForValidNumber( formObj, fieldObj, fieldName, fieldValue, fieldType, allowNegative, isPer, setZero, allowZero, ToDel, Deld, HQty )
{
	with( formObj )
	{
		if ( HQty != "" )
		{
			if ( parseInt(fieldValue) > parseInt(HQty) )
			{
				alert("Quantity assigned cannot be more then Hold Qty !!!");
				fieldObj.value	=	"";
				fieldObj.focus ();
			}
		}		
		if ( parseInt(fieldValue) > (ToDel - Deld) )
		{
			alert("Quantity assigned cannot be more then (Qty To Deliver - Delivered Qty) !!!");
			fieldObj.value	=	"";
			fieldObj.focus ();
		}
		
		// CHECK FIELD VALUE IS NUMERIC OR NOT, IF VALUE IS NOT EMPTY.
		if( ( fieldValue == "" ) || ( fieldValue.charAt(0) == " " ) )
		{
			fieldObj.value	=	"";
		}
		// CHECK FIELD VALUE IS NUMERIC OR NOT, IF VALUE IS NOT EMPTY.
		else if( fieldValue != "" )
		{
			fieldValue		=	new Number( fieldValue );
			
			if( fieldType == "Integer" )
			{
				fieldValue	=	parseInt( fieldValue );
				fieldType	=	"an Integer Number.";
			}
			else if( fieldType == "Float" )
			{
				fieldValue	=	parseFloat( fieldValue );
				fieldType	=	"a Float Number.";
			}
			
			// IF FIELD VALUE IS NOT NUMERIC, THEN ALERT THE USER.
			if( isNaN( fieldValue ) )
			{
				alert( "'" +fieldName +"' should be " +fieldType );
				fieldObj.value	=	"";
				fieldObj.focus ();
				
				return false;
			}
			// IF FIELD VALUE IS NUMERIC, THEN CHECK FOR THE FIELD VALIDITY.
			else
			{
				fieldObj.value	=	fieldValue;
				
				if( isPer == "Yes" && ( fieldValue < 0 || fieldValue > 100 ) )
				{
					// CHECK FOR FIELD VALUE, IT SHOULD BE BETWEEN 0 AND 100( POSITIVE PERCENTAGE ).
					alert( "'" +fieldName +"' should be between 0 and 100." );
					if( setZero == "No" )
					{
						fieldObj.value	=	"";
					}
					else
					{
						fieldObj.value	=	0;
					}
					fieldObj.focus ();
				}
				else
				{
					if( allowNegative == "Yes" && fieldValue > 0 )
					{
						// CHECK FOR FIELD "Quantity", IT SHOULD BE POSITIVE VALUE.
						alert( "'" +fieldName +"' should be a Positive value." );
						fieldObj.value	=	Math.abs( fieldValue );
						fieldObj.focus ();
					}
					
					if( allowZero == "No" && fieldValue == 0 )
					{
						// CHECK FOR FIELD VALUE, IT SHOULD NOT BE ZERO.
						alert( "'" +fieldName +"' should be greater than zero." );
						fieldObj.value	=	"";
						fieldObj.focus ();
					}
				}
			}
		}
	}
}