/* ****************************************************************
	FUNCTION FOR HIDING AND SHOWING THE STOCK POOL ACC DETAILS.
**************************************************************** */
function setOnLoad( form )
{
	with( form )
	{
		COCD.focus();
		CompanyGroupList.style.display	=	"None";
		CoGrpName.readOnly				=	true;
		CoGrpName.style.background		=	"Transparent";
		CoGrpName.style.color			=	"Purple";
		
		
		showHideHelps( "Body" );
	}
}


/* ****************************************************************
	FUNCTION FOR HIDING AND SHOWING THE STOCK POOL ACC DETAILS.
**************************************************************** */

/* ******************************************************************************************
	FUNCTION FOR VALIDATING THE COMPANY GROUP ENTERED AND SETTING THE COMPANY GROUP-NAME.
****************************************************************************************** */
/*********************************************
	Set FA Posting Code / Name
***********************************************/
function setPostingCode(form)
{
	with(form)
	{
		if(COCD.value.charAt(0).toUpperCase() == 'C' || COCD.value.charAt(0).toUpperCase() == 'N')
		{
			FAPostingCOCD.value = COCD.value;
			FAPostingCoName.value = CoName.value;
		}
		else
		{
			alert("Please Enter Company Code Starting with 'C' For CDSL or 'N' For NSDL");
			COCD.value = ""
			FAPostingCOCD.value = "";
			FAPostingCoName.value = "";
		}
	}
}

function setPostingName(form)
{
	with(form)
	{
		
			FAPostingCOCD.value = COCD.value;
			FAPostingCoName.value = CoName.value;
	}
}

/*-------------- Validation -----------------*/
function populateMyValues(form, populateFor, value,count, isin)
{
	with( form )
	{
		FormObject = "parent.document." + form.name;
		HideAndShow.location.href = "Validation/GetValue.cfm?FormObj=" + FormObject + "&PopFor=" + populateFor +"&Refvalue=" + value + "&Count=" + count + "&isin=" + isin;
	}
}



function chkCompanyGroup( form, compCnt )
{
	with( form )
	{
		coGrpCode	=	CoGrpCode.value;
		
		if( ( coGrpCode != "" ) && ( coGrpCode.charAt(0) != " " ) )
		{
			if( compCnt = "0" )
			{
				frameObj	=	"NewCompanyValidates";
				formObj		=	"parent.document.NewCompany";
			}
			else
			{
				frameObj	=	"parent.fraPaneBar";
				formObj		=	"parent.Display.document.NewCompany";
			}
			
			eval( frameObj ).location.href	=	"/DEPOSITORY/DynamicFrame/Fra_Hide.cfm?ValidateCompanyGroup=Yes&DocFormObject=" +formObj +"&CoGrpCode=" +coGrpCode;
		}
		else
		{
			CoGrpName.value					=	"";
		}
	}
}


/* ********************************************************************
	FUNCTION FOR SETTING THE FA-COMPANY CODE & NAME IF IT IS EMPTY.
******************************************************************** */
function setFACompany( form, objValue )
{
	with( form )
	{
		
		if(COCD.value.charAt(0) == 'C')
		{
			//alert(FAPostingCOCD.value.charAt(0).toUpperCase());
			if(!(FAPostingCOCD.value.charAt(0).toUpperCase() == 'C'))
			{
				alert("Please Enter FA Posting Code Star with 'C'");
				FAPostingCOCD.value = "";
				return false;
			}
		}
		if(COCD.value.charAt(0) == 'N')
		{
			if(!(FAPostingCOCD.value.charAt(0).toUpperCase() == 'N'))
			{
				alert("Please Enter FA Posting Code Star with 'N'");
				FAPostingCOCD.value = "";
				return false;
			}
		}
		
		if(!(FAPostingCOCD.value.charAt(0) == 'C' || FAPostingCOCD.value.charAt(0) == 'N'))
		{
			FAPostingCOCD.value = "";
			return false;
		}
		
		if( ( COCD.value != "" && COCD.value.charAt(0) != " " ) && ( objValue == "" || objValue.charAt(0) == " " ) )
		{
			if( confirm( "You have not entered any value for 'FA Company Code', \nthis would set FA Company Code & Name same as Trading Company Code & Name\nDo you want to do so?" ) )
			{
				FAPostingCOCD.value		=	COCD.value;
				FAPostingCoName.value	=	CoName.value;
				
				if( CoName.value != "" && CoName.value.charAt(0) != " " )
				{
					if( CAPS.checked )
					{
						CDSLPoolAccCode.focus();
					}
					else if( FO.checked )
					{
						FinStart.focus();
					}
				}
				else
				{
					FAPostingCoName.focus();
				}
			}
			else
			{
				FAPostingCoName.value	=	"";
				FAPostingCoName.focus();
			}
		}
	}
}


/* ***********************************************************
	FUNCTION FOR CHANGING THE END-YEAR WHEN START CHANGES.
*********************************************************** */
function chkFinStartYear( form, currYear )
{
	with( form )
	{
		finStart = FinStart.value;
		if( ( finStart != "" ) && ( finStart.charAt(0) != " " ) )
		{
			finStart	=	parseInt( finStart );
			
			if( isNaN( finStart ) )
			{
				alert( "Please enter a Numeric Value." );
				FinStart.value	=	parseInt( currYear );
				FinStart.focus();
			}
			else
			{
				FinEnd.value	=	( finStart + 1 );
				StartDate.focus();
			}
		}
	}
}


/* **********************************************************************************
	FUNCTION TO CHECK THE CLEARING-MEMBER CODE, IT SHOULD BE SAME AS BROKER-CODE.
********************************************************************************** */
function chkCMCode( form, obj )
{
	with( form )
	{
		cmCode		=	new String( obj.value ).toUpperCase();
		brokerCode	=	new String( BrokerCode.value ).toUpperCase();
		
		if( ( cmCode != "" ) && ( cmCode.charAt(0) != " " ) )
		{
			if( cmCode == brokerCode )
			{
				alert( "This Code is already used by Broker-A/c, \nso please change Clearing-Member Code." );
				obj.value	=	"";
				obj.focus();
			}
		}
	}
}


/* *************************************************************************
	FUNCTION FOR VALIDATING EMPTY FORM FIELDS BEFORE SUBMITING THE FORM.
************************************************************************* */
function chkForEmptyFields( form )
{
	with( form )
	{
		if(COCD.value=='' || COCD.value.length==0 || COCD.value.charAt(0)==' ')
		{
			alert("Please Insert  Company Code Properly!!!")
			return false;
		}
		if(CoName.value=='' || CoName.value.length==0 || CoName.value.charAt(0)==' ')
		{
			alert("Please Insert  Company Name Properly!!!")
			return false;
		}
		if(CoGrpCode.value=='' || CoGrpCode.value.length==0 || CoGrpCode.value.charAt(0)==' ')
		{
			alert("Please Insert  Company Group Code Properly!!!")
			return false;
		}
		if(CoGrpName.value=='' || CoGrpName.value.length==0 || CoGrpName.value.charAt(0)==' ')
		{
			alert("Please Insert  Company Group Name Properly!!!")
			return false;
		}
		if(FAPostingCOCD.value=='' || FAPostingCOCD.value.length==0 || FAPostingCOCD.value.charAt(0)==' ')
		{
			alert("Please Insert  FA Posting CODE Properly!!!")
			return false;
		}
		if(FAPostingCoName.value=='' || FAPostingCoName.value.length==0 || FAPostingCoName.value.charAt(0)==' ')
		{
			alert("Please Insert  FA Posting Company Name Properly!!!")
			return false;
		}
		if(DPID.value=='' || DPID.value.length==0 || DPID.value.charAt(0)==' ')
		{
			alert("Please Insert  DP ID Properly!!!")
			return false;
		}
		if(CDSLOperatorID.value=='' || CDSLOperatorID.value.length==0 || CDSLOperatorID.value.charAt(0)==' ')
		{
			alert("Please Insert  CDSL Operator ID Properly!!!")
			return false;
		}
		if(DepoId.value=='' || DepoId.value.length==0 || DepoId.value.charAt(0)==' ')
		{
			alert("Please Insert  Depository Id Properly!!!")
			return false;
		}
		if(FinStart.value=='' || FinStart.value.length==0 || FinStart.value.charAt(0)==' ')
		{
			alert("Please Insert Financial Year Start Properly!!!")
			return false;
		}
		if(FinEnd.value=='' || FinEnd.value.length==0 || FinEnd.value.charAt(0)==' ')
		{
			alert("Please Insert Financial Year End Properly!!!")
			return false;
		}
		if(StartDate.value=='' || StartDate.value.length==0 || StartDate.value.charAt(0)==' ')
		{
			alert("Please Insert Financial Start Date Properly!!!")
			return false;
		}
		if(EndDate.value=='' || EndDate.value.length==0 || EndDate.value.charAt(0)==' ')
		{
			alert("Please Insert Financial End Date Properly!!!")
			return false;
		}
		
	}
}


/* **********************************************************
	FUNCTION FOR HIDING/SHOWING USER HELPS WHEN REQUIRED.
********************************************************** */
function showHideHelps( obj )
{
	if( obj == "Body" )
	{
		MainHelp.style.display = "";		
		COCDHelp.style.display ="None";			CoNameHelp.style.display ="None";
		CoGrpCodeHelp.style.display ="None";
		ExchangeHelp.style.display ="None";
		MarketHelp.style.display ="None";
		BrokerHelp.style.display ="None";
		FACOCDHelp.style.display ="None";		FACoNameHelp.style.display ="None";
		IOPoolAccHelp.style.display ="None";
		YearHelp.style.display = "None";		SettingHelp.style.display = "None";
	}
	else if( obj.name == "COCD" )
	{
		MainHelp.style.display = "";		
		COCDHelp.style.display ="";				CoNameHelp.style.display ="None";
		CoGrpCodeHelp.style.display ="None";
		ExchangeHelp.style.display ="None";
		MarketHelp.style.display ="None";
		BrokerHelp.style.display ="None";
		FACOCDHelp.style.display ="None";		FACoNameHelp.style.display ="None";
		IOPoolAccHelp.style.display ="None";
		YearHelp.style.display = "None";		SettingHelp.style.display = "None";
	}
	else if( obj.name == "CoName" )
	{
		MainHelp.style.display = "";		
		COCDHelp.style.display ="None";			CoNameHelp.style.display ="";
		CoGrpCodeHelp.style.display ="None";
		ExchangeHelp.style.display ="None";
		MarketHelp.style.display ="None";
		BrokerHelp.style.display ="None";
		FACOCDHelp.style.display ="None";		FACoNameHelp.style.display ="None";
		IOPoolAccHelp.style.display ="None";
		YearHelp.style.display = "None";		SettingHelp.style.display = "None";
	}
	else if( obj.name == "CoGrpCode" )
	{
		MainHelp.style.display = "";		
		COCDHelp.style.display ="None";			CoNameHelp.style.display ="None";
		CoGrpCodeHelp.style.display ="";
		ExchangeHelp.style.display ="None";
		MarketHelp.style.display ="None";
		BrokerHelp.style.display ="None";
		FACOCDHelp.style.display ="None";		FACoNameHelp.style.display ="None";
		IOPoolAccHelp.style.display ="None";
		YearHelp.style.display = "None";		SettingHelp.style.display = "None";
	}
	else if( obj.name == "Exchange" )
	{
		MainHelp.style.display = "";		
		COCDHelp.style.display ="None";			CoNameHelp.style.display ="None";
		CoGrpCodeHelp.style.display ="None";
		ExchangeHelp.style.display ="";
		MarketHelp.style.display ="None";
		BrokerHelp.style.display ="None";
		FACOCDHelp.style.display ="None";		FACoNameHelp.style.display ="None";
		IOPoolAccHelp.style.display ="None";
		YearHelp.style.display = "None";		SettingHelp.style.display = "None";
	}
	else if( obj.name == "Market" )
	{
		MainHelp.style.display = "";		
		COCDHelp.style.display ="None";			CoNameHelp.style.display ="None";
		CoGrpCodeHelp.style.display ="None";
		ExchangeHelp.style.display ="None";
		MarketHelp.style.display ="";
		BrokerHelp.style.display ="None";
		FACOCDHelp.style.display ="None";		FACoNameHelp.style.display ="None";
		IOPoolAccHelp.style.display ="None";
		YearHelp.style.display = "None";		SettingHelp.style.display = "None";
	}
	else if( obj.name == "Broker" )
	{
		MainHelp.style.display = "";		
		COCDHelp.style.display ="None";			CoNameHelp.style.display ="None";
		CoGrpCodeHelp.style.display ="None";
		ExchangeHelp.style.display ="None";
		MarketHelp.style.display ="None";
		BrokerHelp.style.display ="";
		FACOCDHelp.style.display ="None";		FACoNameHelp.style.display ="None";
		IOPoolAccHelp.style.display ="None";
		YearHelp.style.display = "None";		SettingHelp.style.display = "None";
	}
	else if( obj.name == "FAPostingCOCD" )
	{
		MainHelp.style.display = "";		
		COCDHelp.style.display ="None";			CoNameHelp.style.display ="None";
		CoGrpCodeHelp.style.display ="None";
		ExchangeHelp.style.display ="None";
		MarketHelp.style.display ="None";
		BrokerHelp.style.display ="None";
		FACOCDHelp.style.display ="";			FACoNameHelp.style.display ="None";
		IOPoolAccHelp.style.display ="None";
		YearHelp.style.display = "None";		SettingHelp.style.display = "None";
	}
	else if( obj.name == "FAPostingCoName" )
	{
		MainHelp.style.display = "";		
		COCDHelp.style.display ="None";			CoNameHelp.style.display ="None";
		CoGrpCodeHelp.style.display ="None";
		ExchangeHelp.style.display ="None";
		MarketHelp.style.display ="None";
		BrokerHelp.style.display ="None";
		FACOCDHelp.style.display ="None";		FACoNameHelp.style.display ="";
		IOPoolAccHelp.style.display ="None";
		YearHelp.style.display = "None";		SettingHelp.style.display = "None";
	}
	
	else if( obj.name == "CDSLPoolAccCode" )
	{
		MainHelp.style.display = "None";		
		IOPoolAccHelp.style.display ="";
		CDSLAccCodeHelp.style.display ="";
		CDSLDPIDHelp.style.display ="None";		CDSLDPNameHelp.style.display ="None";
		NSDLAccCodeHelp.style.display ="None";
		NSDLDPIDHelp.style.display ="None";		NSDLDPNameHelp.style.display ="None";
		YearHelp.style.display = "None";		SettingHelp.style.display = "None";
	}
	else if( obj.name == "CDSLPoolDPID" )
	{
		MainHelp.style.display = "None";		
		IOPoolAccHelp.style.display ="";
		CDSLAccCodeHelp.style.display ="None";
		CDSLDPIDHelp.style.display ="";			CDSLDPNameHelp.style.display ="None";
		NSDLAccCodeHelp.style.display ="None";
		NSDLDPIDHelp.style.display ="None";		NSDLDPNameHelp.style.display ="None";
		YearHelp.style.display = "None";		SettingHelp.style.display = "None";
	}
	else if( obj.name == "CDSLPoolDPName" )
	{
		MainHelp.style.display = "None";		
		IOPoolAccHelp.style.display ="";
		CDSLAccCodeHelp.style.display ="None";
		CDSLDPIDHelp.style.display ="None";		CDSLDPNameHelp.style.display ="";
		NSDLAccCodeHelp.style.display ="None";
		NSDLDPIDHelp.style.display ="None";		NSDLDPNameHelp.style.display ="None";
		YearHelp.style.display = "None";		SettingHelp.style.display = "None";
	}
	else if( obj.name == "NSDLPoolAccCode" )
	{
		MainHelp.style.display = "None";		
		IOPoolAccHelp.style.display ="";
		CDSLAccCodeHelp.style.display ="None";
		CDSLDPIDHelp.style.display ="None";		CDSLDPNameHelp.style.display ="None";
		NSDLAccCodeHelp.style.display ="";
		NSDLDPIDHelp.style.display ="None";		NSDLDPNameHelp.style.display ="None";
		YearHelp.style.display = "None";		SettingHelp.style.display = "None";
	}
	else if( obj.name == "NSDLPoolDPID" )
	{
		MainHelp.style.display = "None";		
		IOPoolAccHelp.style.display ="";
		CDSLAccCodeHelp.style.display ="None";
		CDSLDPIDHelp.style.display ="None";		CDSLDPNameHelp.style.display ="None";
		NSDLAccCodeHelp.style.display ="None";
		NSDLDPIDHelp.style.display ="";			NSDLDPNameHelp.style.display ="None";
		YearHelp.style.display = "None";		SettingHelp.style.display = "None";
	}
	else if( obj.name == "NSDLPoolDPName" )
	{
		MainHelp.style.display = "None";		
		IOPoolAccHelp.style.display ="";
		CDSLAccCodeHelp.style.display ="None";
		CDSLDPIDHelp.style.display ="None";		CDSLDPNameHelp.style.display ="None";
		NSDLAccCodeHelp.style.display ="None";
		NSDLDPIDHelp.style.display ="None";		NSDLDPNameHelp.style.display ="";
		YearHelp.style.display = "None";		SettingHelp.style.display = "None";
	}
	
	else if
		( 
			( obj.name == "FinStart" ) || 
			( obj.name == "FinEnd" ) || 
			( obj.name == "StartDate" ) || 
			( obj.name == "EndDate" )
		)
	{
		MainHelp.style.display = "None";		IOPoolAccHelp.style.display ="None";
		YearHelp.style.display = "";			SettingHelp.style.display = "None";
	}
	
	else if
		( 
			( obj.name == "FTPIPAddress" ) || 
			( obj.name == "BrokerCode" ) || 
			( obj.name == "ClearingMemberCode" ) || 
			( obj.name == "FlgResetContract" )
		)
	{
		MainHelp.style.display = "None";		IOPoolAccHelp.style.display ="None";
		YearHelp.style.display = "None";		SettingHelp.style.display = "";
	}
}