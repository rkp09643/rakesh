/* *************************************************************************
	FUNCTION FOR VALIDATING EMPTY FORM FIELDS BEFORE SUBMITING THE FORM.
************************************************************************* */
function validateEmptyFields( form )
{
	var field, fieldName, fieldValue, fieldsCount = form.elements.length;
	
	with( form )
	{
		for( i = 0; i < ( fieldsCount - 2 ); i++ )
		{
			if( ( i != 0 ) && ( i > 17 ) && ( i != 20 ) && ( i != 18 ) && ( i < 22 )  )
			{
				field = elements[ i ];
				//alert(i);
				fieldName = field.name;
				fieldValue = field.value;
				//alert(fieldName,field,fieldValue);
				// GENERALIZED VALIDATION FOR ALL THE FORM FIELDS.
				if( ( fieldValue == "" ) || ( fieldValue.charAt ( 0 ) == " " ) )
				{
					alert( "Please enter a value for the field '" +fieldName +"'." );
					field.value = "";
					field.focus();
					return false;
				}
			}
		}
	}
}


/* *************************************************
	FOR HIDING/SHOWING USER HELPS WHEN REQUIRED.
************************************************* */
function showHideHelps( obj )
{
	if( obj == "Body" )
	{
		DefaultAccHelp.style.display ="";
		ClientDPCodeHelp.style.display ="None";	ClientDPNameHelp.style.display ="None";
		DPIDHelp.style.display = "None";		DPNameHelp.style.display = "None";
	}
	else if( obj.name == "lblDefaultAccount" )
	{
		DefaultAccHelp.style.display ="";
		ClientDPCodeHelp.style.display ="None";	ClientDPNameHelp.style.display ="None";
		DPIDHelp.style.display = "None";		DPNameHelp.style.display = "None";
	}
	else if( obj.name == "ClientDPCode" )
	{
		DefaultAccHelp.style.display ="None";
		ClientDPCodeHelp.style.display ="";	ClientDPNameHelp.style.display ="None";
		DPIDHelp.style.display = "None";		DPNameHelp.style.display = "None";
	}
	else if( obj.name == "ClientDPName" )
	{
		DefaultAccHelp.style.display ="None";
		ClientDPCodeHelp.style.display ="None";	ClientDPNameHelp.style.display ="";
		DPIDHelp.style.display = "None";		DPNameHelp.style.display = "None";
	}
	else if( obj.name == "DPID" )
	{
		DefaultAccHelp.style.display ="None";
		ClientDPCodeHelp.style.display ="None";	ClientDPNameHelp.style.display ="None";
		DPIDHelp.style.display = "";			DPNameHelp.style.display = "None";
	}
	else if( obj.name == "DPName" )
	{
		DefaultAccHelp.style.display ="None";
		ClientDPCodeHelp.style.display ="None";	ClientDPNameHelp.style.display ="None";
		DPIDHelp.style.display = "None";		DPNameHelp.style.display = "";
	}
	else if( obj.name == "Save" )
	{
		DefaultAccHelp.style.display ="None";
		ClientDPCodeHelp.style.display ="None";	ClientDPNameHelp.style.display ="None";
		DPIDHelp.style.display = "None";		DPNameHelp.style.display = "None";
	}
}