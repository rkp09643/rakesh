select 'alter table '+b.name +' drop CONSTRAINT  '+a.name
from sys.objects  a,sys.tables b
where a.name like 'msr%'
and a.parent_object_id =b.object_id
select 'alter table '+b.name +' drop column '+a.name
from syscolumns a,sys.tables b
where a.name like 'msr%'
and a.id =b.object_id