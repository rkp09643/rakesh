/*####################################################################################
					JAVASCRIPT FILE FOR VALIDATING TOP FRAME.
####################################################################################*/


function Initialize( form )
{
	with( form )
	{
		parent.Display.location.href	=	"/DEPOSITORY/DynamicFrame/BlankPage.html";
		
		if( tradingMasters.length > 0 )
		{
			tradingMasters[0].selected	=	true;
			tradingProcess[0].selected	=	true;
			tradingReports[0].selected	=	true;
			TradingUserReports[0].selected	=	true;
			txttradingReports.value		=	"";
		}
		if( faMasters.length > 0 )
		{
			faMasters[0].selected		=	true;
			faVouchers[0].selected		=	true;
			faReports[0].selected		=	true;
			faUserReports[0].selected	=	true;
			txtfaReports.value			=	"";
		}
		if( ioMasters.length > 0 )
		{
			ioMasters[0].selected		=	true;
			ioVouchers[0].selected		=	true;
			ioReports[0].selected		=	true;
			StockUserReports[0].selected	=	true;
			txtIOReports.value			=	"";
		}
	}
}


/* **********************************************
	CHANGING THE END-YEAR WHEN START CHANGES.
********************************************** */	 
function chkFinStartYear( form, currYear )
{
	with( form )
	{
		finStart = FinStart.value;
		
		if( ( finStart != "" ) && ( finStart.charAt(0) != " " ) )
		{
			finStart = parseInt( new Number( finStart ) );
			
			if( isNaN( finStart ) )
			{
				alert( "Please enter a Numeric Value." );
				FinStart.value = parseInt( new Number( currYear ) );
				FinStart.focus();
			}
			else
			{
				FinStart.value = finStart;
				FinEnd.value = ( finStart + 1 );
				
				if( Segment.value == "TRADING" )
				{
					//Branch.focus();
				}
				else if( Segment.value == "FA" )
				{
					faMasters.focus();
				}
				else if( Segment.value == "IO" )
				{
					ioMasters.focus();
				}
			}
		}
	}
}


/* *********************************
	TRADING - MASTERS MENU ITEMS.
********************************* */
function TradingMastersNavigate( form )
{
	with( form )
	{
		mastersPath		=	"/DEPOSITORY/Masters/";
		mastersParam	=	"COCD=" +COCD.value +"&CoName=" +CoName.value +"&CoGroup=" +CoGroup.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=&CDSLPoolAccCode=" +CDSLPoolAccCode.value +"&CDSLDPID=" +CDSLDPID.value +"&CDSLDPName=" +CDSLDPName.value +"&NSDLPoolAccCode=" +NSDLPoolAccCode.value +"&NSDLDPID=" +NSDLDPID.value +"&NSDLDPName=" +NSDLDPName.value;
		
		tradingProcess[0].selected	=	true;
		tradingReports[0].selected	=	true;
		TradingUserReports[0].selected	=	true;
		
		if( tradingMasters.value == "1" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/Common/CompanyList.cfm";
			
		}
		else if( tradingMasters.value == "2" )
		{
			parent.Display.location.href	=	mastersPath +"FinancialYearMaster.cfm?" +mastersParam;
		}
		else if( tradingMasters.value == "3" )
		{
			parent.Display.location.href	=	mastersPath +"SettingsMaster.cfm?" +mastersParam;
		}
		else if( tradingMasters.value == "4" )
		{
			parent.Display.location.href	=	mastersPath +"ControlMaster.cfm?" +mastersParam;
		}
		else if( tradingMasters.value == "5" )
		{
			parent.Display.location.href	=	mastersPath +"HolidayMaster.cfm?" +mastersParam;
		}
		else if( tradingMasters.value == "6" )
		{
			parent.Display.location.href	=	mastersPath +"ClientMaster.cfm?" +mastersParam;
		}
		else if( tradingMasters.value == "7" )
		{
			parent.Display.location.href	=	mastersPath +"ScripMaster.cfm?" +mastersParam;
		}
		else if( tradingMasters.value == "8" )
		{
			parent.Display.location.href	=	mastersPath +"MarketLotMaster.cfm?" +mastersParam;
		}
		else if( tradingMasters.value == "9" )
		{
			parent.Display.location.href	=	mastersPath +"BranchMaster.cfm?" +mastersParam;
		}
		else if( tradingMasters.value == "10" )
		{
			parent.Display.location.href	=	mastersPath +"RemeshireMaster.cfm?" +mastersParam;
		}
		else if( tradingMasters.value == "11" )
		{
			parent.Display.location.href	=	mastersPath +"Client_RemeshireMaster.cfm?" +mastersParam;
		}
		else if( tradingMasters.value == "12" )
		{
			parent.Display.location.href	=	mastersPath +"ReplaceMaster.cfm?" +mastersParam;
		}
		else if( tradingMasters.value == "13" )
		{
			parent.Display.location.href	=	mastersPath +"MarketTypeMaster.cfm?" +mastersParam;
		}
		else if( tradingMasters.value == "14" )
		{
			parent.Display.location.href	=	mastersPath +"SettlementMaster.cfm?" +mastersParam;
		}
		else if( tradingMasters.value == "15" )
		{
			parent.Display.location.href	=	mastersPath +"TransactionMaster.cfm?" +mastersParam;
		}
		else if( tradingMasters.value == "16" )
		{
			parent.Display.location.href	=	mastersPath +"EarlyExpiry.cfm?" +mastersParam;
		}
		else if( tradingMasters.value == "17" )
		{
			parent.Display.location.href	=	mastersPath +"OpeningStock.cfm?" +mastersParam;
		}
		else if( tradingMasters.value == "18" )
		{
			parent.Display.location.href	=	mastersPath +"Inflation_Index.cfm?" +mastersParam;
		}
		else if( tradingMasters.value == "19" )
		{
			parent.Display.location.href	=	mastersPath +"StockValuation.cfm?" +mastersParam;
		}
		else if( tradingMasters.value == "20" )
		{
			parent.Display.location.href	=	mastersPath +"CollateralMaster.cfm?" +mastersParam;
		}
		else if( tradingMasters.value == "22" )
		{
			parent.Display.location.href	=	mastersPath +"BrokerageMaster.cfm?" +mastersParam;
		}
		else if( tradingMasters.value == "23" )
		{
			parent.Display.location.href	=	mastersPath +"SCMaster.cfm?" +mastersParam;
		}
		else if( tradingMasters.value == "24" )
		{
			parent.Display.location.href	=	mastersPath +"TOCMaster.cfm?" +mastersParam;
		}
		else if( tradingMasters.value == "25" )
		{
			parent.Display.location.href	=	mastersPath +"StampDetails.cfm?" +mastersParam;
		}
		else if( tradingMasters.value == "26" )
		{
			parent.Display.location.href	=	mastersPath +"ExpenseMaster.cfm?" +mastersParam;
		}
		else if( tradingMasters.value == "27" )
		{
			parent.Display.location.href	=	mastersPath +"CorporateAction.cfm?" +mastersParam;
		}
		else if( tradingMasters.value == "28" )
		{
			parent.Display.location.href	=	mastersPath +"HairCut.cfm?" +mastersParam;
		}
		else if( tradingMasters.value == "29" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/FOCAPS_REPORTS/REPORTS_TEMPLATES/REPORT_MASTER_ENTRY.CFM";
		}
		else
		{
			parent.Display.location.href	=	"/DEPOSITORY/DynamicFrame/BlankPage.html";
		}
	}
}


/* *********************************
	TRADING - PROCESS MENU ITEMS.
********************************* */
function TradingProcessNavigate( form )
{
	with( form )
	{
		uploadPath		=	"/DEPOSITORY/TradeUploads/";
		processesPath	=	"/DEPOSITORY/ProcessData/";
		screenPath		=	"/DEPOSITORY/Reports/";
		viewPath		=	"/DEPOSITORY/ViewData/";
		transParam		=	"COCD=" +COCD.value +"&CoName=" +CoName.value +"&CoGroup=" +CoGroup.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=&CDSLPoolAccCode=" +CDSLPoolAccCode.value +"&CDSLDPID=" +CDSLDPID.value +"&CDSLDPName=" +CDSLDPName.value +"&NSDLPoolAccCode=" +NSDLPoolAccCode.value +"&NSDLDPID=" +NSDLDPID.value +"&NSDLDPName=" +NSDLDPName.value;
		
		tradingMasters[0].selected	=	true;
		tradingReports[0].selected	=	true;
		TradingUserReports[0].selected	=	true;
		
		if( tradingProcess.value == "1" )
		{
			parent.Display.location.href	=	uploadPath +"Upload.cfm?" +transParam;
		}
		else if( tradingProcess.value == "2" )
		{
			parent.Display.location.href	=	processesPath +Market.value +"/CallProcesses.cfm?" +transParam;
		}
		else if( tradingProcess.value == "3" )
		{
			parent.Display.location.href	=	processesPath +Market.value +"/ContractProcess.cfm?" +transParam;
		}
		else if( tradingProcess.value == "4" )
		{
			parent.Display.location.href	=	processesPath +Market.value +"/BillCancel.cfm?" +transParam;
		}
		else if( tradingProcess.value == "5" )
		{
			parent.Display.location.href	=	processesPath +Market.value +"/NDProcess.cfm?" +transParam;
		}
		else if( tradingProcess.value == "6" )
		{
			parent.Display.location.href	=	processesPath +Market.value +"/MTMClosingPrice.cfm?" +transParam;
		}
		else if( tradingProcess.value == "7" )
		{
			parent.Display.location.href	=	processesPath +Market.value +"/MarkToMarket.cfm?" +transParam;
		}
		else if( tradingProcess.value == "8" )
		{
			parent.Display.location.href	=	processesPath +Market.value +"/Expiry.cfm?" +transParam;
		}
		else if( tradingProcess.value == "9" )
		{
			parent.Display.location.href	=	viewPath +"Browse.cfm?" +transParam;
		}
		else if( tradingProcess.value == "10" )
		{
			parent.Display.location.href	=	screenPath +"Screen.cfm?" +transParam;
		}
		else if( tradingProcess.value == "12" )
		{
			if ( Market.value == "FO" )
			{
				parent.Display.location.href	=	viewPath +"Screen.cfm?" +transParam;
			}
			else
			{
				parent.Display.location.href	=	viewPath +Market.value +"/ManualFrame.cfm?" +transParam;
			}
		}
		else if( tradingProcess.value == "13" )
		{
			parent.Display.location.href	=	processesPath +Market.value +"/TradeDeletion.cfm?" +transParam;
		}
		else if( tradingProcess.value == "14" )
		{
			parent.Display.location.href	=	processesPath +Market.value +"/MarginDeletion.cfm?" +transParam;
		}
		else
		{
			parent.Display.location.href	=	"/DEPOSITORY/DynamicFrame/BlankPage.html";
		}
	}
}


/* *********************************
	TRADING - REPORTS MENU ITEMS.
********************************* */
function TradingReportsNavigate( form, source )
{
	with( form )
	{
		reportsPath		=	"/DEPOSITORY/Reports/";
		reportsParam	=	"COCD=" +COCD.value +"&CoName=" +CoName.value +"&CoGroup=" +CoGroup.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=&CDSLPoolAccCode=" +CDSLPoolAccCode.value +"&CDSLDPID=" +CDSLDPID.value +"&CDSLDPName=" +CDSLDPName.value +"&NSDLPoolAccCode=" +NSDLPoolAccCode.value +"&NSDLDPID=" +NSDLDPID.value +"&NSDLDPName=" +NSDLDPName.value;
		
		tradingProcess[0].selected	=	true;
		tradingMasters[0].selected	=	true;
		TradingUserReports[0].selected	=	true;
		
		if( tradingReports.value > 0 && source == 2 )
		{
			txttradingReports.value = tradingReports.value;
			parent.Display.location.href = reportsPath +Market.value +"/Parameters.cfm?" +reportsParam +"&REPORTID=" +tradingReports.value;
		}
		else if( txttradingReports.value > 0 && source == 1 )
		{
			tradingReports.value = txttradingReports.value;
			parent.Display.location.href = reportsPath +Market.value +"/Parameters.cfm?" +reportsParam +"&REPORTID=" +txttradingReports.value;
		}
		else
		{
			parent.Display.location.href = "/DEPOSITORY/DynamicFrame/BlankPage.html";
		}
	}
}

/* *********************************
	TRADING - REPORTS MENU ITEMS.
********************************* */
function TradingUserReportsNavigate( form, source )
{
	with( form )
	{
		reportsPath		=	"/DEPOSITORY/FOCAPS_REPORTS/REPORTS_TEMPLATES";
		reportsParam	=	"COCD=" +COCD.value +"&CoName=" +CoName.value +"&CoGroup=" +CoGroup.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=&CDSLPoolAccCode=" +CDSLPoolAccCode.value +"&CDSLDPID=" +CDSLDPID.value +"&CDSLDPName=" +CDSLDPName.value +"&NSDLPoolAccCode=" +NSDLPoolAccCode.value +"&NSDLDPID=" +NSDLDPID.value +"&NSDLDPName=" +NSDLDPName.value;
		
		tradingProcess[0].selected	=	true;
		tradingMasters[0].selected	=	true;
		tradingReports[0].selected	=	true;
		
		if( TradingUserReports.value > 0 )
		{
			txttradingReports.value = TradingUserReports.value;
			parent.Display.location.href = reportsPath +"/REPORT_PARAMETERS.cfm?" +reportsParam +"&REPORT_ID=" +TradingUserReports.value;
		}
		else
		{
			parent.Display.location.href = "/DEPOSITORY/DynamicFrame/BlankPage.html";
		}
	}
}

/* ***********************************************
	FINANCIAL ACCOUNTING - MASTERS MENU ITEMS.
*********************************************** */
function AccountMastersNavigate( form )
{
	with( form )
	{
		mainPath	=	"/DEPOSITORY/FA_FOCAPS/Forms/";
		bsPath		=	"/DEPOSITORY/FA_FOCAPS/BalanceSheet/";
		param		=	"COCD=" +COCD.value +"&CoName=" +escape(CoName.value) +"&CoGroup=" +CoGroup.value +"&StYr=" +FinStart.value +"&EndYr=" +FinEnd.value +"&CDSLPoolAccCode=" +CDSLPoolAccCode.value +"&CDSLDPID=" +CDSLDPID.value +"&CDSLDPName=" +CDSLDPName.value +"&NSDLPoolAccCode=" +NSDLPoolAccCode.value +"&NSDLDPID=" +NSDLDPID.value +"&NSDLDPName=" +NSDLDPName.value;
		
		faVouchers[0].selected	=	true;
		faReports[0].selected	=	true;
		faUserReports[0].selected	=	true;
		
		if( faMasters.value == "1" )
		{
			//COMPANY LIST
			parent.Display.location.href	=	mainPath +"Main.cfm"
		}
		else if( faMasters.value == "2" )
		{
			//FAMILY GROUP
			parent.Display.location.href	=	mainPath +"FamilyMaster.cfm?" +param;		
		}
		else if( faMasters.value == "3" )
		{
			//GENERAL LEDGER
			parent.Display.location.href	=	mainPath +"Ledger.cfm?" +param;
		}
		else if( faMasters.value == "4" )
		{
			//OPENING BALANCE
			parent.Display.location.href	=	mainPath +"OpeningBalanceUpdation.cfm?" +param;
		}
		else if( faMasters.value == "5" )
		{
			//NARRATION
			parent.Display.location.href	=	mainPath +"Narration.cfm?" +param;
		}
		else if( faMasters.value == "6" )
		{
			//TRANSFER ACCOUNTS
			parent.Display.location.href	=	mainPath +"TransferAccounts.cfm?" +param;			
		}
		else if( faMasters.value == "7" )
		{
			//FIN YR PROCESS
			parent.Display.location.href	=	mainPath +"FinYrProcess.cfm?" +param;
		}
		else if( faMasters.value == "8" )
		{
			//ACCOUNT POSTING
			parent.Display.location.href	=	mainPath +"LogEntry.cfm?" +param;
		}
		else if( faMasters.value == "10" )
		{
			//MAIN
			parent.Display.location.href	=	bsPath +"LayerFrame.cfm?Layer=Main&" +param;		
		}
		else if( faMasters.value == "11" )
		{
			//GROUP
			parent.Display.location.href	=	bsPath +"LayerFrame.cfm?Layer=Group&" +param;
		}
		else if( faMasters.value == "12" )
		{
			//SCHEDULE
			parent.Display.location.href	=	bsPath +"LayerFrame.cfm?Layer=Schedule&" +param;			
		}
		else if( faMasters.value == "13" )
		{
			//GROUPING
			parent.Display.location.href	=	bsPath +"LayerFrame.cfm?Layer=Grouping&" +param;
		}
		else
		{
			parent.Display.location.href	=	"/DEPOSITORY/DynamicFrame/BlankPage.html";
		}
	}
}


/* ****************************************************
	FINANCIAL ACCOUNTING - TRANSACTIONS MENU ITEMS.
**************************************************** */
function AccountProcessNavigate( form )
{
	with( form )
	{
		mainPath	=	"/DEPOSITORY/FA_FOCAPS/Forms/"
		param		=	"COCD=" +COCD.value +"&CoName=" +CoName.value +"&CoGroup=" +CoGroup.value +"&StYr=" +FinStart.value +"&EndYr=" +FinEnd.value +"&CDSLPoolAccCode=" +CDSLPoolAccCode.value +"&CDSLDPID=" +CDSLDPID.value +"&CDSLDPName=" +CDSLDPName.value +"&NSDLPoolAccCode=" +NSDLPoolAccCode.value +"&NSDLDPID=" +NSDLDPID.value +"&NSDLDPName=" +NSDLDPName.value;
		
		faMasters[0].selected	=	true;
		faReports[0].selected	=	true;
	    faUserReports[0].selected	=	true;
		
		if( faVouchers.value == "1" )
		{
			//RECEIPT VOUCHER
			parent.Display.location.href	=	mainPath +"ReceiptPayment.cfm?Bank=Yes&TransactionType=Receipt&Tr_Type=R&" +param;
		}
		else if( faVouchers.value == "2" )
		{
			//PAYMENT VOUCHER
			parent.Display.location.href	=	mainPath +"ReceiptPayment.cfm?Bank=Yes&TransactionType=Payment&Tr_Type=P&" +param;
		}
		else if( faVouchers.value == "3" )
		{
			//JOURNAL VOUCHER
			parent.Display.location.href	=	mainPath +"Journal.cfm?&JV=Normal&" +param;
		}
		else if( faVouchers.value == "4" )
		{
			//CONTRA VOUCHER
			parent.Display.location.href	=	mainPath +"ContraVoucher.cfm?&Journal=Yes&" +param;
		}
		else if( faVouchers.value == "6" )
		{
			//SYSTEM JOURNAL
			parent.Display.location.href	=	mainPath +"VoucherView.cfm?tr_type=SJ&" +param;			
		}
		else if( faVouchers.value == "8" )
		{
			//TRANSACTION TRANSFER
			parent.Display.location.href	=	mainPath +"TransactionTransfer.cfm?" +param;
		}
		else
		{
			parent.Display.location.href	=	"/DEPOSITORY/DynamicFrame/BlankPage.html";
		}
	}
}


/* ***********************************************
	FINANCIAL ACCOUNTING - REPORTS MENU ITEMS.
*********************************************** */
function AccountingReportsNavigate( form, source )
{
	with( form )
	{
		faMasters[0].selected	=	true;
		faVouchers[0].selected	=	true;
	    faUserReports[0].selected	=	true;
		
		if(faReports.value > 0 && source == 2)
		{
			txtfaReports.value				=	faReports.value;		
			parent.Display.location.href	=	"/DEPOSITORY/FA_FOCAPS/Reports/Parameters1.cfm?COCD=" +COCD.value +"&CoName=" +escape(CoName.value) +"&CoGroup=" +CoGroup.value +"&StYr=" +FinStart.value +"&EndYr=" +FinEnd.value +"&CDSLPoolAccCode=" +CDSLPoolAccCode.value +"&CDSLDPID=" +CDSLDPID.value +"&CDSLDPName=" +CDSLDPName.value +"&NSDLPoolAccCode=" +NSDLPoolAccCode.value +"&NSDLDPID=" +NSDLDPID.value +"&NSDLDPName=" +NSDLDPName.value +"&REPORTID=" +faReports.value;
		}
		else if(txtfaReports.value > 0 && source == 1)
		{
			faReports.value					=	txtfaReports.value;		
			parent.Display.location.href	=	"/DEPOSITORY/FA_FOCAPS/Reports/Parameters1.cfm?COCD=" +COCD.value +"&CoName=" +escape(CoName.value) +"&CoGroup=" +CoGroup.value +"&StYr=" +FinStart.value +"&EndYr=" +FinEnd.value +"&CDSLPoolAccCode=" +CDSLPoolAccCode.value +"&CDSLDPID=" +CDSLDPID.value +"&CDSLDPName=" +CDSLDPName.value +"&NSDLPoolAccCode=" +NSDLPoolAccCode.value +"&NSDLDPID=" +NSDLDPID.value +"&NSDLDPName=" +NSDLDPName.value +"&REPORTID=" +txtfaReports.value;
		}
		else
		{
			parent.Display.location.href	=	"/DEPOSITORY/DynamicFrame/BlankPage.html";
		}
	}
}


/* **************************************
		REFRESH FA FRAME
************************************** */
function refreshFrame( segment )
{
	with( TopFrameForm )
	{
		FinEnd.value	=	( parseInt( new Number( FinStart.value ) ) + 1 );
		
		if( ( segment == "FA" ) && ( faReports.value > 0 ) )
		{
			parent.Display.location.href	=	"/DEPOSITORY/FA_FOCAPS/Reports/Parameters1.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&CoGroup=" +CoGroup.value +"&StYr=" +FinStart.value +"&EndYr=" +FinEnd.value +"&CDSLPoolAccCode=" +CDSLPoolAccCode.value +"&CDSLDPID=" +CDSLDPID.value +"&CDSLDPName=" +CDSLDPName.value +"&NSDLPoolAccCode=" +NSDLPoolAccCode.value +"&NSDLDPID=" +NSDLDPID.value +"&NSDLDPName=" +NSDLDPName.value +"&REPORTID=" +txtfaReports.value;
		}
		else
		{
			parent.Display.location.href	=	"/DEPOSITORY/DynamicFrame/BlankPage.html";
			parent.Query.location.href		=	"/DEPOSITORY/DynamicFrame/Queries.cfm?Segment=" +segment +"&queryfor=COMPANY&FormObject=parent.Support.document.TopFrameForm";
		}
	}
}


/* ****************************************
	TRADING SYSTEM - COMPANY-CODE ITEMS.
**************************************** */
function CompanyList( form )
{
	with( form )
	{
		parent.Display.location.href	=	"/DEPOSITORY/DynamicFrame/BlankPage.html";
		parent.Query.location.href		=	"/DEPOSITORY/DynamicFrame/Queries.cfm?Segment=" +Segment.value +"&queryfor=COMPANY&FormObject=parent.Support.document.TopFrameForm";
		
		FinStart.value	=	"2003";
		FinEnd.value	=	"2004";
		
		if( Segment.value == "FA" || Segment.value == "IO" )
		{
			//lblBranch.style.display		=	"None";
		}
		else
		{
			//lblBranch.style.display		=	"";
		}
		
		if( Segment.value == "TRADING" )
		{
			TradingMenu.style.display	=	"";
			AccountsMenu.style.display	=	"None";
			StockMenu.style.display		=	"None";
		}
		
		if( Segment.value == "FA" )
		{
			TradingMenu.style.display	=	"None";
			faReports[0].selected		=	true;
			AccountsMenu.style.display	=	"";
			StockMenu.style.display		=	"None";
		}
		
		if( Segment.value == "IO" )
		{
			TradingMenu.style.display	=	"None";
			ioReports[0].selected		=	true;
			AccountsMenu.style.display	=	"None";
			StockMenu.style.display		=	"";
		}
	}
}


/* ****************************************
	TRADING SYSTEM - COMPANY-NAME ITEMS.
**************************************** */
function CompanyName( form )
{
	with( form )
	{
		parent.Query.location.href		=	"/DEPOSITORY/DynamicFrame/Queries.cfm?Segment=" +Segment.value +"&COCD=" +COCD.value +"&CoGroup=" +CoGroup.value +"&queryfor=NAME&FormObject=parent.Support.document.TopFrameForm";
		
		if( Segment.value == "FA" || Segment.value == "IO" )
		{
			//lblBranch.style.display		=	"None";
		}
		else
		{
			//lblBranch.style.display		=	"";
		}
		
		if( Segment.value == "FA" )
		{
			//AccountingReportsNavigate(TopFrameForm,'2');
		}	
		
		if( Segment.value == "TRADING" )
		{
			TradingMenu.style.display	=	"";
			tradingMasters[0].selected	=	true;
			tradingProcess[0].selected	=	true;
		    TradingUserReports[0].selected	=	true;
			AccountsMenu.style.display	=	"None";
			StockMenu.style.display		=	"None";
		}
		
		if( Segment.value == "FA" )
		{
			TradingMenu.style.display	=	"None";
			faMasters[0].selected		=	true;
			faVouchers[0].selected		=	true;
			faUserReports[0].selected	=	true;
			AccountsMenu.style.display	=	"";
			StockMenu.style.display		=	"None";
		}
		
		if( Segment.value == "IO" )
		{
			TradingMenu.style.display	=	"None";
			ioMasters[0].selected		=	true;
			ioVouchers[0].selected		=	true;
			StockUserReports[0].selected	=	true;
			AccountsMenu.style.display	=	"None";
			StockMenu.style.display		=	"";
		}
	}
}


/* *************************************************
	STOCK INWARD / OUTWARD - MASTERS MENU ITEMS.
************************************************* */
function IOMastersNavigate( form )
{
	with( form )
	{
		mastersPath		=	"/DEPOSITORY/IO_FOCAPS/Masters/";
		mastersParam	=	"COCD=" +COCD.value +"&CoName=" +CoName.value +"&CoGroup=" +CoGroup.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStYr=" +FinStart.value +"&FinEndYr=" +FinEnd.value +"&Branch=&CDSLPoolAccCode=" +CDSLPoolAccCode.value +"&CDSLDPID=" +CDSLDPID.value +"&CDSLDPName=" +CDSLDPName.value +"&NSDLPoolAccCode=" +NSDLPoolAccCode.value +"&NSDLDPID=" +NSDLDPID.value +"&NSDLDPName=" +NSDLDPName.value;
		
		ioVouchers[0].selected	=	true;
		ioReports[0].selected	=	true;
		StockUserReports[0].selected =	true;
		
		if( ioMasters.value == "1" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/Common/CompanyList.cfm";
			
		}
		else if( ioMasters.value == "2" )
		{
			parent.Display.location.href	=	mastersPath +"ClientDPMaster.cfm?" +mastersParam;
		}
		else if( ioMasters.value == "3" )
		{
			parent.Display.location.href	=	mastersPath +"DPCatalog.cfm?" +mastersParam;
		}
	}
}


/* ******************************************************
	STOCK INWARD / OUTWARD - TRANSACTIONS MENU ITEMS.
****************************************************** */
function IOVouchersNavigate( form )
{
	with( form )
	{
		transPath	=	"/DEPOSITORY/IO_FOCAPS/Transactions/";
		transParam	=	"COCD=" +COCD.value +"&CoName=" +CoName.value +"&CoGroup=" +CoGroup.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStYr=" +FinStart.value +"&FinEndYr=" +FinEnd.value +"&Branch=&CDSLPoolAccCode=" +CDSLPoolAccCode.value +"&CDSLDPID=" +CDSLDPID.value +"&CDSLDPName=" +CDSLDPName.value +"&NSDLPoolAccCode=" +NSDLPoolAccCode.value +"&NSDLDPID=" +NSDLDPID.value +"&NSDLDPName=" +NSDLDPName.value;
		
		ioMasters[0].selected	=	true;
		ioReports[0].selected	=	true;
		StockUserReports[0].selected =	true;
		
		if( ioVouchers.value == "1" )
		{
			parent.Display.location.href	=	transPath +"Import.cfm?" +transParam;
		}
		else if( ioVouchers.value == "2" )
		{
			parent.Display.location.href	=	transPath +"MissingDetailsScreen.cfm?" +transParam;
		}
		else if( ioVouchers.value == "4" )
		{
			parent.Display.location.href	=	transPath +"InwardEntry.cfm?" +transParam +"&InwardType=ClientWise";
		}
		else if( ioVouchers.value == "5" )
		{
			parent.Display.location.href	=	transPath +"InwardEntry.cfm?" +transParam +"&InwardType=ScripWise";
		}
		else if( ioVouchers.value == "6" )
		{
			parent.Display.location.href	=	transPath +"OutwardEntry.cfm?" +transParam +"&OutwardType=ClientWise";
		}
		else if( ioVouchers.value == "7" )
		{
			parent.Display.location.href	=	transPath +"OutwardEntry.cfm?" +transParam +"&OutwardType=ScripWise";
		}
		else if( ioVouchers.value == "9" )
		{
			parent.Display.location.href	=	transPath +"IOProcessParameters.cfm?IOType=I&" +transParam;
		}
		else if( ioVouchers.value == "11" )
		{
			parent.Display.location.href	=	transPath +"CloseOutParameters.cfm?InwardShort=DirectPayIn&" +transParam;
		}
		else if( ioVouchers.value == "12" )
		{
			parent.Display.location.href	=	transPath +"InterSetlParameters.cfm?" +transParam +"&InterSetlType=Client";
		}
		else if( ioVouchers.value == "13" )
		{
			parent.Display.location.href	=	transPath +"InterSetlParameters.cfm?" +transParam +"&InterSetlType=Pool";
		}
		else if( ioVouchers.value == "14" )
		{
			parent.Display.location.href	=	transPath +"AuctionParameters.cfm?" +transParam;
		}
		else if( ioVouchers.value == "15" )
		{
			parent.Display.location.href	=	transPath +"CloseOutParameters.cfm?InwardShort=Exchange&" +transParam;
		}
		else if( ioVouchers.value == "17" )
		{
			parent.Display.location.href	=	transPath +"CloseOutParameters.cfm?InwardShort=Client&" +transParam;
		}
		else if( ioVouchers.value == "18" )
		{
			parent.Display.location.href	=	transPath +"TransactionDeletion.cfm?" +transParam;
		}
		else
		{
			parent.Display.location.href	=	"/DEPOSITORY/DynamicFrame/BlankPage.html";
		}
	}
}


/* *************************************************
	STOCK INWARD / OUTWARD - REPORTS MENU ITEMS.
************************************************* */
function ioReportsNavigate( form, source )
{
	with( form )
	{
		reportsPath		=	"/DEPOSITORY/IO_FOCAPS/Reports/";
		reportsParam	=	"COCD=" +COCD.value +"&CoName=" +CoName.value +"&CoGroup=" +CoGroup.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStYr=" +FinStart.value +"&FinEndYr=" +FinEnd.value +"&Branch=&CDSLPoolAccCode=" +CDSLPoolAccCode.value +"&CDSLDPID=" +CDSLDPID.value +"&CDSLDPName=" +CDSLDPName.value +"&NSDLPoolAccCode=" +NSDLPoolAccCode.value +"&NSDLDPID=" +NSDLDPID.value +"&NSDLDPName=" +NSDLDPName.value;
		
		ioMasters[0].selected	=	true;
		ioVouchers[0].selected	=	true;
		StockUserReports[0].selected =	true;
				
		if( ioReports.value > 0 && source == 2 )
		{
			txtIOReports.value				=	ioReports.value;
			parent.Display.location.href	=	reportsPath +"ReportParameters.cfm?" +reportsParam +"&ReportID=" +ioReports.value;
		}
		else if( txtIOReports.value > 0 && source == 1 )
		{
			ioReports.value					=	txtIOReports.value;
			parent.Display.location.href	=	reportsPath +"ReportParameters.cfm?" +reportsParam +"&ReportID=" +txtIOReports.value;
		}
		else
		{
			parent.Display.location.href	=	"/DEPOSITORY/DynamicFrame/BlankPage.html";
		}
	}
}