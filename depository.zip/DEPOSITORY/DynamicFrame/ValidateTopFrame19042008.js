/*####################################################################################
					JAVASCRIPT FILE FOR VALIDATING TOP FRAME.
####################################################################################*/


function Initialize( form )
{
	with( form )
	{
		parent.Display.location.href	=	"/DEPOSITORY/DynamicFrame/BlankPage.html";
		
		if( tradingMasters.length > 0 )
		{
			tradingMasters[0].selected	=	true;
			tradingProcess[0].selected	=	true;
			tradingReports[0].selected	=	true;
			TradingUserReports[0].selected	=	true;
			txttradingReports.value		=	"";
		}
		if( faMasters.length > 0 )
		{
			faMasters[0].selected		=	true;
			faVouchers[0].selected		=	true;
			faReports[0].selected		=	true;
			faUserReports[0].selected	=	true;
			txtfaReports.value			=	"";
		}
		if( ioMasters.length > 0 )
		{
			ioMasters[0].selected		=	true;
			ioVouchers[0].selected		=	true;
			ioReports[0].selected		=	true;
			StockUserReports[0].selected	=	true;
			txtIOReports.value			=	"";
		}
	}
}


/* **********************************************
	CHANGING THE END-YEAR WHEN START CHANGES.
********************************************** */	 
function chkFinStartYear( form, currYear )
{
	with( form )
	{
		finStart = FinStart.value;
		
		if( ( finStart != "" ) && ( finStart.charAt(0) != " " ) )
		{
			finStart = parseInt( new Number( finStart ) );
			
			if( isNaN( finStart ) )
			{
				alert( "Please enter a Numeric Value." );
				FinStart.value = parseInt( new Number( currYear ) );
				FinStart.focus();
			}
			else
			{
				FinStart.value = finStart;
				FinEnd.value = ( finStart + 1 );
				
				if( Segment.value == "TRADING" )
				{
					//Branch.focus();
				}
				else if( Segment.value == "FA" )
				{
					faMasters.focus();
				}
				else if( Segment.value == "IO" )
				{
					ioMasters.focus();
				}
			}
		}
	}
}


/* *********************************
	TRADING - MASTERS MENU ITEMS.
********************************* */
function TradingMastersNavigate( form )
{
	with( form )
	{
		mastersPath		=	"/DEPOSITORY/Masters/";
		mastersParam	=	"COCD=" +COCD.value +"&CoName=" +CoName.value +"&CoGroup=" +CoGroup.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=&CDSLPoolAccCode=" +CDSLPoolAccCode.value +"&CDSLDPID=" +CDSLDPID.value +"&CDSLDPName=" +CDSLDPName.value +"&NSDLPoolAccCode=" +NSDLPoolAccCode.value +"&NSDLDPID=" +NSDLDPID.value +"&NSDLDPName=" +NSDLDPName.value;
			
		tradingProcess[0].selected	=	true;
		tradingReports[0].selected	=	true;
		TradingUserReports[0].selected	=	true;
		
		if( tradingMasters.value == "1" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/Common/CompanyList.cfm?TemplateName=Trading_CompanyList";
		}
		
		else if( tradingMasters.value == "29" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/FOCAPS_REPORTS/REPORTS_TEMPLATES/REPORT_MASTER_ENTRY.CFM?TemplateName=Trading_REPORT_MASTER_ENTRY&Report_Segment=DEPOSITORY";
		}
		
		
		else
		{
			parent.Display.location.href	=	"/DEPOSITORY/DynamicFrame/BlankPage.html";
		}
	}
}


/* *********************************
	TRADING - PROCESS MENU ITEMS.
********************************* */
function TradingProcessNavigate( form )
{
	with( form )
	{
		uploadPath		=	"/DEPOSITORY/TradeUploads/";
		processesPath	=	"/DEPOSITORY/ProcessData/";
		screenPath		=	"/DEPOSITORY/Reports/";
		viewPath		=	"/DEPOSITORY/ViewData/";
		ioTransPath		=	"/DEPOSITORY/IO_FOCAPS/Transactions/";
		transParam		=	"COCD=" +COCD.value +"&CoName=" +CoName.value +"&CoGroup=" +CoGroup.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=&CDSLPoolAccCode=" +CDSLPoolAccCode.value +"&CDSLDPID=" +CDSLDPID.value +"&CDSLDPName=" +CDSLDPName.value +"&NSDLPoolAccCode=" +NSDLPoolAccCode.value +"&NSDLDPID=" +NSDLDPID.value +"&NSDLDPName=" +NSDLDPName.value;
		
		tradingMasters[0].selected	=	true;
		tradingReports[0].selected	=	true;
		TradingUserReports[0].selected	=	true;
		if( tradingProcess.value == "1" )
		{
			parent.Display.location.href	=	uploadPath +"Upload.cfm?TemplateName=Trading_UploadsForm&" +transParam;
		}
		else if( tradingProcess.value == "2" )
		{
			parent.Display.location.href	=	processesPath +Market.value +"/CallProcesses.cfm?TemplateName=Trading_CallProcesses&" +transParam;
		}
		else if( tradingProcess.value == "3" )
		{
			parent.Display.location.href	=	processesPath +Market.value +"/ContractProcess.cfm?TemplateName=Trading_ContractProcess&" +transParam;
		}
		else if( tradingProcess.value == "4" )
		{
			parent.Display.location.href	=	processesPath +Market.value +"/BillCancel.cfm?TemplateName=Trading_BillCancel&" +transParam;
		}
		else if( tradingProcess.value == "5" )
		{
			parent.Display.location.href	=	processesPath +Market.value +"/NDProcess.cfm?TemplateName=Trading_NDProcess&" +transParam;
		}
		else if( tradingProcess.value == "6" )
		{
			parent.Display.location.href	=	processesPath +Market.value +"/MTMClosingPrice.cfm?TemplateName=Trading_MTMClosingPrice&" +transParam;
		}
		else if( tradingProcess.value == "7" )
		{
			parent.Display.location.href	=	processesPath +Market.value +"/MarkToMarket.cfm?TemplateName=Trading_MarkToMarket&" +transParam;
		}
		else if( tradingProcess.value == "8" )
		{
			parent.Display.location.href	=	processesPath +Market.value +"/Expiry.cfm?TemplateName=Trading_Expiry&" +transParam;
		}
		else if( tradingProcess.value == "9" )
		{
			parent.Display.location.href	=	viewPath +"Browse.cfm?TemplateName=Trading_Browse&" +transParam;
		}
		else if( tradingProcess.value == "10" )
		{
			parent.Display.location.href	=	screenPath +"Screen.cfm?TemplateName=Trading_Screen&" +transParam;
		}
		else if( tradingProcess.value == "12" )
		{
			if ( Market.value == "FO" )
			{
				parent.Display.location.href	=	viewPath +"Screen.cfm?TemplateName=Trading_Screen&" +transParam;
			}
			else
			{
				parent.Display.location.href	=	viewPath +Market.value +"/ManualFrame.cfm?TemplateName=Trading_ManualFrame&" +transParam;
			}
		}
		else if( tradingProcess.value == "13" )
		{
			parent.Display.location.href	=	processesPath +Market.value +"/TradeDeletion.cfm?TemplateName=Trading_TradeDeletion&" +transParam;
		}
		else if( tradingProcess.value == "14" )
		{
			parent.Display.location.href	=	processesPath +Market.value +"/MarginDeletion.cfm?TemplateName=Trading_MarginDeletion&" +transParam;
		}
		else if( tradingProcess.value == "16" )
		{
			parent.Display.location.href	=	ioTransPath +"ExportClientOutwardParameters.cfm?TemplateName=Trading_ClientOutwardExport&" +transParam;
		}
		else if( tradingProcess.value == "17" )
		{
			parent.Display.location.href	=	processesPath +"/DataMaintenance.cfm?TemplateName=Trading_DataMaintenance&" +transParam;
		}
		else if( tradingProcess.value == "18" )
		{
			parent.Display.location.href	=	processesPath +"/IMPORT_MASTER.cfm?TemplateName=Trading_Import&" +transParam;
		}
		else if( tradingProcess.value == "19" )
		{
			parent.Display.location.href	=	processesPath +"/FO/GeneratePositionFile.cfm?TemplateName=Trading_PosGen&" +transParam;
		}
		//Added by santhu on 22-Jan-2004
		else if( tradingProcess.value == "20" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/OfflineOrderEntry/FO/OfflineOrderEntry.cfm?" +transParam;
		}		
		else if( tradingProcess.value == "21" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/OfflineOrderEntry/FO/OfflineOrderEntry.cfm?" +transParam;
		}		
		else if( tradingProcess.value == "222" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/ViewData/FO/CommodityDeliveryMarking.cfm?" +transParam;
		}
		else if( tradingProcess.value == "22" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/ProcessData/ManualContractEntry.cfm?" +transParam;
		}
		else if( tradingProcess.value == "23" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/ProcessData/Remeshire_Process.cfm?" +transParam;
		}
		else if( tradingProcess.value == "24" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/ProcessData/Arbitrage_DataEntry.cfm?" +transParam;
		}
		else if( tradingProcess.value == "25" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/ProcessData/ResetSettlementData.cfm?" +transParam;
		}
		else if( tradingProcess.value == "26" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/ProcessData/Arbitrage_pl_data.cfm?" +transParam;
		}
		else if( tradingProcess.value == "27" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/ProcessData/CAPS/WebX_File_Generation.cfm?" +transParam;
		}
		else if( tradingProcess.value == "28" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/ProcessData/ODIN/ODINFileGeneration.cfm?" +transParam;
		}
		else if( tradingProcess.value == "29" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/ProcessData/Trading_Pms_data.cfm?" +transParam;
		}
		else if( tradingProcess.value == "30" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/ProcessData/CAPS/STPFrame.cfm?" +transParam;
		}
		else if( tradingProcess.value == "31" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/ProcessData/Pms_GlobleProcess.cfm?" +transParam;
		}
		else if( tradingProcess.value == "32" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/ProcessData/ExchangeObligation.cfm?" +transParam;
		}
		else if( tradingProcess.value == "33" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/ProcessData/CAPS/UCCFORWEBXFILE.cfm?" +transParam;
		}
		else if( tradingProcess.value == "34" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/ProcessData/CAPS/ManualDematExpenseEntry.cfm?" +transParam;
		}
		else if( tradingProcess.value == "35" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/ProcessData/CAPS/UCI_File_Generation.cfm?" +transParam;
		}
		else if( tradingProcess.value == "36" )
		{
			parent.Display.location.href	=	processesPath +Market.value +"/CallProcesses.cfm?TemplateName=Trading_CallProcesses&PartialBill=Yes&" +transParam;
		}
		else if( tradingProcess.value == "37" )
		{
			parent.Display.location.href	=	processesPath +Market.value +"/PartialBillCancel.cfm?TemplateName=Trading_BillCancel&" +transParam;
		}
		else if( tradingProcess.value == "38" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/ProcessData/CAPS/InputGenerateTradeFile.cfm?" +transParam;
		}
		else if( tradingProcess.value == "39" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/ProcessData/FO/ManualAddMarginEntry.cfm?" +transParam;
		}
		else if( tradingProcess.value == "40" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/Reports/OrderScreen.cfm?" +transParam;
		}
		else if( tradingProcess.value == "41" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/ProcessData/CAPS/6a7aFileFrame.cfm?" +transParam;
		}
		else if( tradingProcess.value == "42" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/ProcessData/AsianCERCFileView.cfm?" +transParam;
		}
		else if( tradingProcess.value == "43" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/ProcessData/FO/SpanCalculator.cfm?" +transParam;
		}
		else if( tradingProcess.value == "44" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/ProcessData/FO/Commodity_Module.cfm?" +transParam;
		}
		else if( tradingProcess.value == "45" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/ProcessData/SDG/ORIANFileGen.cfm?" +transParam;
		}
		else if( tradingProcess.value == "46" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/ProcessData/MonthlyRemeshire_Process.cfm?" +transParam;
		}
		else
		{
			parent.Display.location.href	=	"/DEPOSITORY/DynamicFrame/BlankPage.html";
		}
	}
}


/* *********************************
	TRADING - REPORTS MENU ITEMS.
********************************* */
function TradingReportsNavigate( form, source )
{
	with( form )
	{
		reportsPath		=	"/DEPOSITORY/Reports/";
		reportsParam	=	"COCD=" +COCD.value +"&CoName=" +CoName.value +"&CoGroup=" +CoGroup.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=&CDSLPoolAccCode=" +CDSLPoolAccCode.value +"&CDSLDPID=" +CDSLDPID.value +"&CDSLDPName=" +CDSLDPName.value +"&NSDLPoolAccCode=" +NSDLPoolAccCode.value +"&NSDLDPID=" +NSDLDPID.value +"&NSDLDPName=" +NSDLDPName.value;
		
		tradingProcess[0].selected		=	true;
		tradingMasters[0].selected		=	true;
		TradingUserReports[0].selected	=	true;
		if( tradingReports.value == 38 )
		{
			parent.Display.location.href	=	"/DEPOSITORY/Common/SMS.cfm?"
		}
		else if( tradingReports.value == 39)
		{
			parent.Display.location.href	=	"/DEPOSITORY/SMSSENDER/SMSInputScreen.cfm?" +reportsParam;
		}
		else if( tradingReports.value == 45 ) 
		{
			parent.Display.location.href	=	"/DEPOSITORY/Reports/EOD.cfm?" +reportsParam;
		}
		else if( tradingReports.value == 40)
		{
			parent.Display.location.href	=	"/DEPOSITORY/SMSSENDER/DeleteSMS.cfm?" +reportsParam;
		}
		else if( tradingReports.value == 32 && Market.value == "CAPS")
		{
			parent.Display.location.href	=	"/DEPOSITORY/Reports/MIS/MISInputScreen.cfm?" +reportsParam;
		}
		else if( tradingReports.value == 41 && Market.value == "CAPS")
		{
			parent.Display.location.href	=	"/DEPOSITORY/Reports/MIS/RISKInputScreen.cfm?" +reportsParam;
		}
		else if( tradingReports.value == 34 && Market.value == "FO")
		{
			parent.Display.location.href	=	"/DEPOSITORY/Reports/MIS/MISInputScreen.cfm?" +reportsParam;
		}
		else if( tradingReports.value > 0 && source == 2 )
		{
			txttradingReports.value = tradingReports.value;
			/*parent.Display.location.href = reportsPath +Market.value +"/Parameters.cfm?" +reportsParam +"&REPORTID=" +tradingReports.value;*/
			parent.Display.location.href = reportsPath +Market.value +"/Parameters.cfm?TemplateName="+Market.value+"_"+tradingReports.value+"&"+reportsParam +"&REPORTID=" +tradingReports.value;
		}
		else if( txttradingReports.value > 0 && source == 1 )
		{
			tradingReports.value = txttradingReports.value;
			/*parent.Display.location.href = reportsPath +Market.value +"/Parameters.cfm?" +reportsParam +"&REPORTID=" +txttradingReports.value;*/
			parent.Display.location.href = reportsPath +Market.value +"/Parameters.cfm?TemplateName="+Market.value+"_"+txttradingReports.value+"&"+reportsParam +"&REPORTID=" +txttradingReports.value;
		}
		else
		{
			parent.Display.location.href = "/DEPOSITORY/DynamicFrame/BlankPage.html";
		}
	}
}

/* *********************************
	TRADING - REPORTS MENU ITEMS.
********************************* */
function TradingUserReportsNavigate( form, source )
{
	with( form )
	{
		reportsPath		=	 "/DEPOSITORY/FOCAPS_REPORTS/REPORTS_TEMPLATES";
		reportsParam	=	"COCD=" +COCD.value +"&CoName=" +CoName.value +"&CoGroup=" +CoGroup.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=&CDSLPoolAccCode=" +CDSLPoolAccCode.value +"&CDSLDPID=" +CDSLDPID.value +"&CDSLDPName=" +CDSLDPName.value +"&NSDLPoolAccCode=" +NSDLPoolAccCode.value +"&NSDLDPID=" +NSDLDPID.value +"&NSDLDPName=" +NSDLDPName.value ;

		tradingProcess[0].selected	=	true;
		tradingMasters[0].selected	=	true;
		tradingReports[0].selected	=	true;
		if(source == 3)
		{
			TradingUserReports.value=   txttradingReports.value
		}
		if( TradingUserReports.value > 0 )
		{
			txttradingReports.value = TradingUserReports.value;
			parent.Display.location.href = reportsPath +"/REPORT_PARAMETERS.cfm?Segment="+Market.value + "&Template_ID="+TradingUserReports.value+"&"+reportsParam +"&REPORT_ID=" +TradingUserReports.value;
		}
		else
		{
			parent.Display.location.href = reportsPath +"/REPORT_PARAMETERS.cfm?Segment="+Market.value + "&Template_ID="+txttradingReports.value+"&"+reportsParam +"&REPORT_ID=" +txttradingReports.value;
		}
	}
}

/* ***********************************************
	FINANCIAL ACCOUNTING - MASTERS MENU ITEMS.
*********************************************** */
function AccountMastersNavigate( form )
{
	with( form )
	{
		mainPath	=	"/DEPOSITORY/FA_FOCAPS/Forms/";
		bsPath		=	"/DEPOSITORY/FA_FOCAPS/BalanceSheet/";
		param		=	"COCD=" +COCD.value +"&CoName=" +escape(CoName.value) +"&CoGroup=" +CoGroup.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&StYr=" +FinStart.value +"&EndYr=" +FinEnd.value +"&CDSLPoolAccCode=" +CDSLPoolAccCode.value +"&CDSLDPID=" +CDSLDPID.value +"&CDSLDPName=" +CDSLDPName.value +"&NSDLPoolAccCode=" +NSDLPoolAccCode.value +"&NSDLDPID=" +NSDLDPID.value +"&NSDLDPName=" +NSDLDPName.value;
		faVouchers[0].selected	=	true;
		faReports[0].selected	=	true;
		faUserReports[0].selected	=	true;
		
		if( faMasters.value == "1" )
		{
			//COMPANY LIST
			parent.Display.location.href	=	mainPath +"Main.cfm?TemplateName=Accounts_companyList"
		}
		else if( faMasters.value == "2" )
		{
			//FAMILY GROUP
			parent.Display.location.href	=	"/DEPOSITORY/Masters/FamilyMaster.cfm?TemplateName=Accounts_FamilyMaster&" + param;
		}
		else if( faMasters.value == "3" )
		{
			//GENERAL LEDGER
			parent.Display.location.href	=	mainPath +"Ledger.cfm?TemplateName=Accounts_Ledger&" + param;
		}
		else if( faMasters.value == "4" )
		{
			//OPENING BALANCE
			parent.Display.location.href	=	mainPath +"OpeningBalanceUpdation.cfm?TemplateName=Accounts_OpeningBalanceUpdation&" +param;
		}
		else if( faMasters.value == "5" )
		{
			//NARRATION
			parent.Display.location.href	=	mainPath +"Narration.cfm?TemplateName=Accounts_Narration&" +param;
		}
		else if( faMasters.value == "6" )
		{
			//TRANSFER ACCOUNTS
			parent.Display.location.href	=	mainPath +"TransferAccounts.cfm?TemplateName=Accounts_TransferAccounts&" +param;			
		}
		else if( faMasters.value == "7" )
		{
			//FIN YR PROCESS
			parent.Display.location.href	=	mainPath +"FinYrProcess.cfm?TemplateName=Accounts_FinYrProcess&" +param;
		}
		else if( faMasters.value == "8" )
		{
			//ACCOUNT POSTING
			parent.Display.location.href	=	mainPath +"LogEntry.cfm?TemplateName=Accounts_LogEntry&" +param;
		}
		else if( faMasters.value == "10" )
		{
			//MAIN1
			parent.Display.location.href	=	bsPath +"LayerFrame.cfm?TemplateName=Accounts_LayerFrameMain&Layer=Main&" +param;	
			
		}
		else if( faMasters.value == "11" )
		{
			//GROUP
			parent.Display.location.href	=	bsPath +"LayerFrame.cfm?TemplateName=Accounts_LayerFrameGroups&Layer=Group&" +param;
		}
		else if( faMasters.value == "12" )
		{
			//SCHEDULE
			parent.Display.location.href	=	bsPath +"LayerFrame.cfm?TemplateName=Accounts_LayerFrameSchedule&Layer=Schedule&" +param;
		}
		else if( faMasters.value == "13" )
		{
			//GROUPING
			parent.Display.location.href	=	bsPath +"LayerFrame.cfm?TemplateName=Accounts_LayerFrameGrouping&Layer=Grouping&" +param;
		}
		else if( faMasters.value == "14" )
		{
			// PL & BS DESIGNER
			parent.Display.location.href	=	"/DEPOSITORY/FA_FOCAPS/Forms/PLBSDesigner.CFM?TemplateName=FA_PL_BS_DESIGNER&" + param;
		}
		else if( faMasters.value == "15" )
		{
			// Report Menu Creation
			parent.Display.location.href	=	"/DEPOSITORY/FOCAPS_REPORTS/REPORTS_TEMPLATES/REPORT_MASTER_ENTRY.CFM?TemplateName=FA_REPORT_MASTER_ENTRY&Report_Segment=FA";
		}
		else if( faMasters.value == "16" )
		{
			// Report Menu Creation
			parent.Display.location.href	=	"/DEPOSITORY/FA_FOCAPS/Forms/Micr_Master.cfm?TemplateName=Micr_Master&" + param;
		}
		else if( faMasters.value == "17" )
		{
			parent.Display.location.href	=	bsPath +"BalanceSheetMaster.cfm?TemplateName=FA_PL_BS_Master&" + param;
		}
		else if( faMasters.value == "18" )
		{
			parent.Display.location.href	=	mainPath +"LedgerDeletion.cfm?TemplateName=FA_PL_BS_Master&" + param;
		}
		else
		{
			parent.Display.location.href	=	"/DEPOSITORY/DynamicFrame/BlankPage.html";
		}
	}
}


/* ****************************************************
	FINANCIAL ACCOUNTING - TRANSACTIONS MENU ITEMS.
**************************************************** */
function AccountProcessNavigate( form )
{
	with( form )
	{
		mainPath	=	"/DEPOSITORY/FA_FOCAPS/Forms/"
		param		=	"COCD=" +COCD.value +"&CoName=" +CoName.value +"&CoGroup=" +CoGroup.value +"&StYr=" +FinStart.value +"&EndYr=" +FinEnd.value +"&CDSLPoolAccCode=" +CDSLPoolAccCode.value +"&CDSLDPID=" +CDSLDPID.value +"&CDSLDPName=" +CDSLDPName.value +"&NSDLPoolAccCode=" +NSDLPoolAccCode.value +"&NSDLDPID=" +NSDLDPID.value +"&NSDLDPName=" +NSDLDPName.value;
		
		faMasters[0].selected	=	true;
		faReports[0].selected	=	true;
	    faUserReports[0].selected	=	true;
		if( faVouchers.value == "1" )
		{
			//RECEIPT VOUCHER
			parent.Display.location.href	=	mainPath +"ReceiptPayment.cfm?TemplateName=Accounts_Receipt&Bank=Yes&TransactionType=Receipt&Tr_Type=R&" +param;
		}
		else if( faVouchers.value == "2" )
		{
			//PAYMENT VOUCHER
			parent.Display.location.href	=	mainPath +"ReceiptPayment.cfm?TemplateName=Accounts_Payment&Bank=Yes&TransactionType=Payment&Tr_Type=P&" +param;
		}
		else if( faVouchers.value == "3" )
		{
			//JOURNAL VOUCHER 
			/*parent.Display.location.href	=	mainPath +"Journal.cfm?&JV=Normal&" +param;*/
			parent.Display.location.href	=	mainPath +"Journal.cfm?TemplateName=Accounts_Journal&JV=Normal&" +param;
		}
		else if( faVouchers.value == "4" )
		{
			///CONTRA VOUCHER
			var date1 = new Date();		
			var Day = date1.getDate();
			var Month = date1.getMonth()+1;			
			var Hour = date1.getHours();
			var Mininute = date1.getMinutes();
			var Seconds = date1.getSeconds();
			//alert(Day);
			//alert(Month);			
			var t = Day+""+Month+""+date1.getFullYear()+Hour+""+Mininute+""+Seconds;
			parent.Display.location.href	=	mainPath +"ContraVoucher.cfm?TemplateName=Accounts_ContraVoucher&New=Yes&Journal=Yes&Token=C"+t +"&"+param;
		}
		else if( faVouchers.value == "6" )
		{
			//SYSTEM JOURNAL
			parent.Display.location.href	=	mainPath +"VoucherView.cfm?TemplateName=Accounts_VoucherView&tr_type=SJ&" +param;			
		}
		else if( faVouchers.value == "8" )
		{
			//TRANSACTION TRANSFER
			parent.Display.location.href	=	mainPath +"TransactionTransfer.cfm?TemplateName=Accounts_TransactionTransfer&" +param;
		}
		else if( faVouchers.value == "9" )
		{
			//RECEIPT VOUCHER
			parent.Display.location.href	=	mainPath +"RequestAcceptance.cfm?TemplateName=Accounts_RequestAccept&" +param;
		}
		else if( faVouchers.value == "10" )
		{
			//Import
			parent.Display.location.href	=	mainPath +"Import.cfm?TemplateName=Accounts_Import&" +param;
		}
		else if( faVouchers.value == "11" )
		{
			//Import
			parent.Display.location.href	=	mainPath +"BRS_MissingReport.cfm?TemplateName=Accounts_Missing&ProcessType=Process&" +param;
		}
		else if( faVouchers.value == "12" )
		{
			//Auto Manual Voucherno Posting
			parent.Display.location.href	=	mainPath +"AutoUpdationForManualVoucher.cfm?TemplateName=Accounts_AutoManual&" +param;
		}
		else if( faVouchers.value == "13" )
		{
			//Import Voucher Posting
			parent.Display.location.href	=	mainPath +"ImportVoucher.cfm?TemplateName=Accounts_ImpVoucher&" +param;
		}
		else if( faVouchers.value == "14" )
		{
			//Global Ledger Summery
			parent.Display.location.href	=	mainPath +"GlobalLedgerSummery.cfm?TemplateName=Accounts_GlobalView&" +param;
		}
		else if( faVouchers.value == "15" )
		{
			//Global Ledger Summery
			parent.Display.location.href	=	mainPath +"FundTransfer.cfm?TemplateName=FundTransfer&" +param;
		}
		else if( faVouchers.value == "16" )
		{
			
			parent.Display.location.href	=	mainPath +"Receipt_Payment_Generation.cfm?TemplateName=ReceiptPayment&" + param + "&CoGroup=" +CoGroup.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value  ;
		}
		else if( faVouchers.value == "17" )
		{
			
			parent.Display.location.href	=	"/DEPOSITORY/PROCESSDATA/CAPS/MonthlyProcess.cfm?TemplateName=ReceiptPayment&" + param + "&CoGroup=" +CoGroup.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value  ;
		}
		else if( faVouchers.value == "18" )
		{
			
			parent.Display.location.href	=	"/DEPOSITORY/PROCESSDATA/CAPS/ShortageJVProcess.cfm?TemplateName=Shortage&" + param + "&CoGroup=" +CoGroup.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value  ;
		}
		else if( faVouchers.value == "19" )
		{
			parent.Display.location.href	=	mainPath +"JV.cfm?TemplateName=Accounts_Journal&JV=Normal&" +param;
		}

		else if( faVouchers.value == "20" )
		{
			parent.Display.location.href	=	mainPath +"JV_aUTH_VoucherView.cfm?TemplateName=Accounts_Journal&&tr_type=J&JV=Normal&" +param;
		}
		else if( faVouchers.value == "21" )
		{
			
			parent.Display.location.href	=	mainPath  + "Epayment.cfm?TemplateName=Epayment&"+ param +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value  ;
		}
		else if( faVouchers.value == "22" )
		{
			parent.Display.location.href	=	mainPath +"BILL_FundTransfer.cfm?TemplateName=FundTransfer&" +param;
		}
		else if( faVouchers.value == "23" )
		{
			parent.Display.location.href	=	mainPath +"Rec_aUTH_VoucherView.cfm?TemplateName=Accounts_Receipt&tr_type=R&JV=Normal&" +param;
		}
		else if( faVouchers.value == "24" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/receiptEntry/index.cfm?TemplateName=Accounts_Receipt&tr_type=R&JV=Normal&" +param;
		}
		else if( faVouchers.value == "25" )
		{
			parent.Display.location.href	=	mainPath +"Receipt_Payment_Generation_UnAutho.cfm?TemplateName=ReceiptPayment&" + param + "&CoGroup=" +CoGroup.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value  ;
		}
		else if( faVouchers.value == "26" )
		{
			parent.Display.location.href	=	mainPath +"Receipt_Payment_Generation_Autho.cfm?TemplateName=ReceiptPayment&" + param + "&CoGroup=" +CoGroup.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value  ;
		}
		else if( faVouchers.value == "27" )
		{
			parent.Display.location.href	=	mainPath +"Debit_Journal.cfm?TemplateName=Accounts_Journal&JV=Normal&" +param;
		}
		else if( faVouchers.value == "28" )
		{
			parent.Display.location.href	=	mainPath +"Credit_Journal.cfm?TemplateName=Accounts_Journal&JV=Normal&" +param;
		}
		else if( faVouchers.value == "29" )
		{
			parent.Display.location.href	=	mainPath +"Salary_Payment.cfm?TemplateName=Accounts_Receipt&Bank=Yes&TransactionType=Payment&Tr_Type=P&" +param;
		}
		else if( faVouchers.value == "30" )
		{
			parent.Display.location.href	=	mainPath +"ReceiptWithJV_First.cfm?TemplateName=Accounts_Receipt&Bank=Yes&TransactionType=Receipt&Tr_Type=R&" +param;
		}
		else if( faVouchers.value == "31" )
		{
			parent.Display.location.href	=	mainPath +"EXPENSE_Journal.cfm?TemplateName=Accounts_Journal&JV=Normal&" +param;
		}
		else if( faVouchers.value == "32" )
		{
			parent.Display.location.href	=	mainPath +"Bank_Guarantee.cfm?TemplateName=Bank_Guarantee&" +param;
		}
		else if( faVouchers.value == "33" )
		{
			parent.Display.location.href	=	mainPath +"BrsMainScreen.cfm?TemplateName=BRS&" +param;
		}
		else if( faVouchers.value == "34" )
		{
			parent.Display.location.href	=	mainPath +"BankTransactionMainScreen.cfm?TemplateName=Bank_Transaction&" +param;
		}
		else if( faVouchers.value == "35" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/PROCESSDATA/CAPS/FrmDailyProcess.cfm?TemplateName=Daily_Weekly_Process&" + param + "&CoGroup=" +CoGroup.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value  ;
		}
		else if( faVouchers.value == "50" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/PROCESSDATA/fa_IMPORT_MASTER.cfm?TemplateName=Trading_Import&" + param + "&CoGroup=" +CoGroup.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value  ;;
		}
		else if( faVouchers.value == "51" )
		{
			parent.Display.location.href	=	mainPath +"NBFCFundTransfer.cfm?TemplateName=FundTransfer&" +param;
		}
		else if( faVouchers.value == "55" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/PROCESSDATA/CAPS/FrmNBFCDailyProcess.cfm?TemplateName=Daily_Weekly_Process&" + param + "&CoGroup=" +CoGroup.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value  ;
		}
		else if( faVouchers.value == "59" )
		{
			parent.Display.location.href	=	mainPath +"BrsiiMainScreen.cfm?TemplateName=BRS&" +param;
		}
		else
		{
			parent.Display.location.href	=	"/DEPOSITORY/DynamicFrame/BlankPage.html";
		}
	}
}


/* ***********************************************
	FINANCIAL ACCOUNTING - REPORTS MENU ITEMS.
*********************************************** */
function AccountingReportsNavigate( form, source )
{
	with( form )
	{
		
		faMasters[0].selected	=	true;
		faVouchers[0].selected	=	true;
	    faUserReports[0].selected	=	true;
		param	=	"COCD=" +COCD.value +"&CoName=" +escape(CoName.value) +"&CoGroup=" +CoGroup.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&StYr=" +FinStart.value +"&EndYr=" +FinEnd.value +"&CDSLPoolAccCode=" +CDSLPoolAccCode.value +"&CDSLDPID=" +CDSLDPID.value +"&CDSLDPName=" +CDSLDPName.value +"&NSDLPoolAccCode=" +NSDLPoolAccCode.value +"&NSDLDPID=" +NSDLDPID.value +"&NSDLDPName=" +NSDLDPName.value;

		if(faReports.value > 0 && source == 2)
		{
			txtfaReports.value				=	faReports.value;		
			parent.Display.location.href	=	"/DEPOSITORY/FA_FOCAPS/Reports/Parameters1.cfm?Template_ID="+faReports.value+"&REPORTID=" +faReports.value+"&" + param;
		}
		else if(txtfaReports.value > 0 && source == 1)
		{
			faReports.value					=	txtfaReports.value;		
			parent.Display.location.href	=	"/DEPOSITORY/FA_FOCAPS/Reports/Parameters1.cfm?Template_ID="+txtfaReports.value+"&REPORTID=" +txtfaReports.value+"&" + param;
		}
		else
		{
			parent.Display.location.href	=	"/DEPOSITORY/DynamicFrame/BlankPage.html";
		}
		
	}
}

function FAUserReportsNavigate( form, source )
{
	with( form )
	{
		reportsPath		=	"/DEPOSITORY/FOCAPS_REPORTS/REPORTS_TEMPLATES";
		reportsParam	=	"COCD=" +COCD.value +"&CoName=" +CoName.value +"&CoGroup=" +CoGroup.value +"&Market=FA&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=&CDSLPoolAccCode=" +CDSLPoolAccCode.value +"&CDSLDPID=" +CDSLDPID.value +"&CDSLDPName=" +CDSLDPName.value +"&NSDLPoolAccCode=" +NSDLPoolAccCode.value +"&NSDLDPID=" +NSDLDPID.value +"&NSDLDPName=" +NSDLDPName.value;
		
		faVouchers[0].selected	=	true;
		faMasters[0].selected	=	true;
		faReports[0].selected	=	true;
		
		if(source == 3)
		{
			faUserReports.value=   txtfaReports.value
		}
		if( faUserReports.value > 0 )
		{
			txtfaReports.value = faUserReports.value;
			parent.Display.location.href = reportsPath +"/REPORT_PARAMETERS.cfm?Segment=FA&Template_ID="+faUserReports.value+"&"+reportsParam +"&REPORT_ID=" +faUserReports.value;
		}
		else
		{
			parent.Display.location.href = reportsPath +"/REPORT_PARAMETERS.cfm?Segment=FA&Template_ID="+txtfaReports.value+"&"+reportsParam +"&REPORT_ID=" +txtfaReports.value;
		}
	}
}


/* **************************************
		REFRESH FA FRAME
************************************** */
function refreshFrame( segment )
{
	with( TopFrameForm )
	{
		FinEnd.value	=	( parseInt( new Number( FinStart.value ) ) + 1 );
		
		if( ( segment == "FA" ) && ( faReports.value > 0 ) )
		{
			parent.Display.location.href	=	"/DEPOSITORY/FA_FOCAPS/Reports/Parameters1.cfm?COCD=" +COCD.value +"&CoName=" +CoName.value +"&CoGroup=" +CoGroup.value +"&StYr=" +FinStart.value +"&EndYr=" +FinEnd.value +"&CDSLPoolAccCode=" +CDSLPoolAccCode.value +"&CDSLDPID=" +CDSLDPID.value +"&CDSLDPName=" +CDSLDPName.value +"&NSDLPoolAccCode=" +NSDLPoolAccCode.value +"&NSDLDPID=" +NSDLDPID.value +"&NSDLDPName=" +NSDLDPName.value +"&REPORTID=" +txtfaReports.value;
		}
		else
		{
			parent.Display.location.href	=	"/DEPOSITORY/DynamicFrame/BlankPage.html";
			parent.Query.location.href		=	"/DEPOSITORY/DynamicFrame/Queries.cfm?Segment=" +segment +"&queryfor=COMPANY&FormObject=parent.Support.document.TopFrameForm";
		}
	}
}


/* ****************************************
	TRADING SYSTEM - COMPANY-CODE ITEMS.
**************************************** */
function CompanyList( form )
{
	with( form )
	{
		parent.Display.location.href	=	"/DEPOSITORY/DynamicFrame/BlankPage.html?Segment=" +Segment.value;
		parent.Query.location.href		=	"/DEPOSITORY/DynamicFrame/Queries.cfm?Segment=" +Segment.value +"&queryfor=COMPANY&FormObject=parent.Support.document.TopFrameForm";
		//FinStart.value	=	"2003";
		//FinEnd.value	=	"2004";
		if( Segment.value == "FA" || Segment.value == "IO" )
		{
			//lblBranch.style.display		=	"None";

		}
		else
		{
			//lblBranch.style.display		=	"";
		}
		
		if( Segment.value == "TRADING" )
		{
			TradingMenu.style.display	=	"";
			AccountsMenu.style.display	=	"None";
			StockMenu.style.display		=	"None";
		}
		
		if( Segment.value == "FA" )
		{
			TradingMenu.style.display	=	"None";
			faReports[0].selected		=	true;
			AccountsMenu.style.display	=	"";
			StockMenu.style.display		=	"None";
		}
		
		if( Segment.value == "IO" )
		{
			TradingMenu.style.display	=	"None";
			ioReports[0].selected		=	true;
			AccountsMenu.style.display	=	"None";
			StockMenu.style.display		=	"";
		}
	}
}


/* ****************************************
	TRADING SYSTEM - COMPANY-NAME ITEMS.
**************************************** */
function CompanyName( form )
{
	with( form )
	{
		parent.Query.location.href		=	"/DEPOSITORY/DynamicFrame/Queries.cfm?Segment=" +Segment.value +"&COCD=" +COCD.value +"&CoGroup=" +CoGroup.value +"&queryfor=NAME&FormObject=parent.Support.document.TopFrameForm";
		
		if( Segment.value == "FA" || Segment.value == "IO" )
		{
			//lblBranch.style.display		=	"None";
		}
		else
		{
			//lblBranch.style.display		=	"";
		}
		
		if( Segment.value == "FA" )
		{
			//AccountingReportsNavigate(TopFrameForm,'2');
		}	
		
		if( Segment.value == "TRADING" )
		{
			TradingMenu.style.display	=	"";
			tradingMasters[0].selected	=	true;
			tradingProcess[0].selected	=	true;
		    TradingUserReports[0].selected	=	true;
			AccountsMenu.style.display	=	"None";
			StockMenu.style.display		=	"None";
		}
		
		if( Segment.value == "FA" )
		{
			TradingMenu.style.display	=	"None";
			faMasters[0].selected		=	true;
			faVouchers[0].selected		=	true;
			faUserReports[0].selected	=	true;
			AccountsMenu.style.display	=	"";
			StockMenu.style.display		=	"None";
		}
		
		if( Segment.value == "IO" )
		{
			TradingMenu.style.display	=	"None";
			ioMasters[0].selected		=	true;
			ioVouchers[0].selected		=	true;
			StockUserReports[0].selected	=	true;
			AccountsMenu.style.display	=	"None";
			StockMenu.style.display		=	"";
		}
	}
}


/* *************************************************
	STOCK INWARD / OUTWARD - MASTERS MENU ITEMS.
************************************************* */
function IOMastersNavigate( form )
{
	with( form )
	{
		mastersPath		=	"/DEPOSITORY/IO_FOCAPS/Masters/";
		benMasterPath	=	"/DEPOSITORY/BENEFICIARY/Masters/";
		mastersParam	=	"COCD=" +COCD.value +"&CoName=" +CoName.value +"&CoGroup=" +CoGroup.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStYr=" +FinStart.value +"&FinEndYr=" +FinEnd.value +"&Branch=&CDSLPoolAccCode=" +CDSLPoolAccCode.value +"&CDSLDPID=" +CDSLDPID.value +"&CDSLDPName=" +CDSLDPName.value +"&NSDLPoolAccCode=" +NSDLPoolAccCode.value +"&NSDLDPID=" +NSDLDPID.value +"&NSDLDPName=" +NSDLDPName.value;
		
		ioVouchers[0].selected	=	true;
		ioReports[0].selected	=	true;
		StockUserReports[0].selected =	true;
		if( ioMasters.value == "1" )
		{
			/*parent.Display.location.href	=	"/DEPOSITORY/Common/CompanyList.cfm";*/
			parent.Display.location.href	=	"/DEPOSITORY/Common/CompanyList.cfm?TemplateName=Stock_CompanyList";
		}
		else if( ioMasters.value == "7" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/FOCAPS_REPORTS/REPORTS_TEMPLATES/REPORT_MASTER_ENTRY.CFM?TemplateName=IO_REPORT_MASTER_ENTRY&Report_Segment=IO";
		}
		else if( ioMasters.value == "8" )
		{
			parent.Display.location.href	=	mastersPath + "IO_SYSTEMSETTINGS.CFM?"+mastersParam;
		}
		else if( ioMasters.value == "9" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/CDSL/Masters/ImportCDSL_ClientMaster.CFM?"+mastersParam;
		}
		else if( ioMasters.value == "10" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/CDSL/Masters/Cdsl_Global_FeeMaster.cfm?" +mastersParam;
		}
		else if( ioMasters.value == "11" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/CDSL/Masters/Cdsl_Trans_Nature.cfm?" +mastersParam;
		}
		else if( ioMasters.value == "12" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/CDSL/Masters/Cdsl_SrvTax_Master.cfm?" +mastersParam;
		}
		else if( ioMasters.value == "13" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/CDSL/Masters/Cdsl_CompanyMaster.cfm?" +mastersParam;
		}
		else if( ioMasters.value == "14" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/CDSL/Masters/Cdsl_OtherCharges_Master.cfm?" +mastersParam;
		}
		else if( ioMasters.value == "15" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/CDSL/Masters/Cdsl_ClientMaster.cfm?" +mastersParam;
		}
		else if( ioMasters.value == "16" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/CDSL/Masters/NewCdslClientMaster.cfm?" +mastersParam;
		}
		else if( ioMasters.value == "17" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/CDSL/Masters/CDSLModuleMaster.cfm?" +mastersParam;
		}
		else if( ioMasters.value == "18" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/CDSL/Masters/CDSL_WelComeLetter.cfm?" +mastersParam;
		}
		else if( ioMasters.value == "20" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/Masters/Nsdl_BO_Type_Master.cfm?" +mastersParam;
		}
		else if( ioMasters.value == "21" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/Masters/Nsdl_BO_Occupation_Master.cfm?" +mastersParam;
		}
		else if( ioMasters.value == "22" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/Masters/Nsdl_BO_Status_Master.cfm?" +mastersParam;
		}
		else if( ioMasters.value == "25" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/Masters/Nsdl_BP_Role_Master.cfm?" +mastersParam;
		}
		else if( ioMasters.value == "26" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/Masters/Nsdl_BP_Category_Master.cfm?" +mastersParam;
		}
		else if( ioMasters.value == "27" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/Masters/Nsdl_BP_Status_Master.cfm?" +mastersParam;
		}
		else if( ioMasters.value == "49" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/Masters/" + "Dp_Modules.cfm?TemplateName=Modules&" +mastersParam;
		}
		else if( ioMasters.value == "50" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/Masters/" + "NSDL_NewClient.cfm?TemplateName=ClientMaster&" +mastersParam;
		}
		else if( ioMasters.value == "51" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/Masters/" + "BranchMaster_EntryForm.cfm?TemplateName=BranchMaster&" +mastersParam;
		}
		else if( ioMasters.value == "52" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/Masters/" + "Nsdl_BO_Category_Master.cfm?TemplateName=ClientMaster&" +mastersParam;
		}
		else if( ioMasters.value == "53" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/Masters/" + "GroupMaster_EntryForm.cfm?TemplateName=GroupMaster&" +mastersParam;
		}
		else if( ioMasters.value == "54" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/Masters/" + "SubGroupMaster_EntryForm.cfm?TemplateName=SubGroupMaster&" +mastersParam;
		}
		else if( ioMasters.value == "56" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/Masters/" + "Nsdl_VendorMaster.cfm?TemplateName=VendorMaster&" +mastersParam;
		}
		else if( ioMasters.value == "58" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/Masters/" + "Nsdl_Book_Size_Master.cfm?TemplateName=BookSizeMaster&" +mastersParam;
		}
		else if( ioMasters.value == "59" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/Masters/" + "DP_Master.cfm?TemplateName=MasterMenu&" +mastersParam;
		}
		else if( ioMasters.value == "60" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/Masters/" + "Nsdl_Courier_Master.cfm?TemplateName=MasterMenu&" +mastersParam;
		}
		else if( ioMasters.value == "61" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/Masters/" + "Nsdl_SlipBk_Issue_Master.cfm?TemplateName=MasterMenu&" +mastersParam;
		}
		else if( ioMasters.value == "62" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/Masters/" + "Nsdl_Loose_Slip_Master.cfm?TemplateName=MasterMenu&" +mastersParam;
		}
		else if( ioMasters.value == "63" )
		{
			mastersParam	=	"COCD=" +COCD.value +"&CoName=" +CoName.value +"&CoGroup=" +CoGroup.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=&CDSLPoolAccCode=" +CDSLPoolAccCode.value +"&CDSLDPID=" +CDSLDPID.value +"&CDSLDPName=" +CDSLDPName.value +"&NSDLPoolAccCode=" +NSDLPoolAccCode.value +"&NSDLDPID=" +NSDLDPID.value +"&NSDLDPName=" +NSDLDPName.value;
			parent.Display.location.href	=	"/DEPOSITORY/Masters/" + "Nsdl_Instruction_Slip_Master.cfm?TemplateName=Block&" +mastersParam;
		}
		else if( ioMasters.value == "64" )
		{
			mastersParam	=	"COCD=" +COCD.value +"&CoName=" +CoName.value +"&CoGroup=" +CoGroup.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=&CDSLPoolAccCode=" +CDSLPoolAccCode.value +"&CDSLDPID=" +CDSLDPID.value +"&CDSLDPName=" +CDSLDPName.value +"&NSDLPoolAccCode=" +NSDLPoolAccCode.value +"&NSDLDPID=" +NSDLDPID.value +"&NSDLDPName=" +NSDLDPName.value;
			parent.Display.location.href	=	"/DEPOSITORY/Masters/" + "Nsdl_Instruction_Slip_Master.cfm?TemplateName=Revoke&" +mastersParam;
		}
		else if( ioMasters.value == "65" )
		{
			mastersParam	=	"COCD=" +COCD.value +"&CoName=" +CoName.value +"&CoGroup=" +CoGroup.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=&CDSLPoolAccCode=" +CDSLPoolAccCode.value +"&CDSLDPID=" +CDSLDPID.value +"&CDSLDPName=" +CDSLDPName.value +"&NSDLPoolAccCode=" +NSDLPoolAccCode.value +"&NSDLDPID=" +NSDLDPID.value +"&NSDLDPName=" +NSDLDPName.value;
			parent.Display.location.href	=	"/DEPOSITORY/Masters/" + "Nsdl_Bulk_Slip_Book_Master.cfm?TemplateName=MasterMenu&" +mastersParam;
		}
		else if( ioMasters.value == "67" )
		{
			mastersParam	=	"COCD=" +COCD.value +"&CoName=" +CoName.value +"&CoGroup=" +CoGroup.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=&CDSLPoolAccCode=" +CDSLPoolAccCode.value +"&CDSLDPID=" +CDSLDPID.value +"&CDSLDPName=" +CDSLDPName.value +"&NSDLPoolAccCode=" +NSDLPoolAccCode.value +"&NSDLDPID=" +NSDLDPID.value +"&NSDLDPName=" +NSDLDPName.value;
			parent.Display.location.href	=	"/DEPOSITORY/Masters/" + "Nsdl_Slip_Inward.cfm?TemplateName=MasterMenu&" +mastersParam;
		}
		else if( ioMasters.value == "70" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/Masters/" + "Nsdl_Transaction_Master.cfm?TemplateName=MasterMenu&" +mastersParam;
		}
		else if( ioMasters.value == "101" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/Masters/" + "Nsdl_Narration_Master.cfm?TemplateName=MasterMenu&" +mastersParam;
		}
		else if( ioMasters.value == "107" )
		{
				mastersPath		=	"/DEPOSITORY/Masters/";
				mastersParam	=	"COCD=" +COCD.value +"&CoName=" +CoName.value +"&CoGroup=" +CoGroup.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=&CDSLPoolAccCode=" +CDSLPoolAccCode.value +"&CDSLDPID=" +CDSLDPID.value +"&CDSLDPName=" +CDSLDPName.value +"&NSDLPoolAccCode=" +NSDLPoolAccCode.value +"&NSDLDPID=" +NSDLDPID.value +"&NSDLDPName=" +NSDLDPName.value;
				parent.Display.location.href	=	mastersPath +"Nsdl_Isin_Master.cfm?TemplateName=Trading_ScripMaster&" +mastersParam;
		}
		else if( ioMasters.value == "108" )
		{
				//Securities Status
				mastersPath		=	"/DEPOSITORY/Masters/";
				mastersParam	=	"COCD=" +COCD.value +"&CoName=" +CoName.value +"&CoGroup=" +CoGroup.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=&CDSLPoolAccCode=" +CDSLPoolAccCode.value +"&CDSLDPID=" +CDSLDPID.value +"&CDSLDPName=" +CDSLDPName.value +"&NSDLPoolAccCode=" +NSDLPoolAccCode.value +"&NSDLDPID=" +NSDLDPID.value +"&NSDLDPName=" +NSDLDPName.value;
				parent.Display.location.href	=	mastersPath +"Nsdl_Security_Type_Master.cfm?TemplateName=Trading_ScripMaster&" +mastersParam;
		}
		else if( ioMasters.value == "109" )
		{
				//Securities Type
				mastersPath		=	"/DEPOSITORY/Masters/";
				mastersParam	=	"COCD=" +COCD.value +"&CoName=" +CoName.value +"&CoGroup=" +CoGroup.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=&CDSLPoolAccCode=" +CDSLPoolAccCode.value +"&CDSLDPID=" +CDSLDPID.value +"&CDSLDPName=" +CDSLDPName.value +"&NSDLPoolAccCode=" +NSDLPoolAccCode.value +"&NSDLDPID=" +NSDLDPID.value +"&NSDLDPName=" +NSDLDPName.value;
				parent.Display.location.href	=	mastersPath +"Nsdl_Security_Status_Master.cfm?TemplateName=Trading_ScripMaster&" +mastersParam;
		}

		else if( ioMasters.value == "113" )
		{
			mastersPath		=	"/DEPOSITORY/Masters/";
			mastersParam	=	"COCD=" +COCD.value +"&CoName=" +CoName.value +"&CoGroup=" +CoGroup.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=&CDSLPoolAccCode=" +CDSLPoolAccCode.value +"&CDSLDPID=" +CDSLDPID.value +"&CDSLDPName=" +CDSLDPName.value +"&NSDLPoolAccCode=" +NSDLPoolAccCode.value +"&NSDLDPID=" +NSDLDPID.value +"&NSDLDPName=" +NSDLDPName.value;
			parent.Display.location.href	=	mastersPath +"Nsdl_Market_Master.cfm?ReplaceMaster.cfm?TemplateName=Trading_MarketTypeMaster&" +mastersParam;
		}
		else if( ioMasters.value == "114" )
		{
			mastersPath		=	"/DEPOSITORY/Masters/";
			mastersParam	=	"COCD=" +COCD.value +"&CoName=" +CoName.value +"&CoGroup=" +CoGroup.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=&CDSLPoolAccCode=" +CDSLPoolAccCode.value +"&CDSLDPID=" +CDSLDPID.value +"&CDSLDPName=" +CDSLDPName.value +"&NSDLPoolAccCode=" +NSDLPoolAccCode.value +"&NSDLDPID=" +NSDLDPID.value +"&NSDLDPName=" +NSDLDPName.value;
			parent.Display.location.href	=	mastersPath +"Nsdl_CC_Calendar_Master.cfm?TemplateName=Trading_MarketTypeMaster&" +mastersParam;
		}
		else if( ioMasters.value == "115" )
		{
				//Sectore
				mastersPath		=	"/DEPOSITORY/Masters/";
				mastersParam	=	"COCD=" +COCD.value +"&CoName=" +CoName.value +"&CoGroup=" +CoGroup.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=&CDSLPoolAccCode=" +CDSLPoolAccCode.value +"&CDSLDPID=" +CDSLDPID.value +"&CDSLDPName=" +CDSLDPName.value +"&NSDLPoolAccCode=" +NSDLPoolAccCode.value +"&NSDLDPID=" +NSDLDPID.value +"&NSDLDPName=" +NSDLDPName.value;
				parent.Display.location.href	=	mastersPath +"Nsdl_Sector_Master.cfm?TemplateName=Trading_ScripMaster&" +mastersParam;
		}
		else if( tradingMasters.value == "200" )
		{	
			mastersPath		=	"/DEPOSITORY/Masters/";
			mastersParam	=	"COCD=" +COCD.value +"&CoName=" +CoName.value +"&CoGroup=" +CoGroup.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=&CDSLPoolAccCode=" +CDSLPoolAccCode.value +"&CDSLDPID=" +CDSLDPID.value +"&CDSLDPName=" +CDSLDPName.value +"&NSDLPoolAccCode=" +NSDLPoolAccCode.value +"&NSDLDPID=" +NSDLDPID.value +"&NSDLDPName=" +NSDLDPName.value;
			parent.Display.location.href	=	mastersPath +"PrinterMaster.cfm?TemplateName=CAPS_Corp_Action&" +mastersParam;
		}



	}
}


/* ******************************************************
	STOCK INWARD / OUTWARD - TRANSACTIONS MENU ITEMS.
****************************************************** */
function IOVouchersNavigate( form )
{
	with( form )
	{
		transPath	=	"/DEPOSITORY/DayToDay/";
		benTransPath=	"/DEPOSITORY/BENEFICIARY/Transactions/";
		transParam	=	"COCD=" +COCD.value +"&CoName=" +CoName.value +"&CoGroup=" +CoGroup.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStYr=" +FinStart.value +"&FinEndYr=" +FinEnd.value +"&Branch=&CDSLPoolAccCode=" +CDSLPoolAccCode.value +"&CDSLDPID=" +CDSLDPID.value +"&CDSLDPName=" +CDSLDPName.value +"&NSDLPoolAccCode=" +NSDLPoolAccCode.value +"&NSDLDPID=" +NSDLDPID.value +"&NSDLDPName=" +NSDLDPName.value;
		
		ioMasters[0].selected	=	true;
		ioReports[0].selected	=	true;
		StockUserReports[0].selected =	true;
		
		if( ioVouchers.value == "1" )
		{
			parent.Display.location.href	=	transPath +"Dp_Import.cfm?TemplateName=Import&" +transParam;
		}
		else if( ioVouchers.value == "2" )
		{
			parent.Display.location.href	=	transPath +"MissingDetailsScreen.cfm?TemplateName=Stock_MissingDetailsScreen&" +transParam;
		}
		else if( ioVouchers.value == "4" )
		{
			parent.Display.location.href	=	transPath +"InwardEntry.cfm?TemplateName=Stock_ClientWise_InwardEntry&" +transParam +"&InwardType=ClientWise";
		}
		else if( ioVouchers.value == "5" )
		{
			parent.Display.location.href	=	transPath +"InwardEntry.cfm?TemplateName=Stock_ScripWise_InwardEntry&" +transParam +"&InwardType=ScripWise";
		}
		else if( ioVouchers.value == "6" )
		{
			parent.Display.location.href	=	transPath +"OutwardEntry.cfm?TemplateName=Stock_ClientWise_OutwardEntry&" +transParam +"&OutwardType=ClientWise";
		}
		else if( ioVouchers.value == "7" )
		{
			parent.Display.location.href	=	transPath +"OutwardEntry.cfm?TemplateName=Stock_ScripWise_OutwardEntry&" +transParam +"&OutwardType=ScripWise";
		}
		else if( ioVouchers.value == "9" )
		{
			parent.Display.location.href	=	transPath +"IOProcessParameters.cfm?TemplateName=Stock_IOProcessParameters&IOType=I&" +transParam;
		}
		else if( ioVouchers.value == "11" )
		{
			parent.Display.location.href	=	transPath +"CloseOutParameters.cfm?TemplateName=Stock_CloseOutParameters&InwardShort=DirectPayIn&" +transParam;
		}
		else if( ioVouchers.value == "12" )
		{
			parent.Display.location.href	=	transPath +"InterSetlParameters.cfm?TemplateName=Stock_Client_InterSetlParameters&" +transParam +"&InterSetlType=Client";
		}
		else if( ioVouchers.value == "13" )
		{
			parent.Display.location.href	=	transPath +"InterSetlParameters.cfm?TemplateName=Stock_Pool_InterSetlParameters&" +transParam +"&InterSetlType=Pool";
		}
		else if( ioVouchers.value == "14" )
		{
			parent.Display.location.href	=	transPath +"AuctionParameters.cfm?TemplateName=Stock_AuctionParameters&" +transParam;
		}
		else if( ioVouchers.value == "15" )
		{
			parent.Display.location.href	=	transPath +"CloseOutParameters.cfm?TemplateName=Stock_ExchangeInwardShort_CloseOutParameters&InwardShort=Exchange&" +transParam;
		}
		else if( ioVouchers.value == "16" )
		{
			parent.Display.location.href	=	transPath +"CloseOutParameters.cfm?TemplateName=Stock_CloseOutMarketing_CloseOutParameters&InwardShort=Client&" +transParam;
		}
		else if( ioVouchers.value == "18" )
		{
			parent.Display.location.href	=	transPath +"TransactionDeletion.cfm?TemplateName=Stock_TransactionDeletion&" +transParam;
		}
		else if( ioVouchers.value == "19" )
		{
			parent.Display.location.href	=	benTransPath +"Voucher_Screen.cfm?TemplateName=Stock_BenInward&" +transParam;
		}
		else if( ioVouchers.value == "20" )
		{
			parent.Display.location.href	=	transPath +"PoolToBeneficiaryParameters.cfm?TemplateName=Stock_PoolToBeneficiaryTransfer&" +transParam;
		}
		else if( ioVouchers.value == "21" )
		{
			parent.Display.location.href	=	transPath +"AuctionParameters.cfm?TemplateName=Stock_AuctEdit&AuctionPriceEdit=Yes&" +transParam;
		}
		else if( ioVouchers.value == "22" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/FileUpLoads/Import.cfm?TemplateName=Stock_CDSLImport&" +transParam;
		}
		else if( ioVouchers.value == "23" )
		{
			parent.Display.location.href	=	transPath +"CloseOutParameters.cfm?TemplateName=Stock_CloseOutParameters&InwardShort=BreakUp&" +transParam;
		}
		else if( ioVouchers.value == "24" )
		{
			parent.Display.location.href	=	transPath +"CloseOutParameters.cfm?TemplateName=Stock_BenMarket&InwardShort=BenToMarket&" +transParam;
		}
		else if( ioVouchers.value == "25" )
		{
			parent.Display.location.href	=	transPath +"CloseOutParameters.cfm?TemplateName=Stock_PayoutExchange&InwardShort=PayoutToExchange&" +transParam;
		}
		else if( ioVouchers.value == "26" )
		{
			parent.Display.location.href	=	benTransPath +"Import_Beneficiary_Transaction.cfm?TemplateName=Stock_Import&" +transParam;
		}
		else if( ioVouchers.value == "27" )
		{
			parent.Display.location.href	=	benTransPath +"Import_Beneficiary_Opening_ISIN.cfm?TemplateName=Stock_Import_Ben_Opening&" +transParam;
		}
		else if( ioVouchers.value == "28" )
		{
			parent.Display.location.href	=	transPath +"PayoutToClientParameters.cfm?TemplateName=Stock_PayoutToClients&InwardShort=PayoutToClient&" +transParam;
		}
		else if( ioVouchers.value == "29" )
		{
			parent.Display.location.href	=	transPath +"AuctionParameters.cfm?TemplateName=Stock_AutoAuctionProcess&AutoAuctionProcess=True&" +transParam;
		}
		else if( ioVouchers.value == "30" )
		{
			parent.Display.location.href	=	transPath +"ClientBeneficiaryToPool.cfm?TemplateName=Stock_AutoAllocate&" +transParam;
		}
		else if( ioVouchers.value == "31" )
		{
			parent.Display.location.href	=	transPath +"Client_Holding_Parameter.cfm?TemplateName=Client_Holding&" +transParam;
		}
		else if( ioVouchers.value == "32" )
		{
			parent.Display.location.href	=	transPath +"Client_Holding_Parameter.cfm?TemplateName=Hold_Release&" +transParam;
		}
		else if( ioVouchers.value == "33" )
		{
			parent.Display.location.href	=	transPath +"InterSetlParameters.cfm?TemplateName=Stock_Hold_InterSetl&" +transParam +"&InterSetlType=ClientHolding";
		}
		else if( ioVouchers.value == "34" )
		{
			parent.Display.location.href	=	transPath +"CloseOutParameters.cfm?TemplateName=Stock_EarlyPayIn&InwardShort=EarlyPayInToExchange&" +transParam;
		}
		else if( ioVouchers.value == "35" )
		{
			parent.Display.location.href	=	transPath +"CDSL_To_NSDL_Param.cfm?TemplateName=CDSL_To_NSDL_Transfer&InwardShort=CDSL_To_NSDL_Transfer&" +transParam;
		}
		else if( ioVouchers.value == "36" )
		{
			parent.Display.location.href	=	transPath +"CloseOutParameters.cfm?TemplateName=Ben_Inter_Transfer&InwardShort=Ben_Inter_Transfer&" +transParam;
		}
		else if( ioVouchers.value == "37" )
		{
			parent.Display.location.href	=	transPath +"AutoAllocationMktSetl.cfm?TemplateName=Stock_AutoAllocate&InwardShort=Ben_Inter_Transfer&" +transParam;
		}
		else if( ioVouchers.value == "38" )
		{
			parent.Display.location.href	=	transPath +"CloseOutParameters.cfm?TemplateName=Stock_AutoPostInward&InwardShort=AutoInwardPost&" +transParam;
		}
		else if( ioVouchers.value == "39" )
		{
			parent.Display.location.href	=	transPath +"CloseOutParameters.cfm?TemplateName=Stock_OblTransfer&InwardShort=OblTransfer&" +transParam;
		}
		else if( ioVouchers.value == "40" )
		{
			parent.Display.location.href	=	transPath +"IoAutoProcess1.cfm?TemplateName=Stock_Bliend_process&" +transParam;
		}
		else if( ioVouchers.value == "41" )
		{
			parent.Display.location.href	=	transPath +"IoAutoProcess2.cfm?TemplateName=Stock_Bliend_process&" +transParam;
		}
		else if( ioVouchers.value == "42" )
		{
			parent.Display.location.href	=	transPath +"InternalPayIn_NSDL.cfm?TemplateName=InternalPayIn&" +transParam;
		}
		else if( ioVouchers.value == "43" )
		{
			parent.Display.location.href	=	transPath +"DirPayoutInternal.cfm?TemplateName=DirPayoutInternal&" +transParam;
		}
		else if( ioVouchers.value == "44" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/BENEFICIARY/TRANSACTIONS/" +"Beneficiary_Parameter.cfm?TemplateName=Beneficiary_Parameter&" +transParam;
		}
		else if( ioVouchers.value == "45" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/BENEFICIARY/TRANSACTIONS/" +"Pledge_Param.cfm?TemplateName=Pledge_Parameter&" +transParam;
		}
		else if( ioVouchers.value == "46" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/CDSL/Process/" +"CDSL_Billing.cfm?TemplateName=CDSLBill&" +transParam;
		}
		else if( ioVouchers.value == "47" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/CDSL/Masters/" +"CDSL_Demat_Inward.cfm?TemplateName=CDSLDematInward&" +transParam;
		}
				else if( ioVouchers.value == "48" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/CDSL/Process/" +"CDSL_Trans_Deletion.cfm?TemplateName=CDSLTransDeletion&" +transParam;
		}
		else if( ioVouchers.value == "50" )
		{
			parent.Display.location.href	=	transPath +"CloseOutParameters.cfm?TemplateName=ExpCdslPoolToCdslPIn&InwardShort=ExpCdslPoolToCdslPIn&" +transParam;
		}
		else if( ioVouchers.value == "51" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/CDSL/Masters/" +"Pysical_ShareEntry.cfm?TemplateName=Pysical_ShareEntry&" +transParam;
		}
		else if( ioVouchers.value == "52" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/BENEFICIARY/TRANSACTIONS/" +"Pledge_Update.cfm?TemplateName=Pledge_Update&" +transParam;
		}
		else if( ioVouchers.value == "53" )
		{
			parent.Display.location.href	=	"/DEPOSITORY/CDSL/Process/" + "RTA_ImportTranscation.cfm?TemplateName=RTA_ImportTranscation&" +transParam;
		}
		else if( ioVouchers.value == "54" )
		{
			parent.Display.location.href	=	transPath + "Dp_Demat.cfm?TemplateName=Demat&" +transParam;
		}
		else if( ioVouchers.value == "55" )
		{
			parent.Display.location.href	=	transPath + "Dp_Instructions.cfm?TemplateName=Instructions&" +transParam;
		}
		else if( ioVouchers.value == "56" )
		{
			parent.Display.location.href	=	transPath + "Dp_Fee_Calc.cfm?TemplateName=Instructions&" +transParam;
		}
		else if( ioVouchers.value == "57" )
		{
			parent.Display.location.href	=	transPath + "Dp_Bill.cfm?TemplateName=Bill&" +transParam;
		}
		else if( ioVouchers.value == "58" )
		{
			parent.Display.location.href	=	transPath + "PriceUpdation.cfm?TemplateName=PriceUpdation&" +transParam;
		}
		else if( ioVouchers.value == "59" )
		{
			parent.Display.location.href	=	transPath + "MissingPrice.cfm?TemplateName=MissingPrice&" +transParam;
		}
		else if( ioVouchers.value == "60" )
		{
			parent.Display.location.href	=	transPath + "NullFees.cfm?TemplateName=NullFees&" +transParam;
		}
		else
		{
			parent.Display.location.href	=	"/DEPOSITORY/DynamicFrame/BlankPage.html";
		}
	}
}


/* *************************************************
	STOCK INWARD / OUTWARD - REPORTS MENU ITEMS.
************************************************* */
function ioReportsNavigate( form, source )
{
	with( form )
	{
		reportsPath		=	"/DEPOSITORY/IO_FOCAPS/Reports/";
		reportsParam	=	"COCD=" +COCD.value +"&CoName=" +CoName.value +"&CoGroup=" +CoGroup.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStYr=" +FinStart.value +"&FinEndYr=" +FinEnd.value +"&Branch=&CDSLPoolAccCode=" +CDSLPoolAccCode.value +"&CDSLDPID=" +CDSLDPID.value +"&CDSLDPName=" +CDSLDPName.value +"&NSDLPoolAccCode=" +NSDLPoolAccCode.value +"&NSDLDPID=" +NSDLDPID.value +"&NSDLDPName=" +NSDLDPName.value;
		
		ioMasters[0].selected	=	true;
		ioVouchers[0].selected	=	true;
		StockUserReports[0].selected =	true;
				
		if( ioReports.value > 0 && source == 2 )
		{
			txtIOReports.value				=	ioReports.value;
			parent.Display.location.href	=	reportsPath +"ReportParameters.cfm?Template_ID="+ioReports.value+"&"+reportsParam +"&ReportID=" +ioReports.value;
		}
		else if( txtIOReports.value > 0 && source == 1 )
		{
			ioReports.value					=	txtIOReports.value;
			parent.Display.location.href	=	reportsPath +"ReportParameters.cfm?Template_ID="+txtIOReports.value+"&" +reportsParam +"&ReportID=" +txtIOReports.value;
		}
		else
		{
			parent.Display.location.href	=	"/DEPOSITORY/DynamicFrame/BlankPage.html";
		}
	}
}

function ioUserReportsNavigate( form, source )
{
	with( form )
	{
		reportsPath		=	"/DEPOSITORY/FOCAPS_REPORTS/REPORTS_TEMPLATES";
		reportsParam	=	"COCD=" +COCD.value +"&CoName=" +CoName.value +"&CoGroup=" +CoGroup.value +"&Market=" +Market.value +"&Exchange=" +Exchange.value +"&Broker=" +Broker.value +"&FinStart=" +FinStart.value +"&FinEnd=" +FinEnd.value +"&Branch=&CDSLPoolAccCode=" +CDSLPoolAccCode.value +"&CDSLDPID=" +CDSLDPID.value +"&CDSLDPName=" +CDSLDPName.value +"&NSDLPoolAccCode=" +NSDLPoolAccCode.value +"&NSDLDPID=" +NSDLDPID.value +"&NSDLDPName=" +NSDLDPName.value;
		
		ioMasters[0].selected	=	true;
		ioVouchers[0].selected	=	true;
		ioReports[0].selected	=	true;
		if(source == 3)
		{
			StockUserReports.value=   txtIOReports.value
		}
		if( StockUserReports.value > 0 )
		{
			txtIOReports.value = StockUserReports.value;
			parent.Display.location.href = reportsPath +"/REPORT_PARAMETERS.cfm?Segment=IO&Template_ID="+StockUserReports.value+"&"+reportsParam +"&REPORT_ID=" +StockUserReports.value;
		}
		else
		{
			parent.Display.location.href = reportsPath +"/REPORT_PARAMETERS.cfm?Segment=IO&Template_ID="+txtIOReports.value+"&"+reportsParam +"&REPORT_ID=" +txtIOReports.value;
		}
	}
}